plugins {
    id("com.android.application") apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
