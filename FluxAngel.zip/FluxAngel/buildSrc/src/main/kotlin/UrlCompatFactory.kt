import com.android.build.api.instrumentation.AsmClassVisitorFactory
import com.android.build.api.instrumentation.ClassContext
import com.android.build.api.instrumentation.ClassData
import com.android.build.api.instrumentation.InstrumentationParameters
import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes

/**
 * Old Android (<13) lacks URLDecoder.decode(String, Charset) / URLEncoder.encode(String, Charset) (Java 10 APIs).
 * NewPipeExtractor calls them => NoSuchMethodError. Redirect those calls (in ALL classes) to CompatUrl.
 */
abstract class UrlCompatFactory : AsmClassVisitorFactory<InstrumentationParameters.None> {
    override fun createClassVisitor(classContext: ClassContext, nextClassVisitor: ClassVisitor): ClassVisitor =
        object : ClassVisitor(Opcodes.ASM9, nextClassVisitor) {
            override fun visitMethod(
                access: Int, name: String?, descriptor: String?, signature: String?, exceptions: Array<out String>?
            ): MethodVisitor {
                val mv = super.visitMethod(access, name, descriptor, signature, exceptions)
                return object : MethodVisitor(Opcodes.ASM9, mv) {
                    override fun visitMethodInsn(
                        opcode: Int, owner: String?, name: String?, descriptor: String?, isInterface: Boolean
                    ) {
                        if (opcode == Opcodes.INVOKESTATIC &&
                            (owner == "java/net/URLDecoder" || owner == "java/net/URLEncoder") &&
                            (name == "decode" || name == "encode") &&
                            descriptor == "(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;"
                        ) {
                            super.visitMethodInsn(
                                Opcodes.INVOKESTATIC, "com/ranweir/fluxangel/CompatUrl", name, descriptor, false
                            )
                        } else super.visitMethodInsn(opcode, owner, name, descriptor, isInterface)
                    }
                }
            }
        }

    override fun isInstrumentable(classData: ClassData): Boolean =
        classData.className != "com.ranweir.fluxangel.CompatUrl"
}
