package fluxbuild;

import com.android.build.api.instrumentation.AsmClassVisitorFactory;
import com.android.build.api.instrumentation.ClassContext;
import com.android.build.api.instrumentation.ClassData;
import com.android.build.api.instrumentation.InstrumentationParameters;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/**
 * Old Android (below 13) lacks URLDecoder.decode(String, Charset) and URLEncoder.encode(String, Charset)
 * (Java 10 APIs). NewPipeExtractor calls them, which throws NoSuchMethodError. This redirects those
 * calls, in all classes, to com.ranweir.fluxangel.CompatUrl.
 */
public abstract class UrlCompatFactory implements AsmClassVisitorFactory<InstrumentationParameters.None> {
    private static final String DESC = "(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;";

    @Override
    public ClassVisitor createClassVisitor(ClassContext classContext, ClassVisitor next) {
        return new ClassVisitor(Opcodes.ASM9, next) {
            @Override
            public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                MethodVisitor mv = super.visitMethod(access, name, descriptor, signature, exceptions);
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    @Override
                    public void visitMethodInsn(int opcode, String owner, String mName, String mDesc, boolean isInterface) {
                        if (opcode == Opcodes.INVOKESTATIC
                                && ("java/net/URLDecoder".equals(owner) || "java/net/URLEncoder".equals(owner))
                                && ("decode".equals(mName) || "encode".equals(mName))
                                && DESC.equals(mDesc)) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "com/ranweir/fluxangel/CompatUrl", mName, mDesc, false);
                        } else {
                            super.visitMethodInsn(opcode, owner, mName, mDesc, isInterface);
                        }
                    }
                };
            }
        };
    }

    @Override
    public boolean isInstrumentable(ClassData classData) {
        return !"com.ranweir.fluxangel.CompatUrl".equals(classData.getClassName());
    }
}
