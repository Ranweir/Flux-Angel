plugins { `kotlin-dsl` }
repositories { google(); mavenCentral(); gradlePluginPortal() }
dependencies { implementation("com.android.tools.build:gradle:8.5.2") }
