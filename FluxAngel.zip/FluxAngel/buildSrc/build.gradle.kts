plugins { `java-library` }
repositories { google(); mavenCentral() }
java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}
dependencies {
    // the Android Gradle Plugin version lives here (root build.gradle.kts applies it without a version)
    implementation("com.android.tools.build:gradle:8.5.2")
    implementation("org.ow2.asm:asm:9.6")
}
