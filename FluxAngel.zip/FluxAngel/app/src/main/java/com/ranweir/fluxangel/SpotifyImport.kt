package com.ranweir.fluxangel

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/** One song as Spotify (or a CSV export) lists it. Not playable yet; see [SpotifyImporter.matchToYouTube]. */
data class SpotifyTrack(val title: String, val artist: String, val durationMs: Long)

/**
 * [tracks] = every song that could be read. [maybeTruncated] = Spotify may have more songs than we got
 * (only the first 100 were readable), so the UI should point to the CSV import for the rest.
 */
class SpotifyPlaylistData(val name: String, val tracks: List<SpotifyTrack>, val maybeTruncated: Boolean)

object SpotifyImporter {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private val idRegex = Regex("""playlist[/:]([A-Za-z0-9]{16,24})""")

    // ---------- link handling ----------

    /** Accepts open.spotify.com links (also /intl-xx/ ones), spotify:playlist:ID, spotify.link short links or a bare ID. */
    fun extractPlaylistId(input: String): String? {
        val text = input.trim()
        idRegex.find(text)?.let { return it.groupValues[1] }
        if (Regex("^[A-Za-z0-9]{22}$").matches(text)) return text
        if (text.startsWith("http") && (text.contains("spotify.link") || text.contains("spotify.app.link"))) {
            // short share link: follow the redirect and look for the id in the final address
            val finalUrl = runCatching {
                http.newCall(Request.Builder().url(text).header("User-Agent", BROWSER_UA).build())
                    .execute().use { it.request.url.toString() }
            }.getOrNull() ?: return null
            return idRegex.find(finalUrl)?.groupValues?.get(1)
        }
        return null
    }

    // ---------- reading a public playlist ----------

    /** Blocking – call from a background thread. Throws IOException with a readable message. */
    fun fetchPlaylist(input: String): SpotifyPlaylistData {
        val id = extractPlaylistId(input)
            ?: throw IOException("This doesn't look like a Spotify playlist link")

        val html = httpGet("https://open.spotify.com/embed/playlist/$id", null)
        val json = extractNextData(html)
            ?: throw IOException("Spotify did not return playlist data. Is the playlist public?")

        val tracksFromEmbed = findKey(json, "trackList")?.let { it as? JSONArray }?.let { parseEmbedTracks(it) }.orEmpty()
        val name = playlistName(json) ?: "Spotify playlist"
        val token = findKey(json, "accessToken") as? String

        // The embed page only lists the first 100 songs. With the anonymous token it ships, try to read the whole
        // playlist from the Web API; if Spotify refuses, we keep the embed songs and tell the user.
        var best = tracksFromEmbed
        var apiTotal = -1
        if (!token.isNullOrBlank()) {
            runCatching { fetchAllViaApi(id, token) }.getOrNull()?.let { (list, total) ->
                apiTotal = total
                if (list.size > best.size) best = list
            }
        }
        if (best.isEmpty()) throw IOException("No songs found. The playlist is private or empty. Try the CSV import instead.")
        val truncated = if (apiTotal >= 0) best.size < apiTotal else best.size >= 100
        return SpotifyPlaylistData(name, best, truncated)
    }

    private fun httpGet(url: String, bearer: String?): String {
        val b = Request.Builder().url(url).header("User-Agent", BROWSER_UA).header("Accept-Language", "en")
        if (bearer != null) b.header("Authorization", "Bearer $bearer")
        http.newCall(b.build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Spotify answered HTTP ${r.code}")
            return r.body?.string() ?: throw IOException("Empty answer from Spotify")
        }
    }

    private fun extractNextData(html: String): JSONObject? {
        val marker = html.indexOf("id=\"__NEXT_DATA__\"")
        if (marker < 0) return null
        val start = html.indexOf('>', marker) + 1
        val end = html.indexOf("</script>", start)
        if (start <= 0 || end < 0) return null
        return runCatching { JSONObject(html.substring(start, end)) }.getOrNull()
    }

    /** Depth-first search for the first value stored under [key]; survives small layout changes on Spotify's side. */
    private fun findKey(node: Any?, key: String): Any? {
        when (node) {
            is JSONObject -> {
                if (node.has(key) && !node.isNull(key)) return node.get(key)
                val keys = node.keys()
                while (keys.hasNext()) findKey(node.opt(keys.next()), key)?.let { found -> return found }
            }
            is JSONArray -> for (i in 0 until node.length()) findKey(node.opt(i), key)?.let { return it }
        }
        return null
    }

    private fun playlistName(json: JSONObject): String? {
        val entity = findKey(json, "entity") as? JSONObject ?: return null
        return (entity.optString("name").ifBlank { entity.optString("title") }).takeIf { it.isNotBlank() }
    }

    private fun parseEmbedTracks(arr: JSONArray): List<SpotifyTrack> = (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val title = o.optString("title").trim()
        if (title.isEmpty()) return@mapNotNull null
        SpotifyTrack(title, cleanArtist(o.optString("subtitle")), o.optLong("duration", 0L))
    }

    private fun cleanArtist(s: String) = s.replace(' ', ' ').trim()

    /** Pages through /v1/playlists/{id}/tracks. Returns (songs, total). */
    private fun fetchAllViaApi(id: String, token: String): Pair<List<SpotifyTrack>, Int> {
        val out = ArrayList<SpotifyTrack>()
        var total = -1
        var offset = 0
        val fields = "items(track(name,duration_ms,is_local,artists(name))),total,next"
        while (offset < 10_000) {
            val body = httpGet(
                "https://api.spotify.com/v1/playlists/$id/tracks?limit=100&offset=$offset&fields=$fields",
                token
            )
            val o = JSONObject(body)
            total = o.optInt("total", total)
            val items = o.optJSONArray("items") ?: break
            for (i in 0 until items.length()) {
                val t = items.optJSONObject(i)?.optJSONObject("track") ?: continue
                val title = t.optString("name").trim()
                if (title.isEmpty()) continue
                val artists = t.optJSONArray("artists")
                val artist = (0 until (artists?.length() ?: 0)).joinToString(", ") { artists!!.getJSONObject(it).optString("name") }
                out += SpotifyTrack(title, artist, t.optLong("duration_ms", 0L))
            }
            if (o.isNull("next") || items.length() == 0) break
            offset += 100
        }
        return out to total
    }

    // ---------- CSV / text file (Exportify, TuneMyMusic, Soundiiz, or plain "Artist - Title" lines) ----------

    fun parseFile(text: String): List<SpotifyTrack> {
        val clean = text.removePrefix("﻿")
        val rows = parseCsv(clean)
        if (rows.isEmpty()) return emptyList()
        val header = rows.first().map { it.trim().lowercase() }
        fun col(vararg names: String): Int = header.indexOfFirst { h -> names.any { n -> h == n || h.startsWith(n) } }
        val titleCol = col("track name", "track", "title", "song name", "song", "name")
        val artistCol = col("artist name(s)", "artist name", "artists", "artist")
        if (titleCol >= 0 && header.size > 1) {
            val durCol = header.indexOfFirst { it.startsWith("duration") }
            return rows.drop(1).mapNotNull { r ->
                val title = r.getOrNull(titleCol)?.trim().orEmpty()
                if (title.isEmpty()) return@mapNotNull null
                val artist = r.getOrNull(artistCol)?.trim().orEmpty().replace(";", ", ")
                val raw = r.getOrNull(durCol)?.trim()?.toDoubleOrNull() ?: 0.0
                // Exportify gives milliseconds; some tools give seconds. A song is never over 1000 s long in ms.
                val ms = if (durCol < 0) 0L else if (raw > 2000) raw.toLong() else (raw * 1000).toLong()
                SpotifyTrack(title, artist, ms)
            }
        }
        // no recognisable header: treat every line as "Artist - Title" (or just a title)
        return clean.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { line ->
            val parts = line.split(" - ", limit = 2)
            if (parts.size == 2) SpotifyTrack(parts[1].trim(), parts[0].trim(), 0L) else SpotifyTrack(line, "", 0L)
        }
    }

    /** Small RFC-4180 reader: quoted fields, escaped quotes, commas/semicolons-free newlines inside quotes. */
    private fun parseCsv(text: String): List<List<String>> {
        val firstLine = text.lineSequence().firstOrNull().orEmpty()
        val delim = if (firstLine.count { it == ';' } > firstLine.count { it == ',' }) ';' else ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cur = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                inQuotes && c == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cur.append('"'); i++ }
                c == '"' -> inQuotes = !inQuotes
                !inQuotes && c == delim -> { row.add(cur.toString()); cur.setLength(0) }
                !inQuotes && (c == '\n' || c == '\r') -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row.add(cur.toString()); cur.setLength(0)
                    if (row.any { it.isNotBlank() }) rows.add(row)
                    row = ArrayList()
                }
                else -> cur.append(c)
            }
            i++
        }
        row.add(cur.toString())
        if (row.any { it.isNotBlank() }) rows.add(row)
        return rows
    }

    // ---------- finding the song on YouTube ----------

    private val badWords = listOf(
        "live", "cover", "remix", "karaoke", "instrumental", "reaction", "slowed", "reverb", "sped up",
        "nightcore", "8d", "tutorial", "mashup", "piano version", "acoustic", "bass boosted"
    )

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Spotify titles often end in " - Remastered 2011" or "(feat. X)"; compare without those. */
    private fun coreTitle(s: String) = norm(s.substringBefore(" - ").replace(Regex("\\(.*?\\)|\\[.*?]"), " "))

    private fun score(t: SpotifyTrack, c: Song): Int {
        val ct = norm(c.title)
        val up = norm(c.artist)
        val title = coreTitle(t.title)
        val firstArtist = norm(t.artist.split(",", "&").firstOrNull().orEmpty())
        var s = 0

        if (t.durationMs > 0 && c.durationSec > 0) {
            val d = abs(c.durationSec - t.durationMs / 1000)
            s += when {
                d <= 3 -> 60
                d <= 8 -> 45
                d <= 15 -> 25
                d <= 30 -> 0
                else -> -40
            }
        }
        if (title.isNotEmpty() && ct.contains(title)) s += 30
        if (firstArtist.isNotEmpty() && (ct.contains(firstArtist) || up.contains(firstArtist))) s += 20
        if (c.artist.endsWith("- Topic")) s += 10
        if (up.contains("vevo") || up.contains("official")) s += 5
        val orig = norm(t.title)
        for (w in badWords) if (Regex("\\b$w\\b").containsMatchIn(ct) && !Regex("\\b$w\\b").containsMatchIn(orig)) s -= 35
        if (c.durationSec > 900 && (t.durationMs == 0L || t.durationMs < 600_000)) s -= 30
        return s
    }

    /** Blocking. Returns the best YouTube match for [t], or null when nothing was found. */
    fun matchToYouTube(t: SpotifyTrack): Song? {
        val first = "${t.artist.split(",").firstOrNull().orEmpty().trim()} ${t.title}".trim()
        var best: Pair<Song, Int>? = null
        for (query in listOf(first, "$first official audio")) {
            val results = try {
                YouTubeRepo.search(query)
            } catch (e: Exception) {
                Thread.sleep(800)
                runCatching { YouTubeRepo.search(query) }.getOrDefault(emptyList())
            }.filter { it.durationSec > 0 }
            for (r in results.take(8)) {
                val sc = score(t, r)
                if (best == null || sc > best!!.second) best = r to sc
            }
            // good enough (duration + title/artist agree): skip the second search
            if (best != null && best!!.second >= 80) break
        }
        return best?.first
    }
}
