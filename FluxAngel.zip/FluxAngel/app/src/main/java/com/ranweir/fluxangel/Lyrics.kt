package com.ranweir.fluxangel

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class LyricLine(val timeMs: Long, val text: String)

sealed class LyricsResult {
    object None : LyricsResult()
    /** synced = timed lines (LRC); otherwise [plain] text only */
    class Found(val synced: List<LyricLine>, val plain: String) : LyricsResult()
}

/** Lyrics from LRCLIB (free, no key). Results are kept in memory per song. */
object LyricsRepo {
    private val cache = HashMap<String, LyricsResult>()
    private const val API = "https://lrclib.net/api/search"

    private fun cleanTitle(t: String): String {
        var s = t.replace(Regex("""[\(\[\{][^)\]}]*[)\]}]"""), " ")
        s = s.substringBefore("|")
        s = s.replace(Regex("""(?i)\b(official|lyrical|lyrics?|video|audio|full\s*song|full\s*video|music|hd|4k|hq|remastered|slowed|reverb|feat\.?.*|ft\.?.*)\b"""), " ")
        return s.replace(Regex("""\s+"""), " ").trim(' ', '-', '–', '|')
    }

    private fun cleanArtist(a: String): String =
        a.replace(Regex("""(?i)\s*-\s*topic$|vevo$|\bofficial\b"""), "").trim()

    private fun get(q: String): JSONArray? {
        val conn = URL("$API?q=${Uri.encode(q)}").openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 8000; conn.readTimeout = 10000
            conn.setRequestProperty("User-Agent", "FluxAngel (YouTube music player)")
            if (conn.responseCode != 200) null else JSONArray(conn.inputStream.bufferedReader().readText())
        } finally { conn.disconnect() }
    }

    fun parseLrc(lrc: String): List<LyricLine> {
        val out = ArrayList<LyricLine>()
        val stamp = Regex("""\[(\d+):(\d+(?:\.\d+)?)]""")
        for (line in lrc.lines()) {
            val ms = stamp.findAll(line).toList()
            if (ms.isEmpty()) continue
            val text = line.substring(ms.last().range.last + 1).trim()
            for (m in ms) {
                val t = ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toDouble()) * 1000).toLong()
                out.add(LyricLine(t, text))
            }
        }
        return out.sortedBy { it.timeMs }
    }

    /** Blocking: call from a background thread. */
    fun fetch(title: String, artist: String, durationSec: Long): LyricsResult {
        val key = "$title|$artist"
        synchronized(cache) { cache[key]?.let { return it } }
        val t = cleanTitle(title).ifBlank { title }
        val a = cleanArtist(artist)
        var best: JSONObject? = null
        for (q in listOf("$t $a", t)) {
            val arr = runCatching { get(q) }.getOrNull() ?: continue
            val items = (0 until arr.length()).map { arr.getJSONObject(it) }
            val withSync = items.filter { it.optString("syncedLyrics").isNotBlank() }
            best = (if (durationSec > 0) withSync.minByOrNull { abs(it.optDouble("duration", 0.0) - durationSec) }
                        ?.takeIf { abs(it.optDouble("duration", 0.0) - durationSec) <= 8 } else null)
                ?: withSync.firstOrNull()
                ?: items.firstOrNull { it.optString("plainLyrics").isNotBlank() }
            if (best != null) break
        }
        val result = best?.let {
            val synced = parseLrc(it.optString("syncedLyrics"))
            val plain = it.optString("plainLyrics")
            if (synced.isEmpty() && plain.isBlank()) LyricsResult.None else LyricsResult.Found(synced, plain)
        } ?: LyricsResult.None
        // only cache hits, so a network failure can be retried
        if (result is LyricsResult.Found) synchronized(cache) { cache[key] = result }
        return result
    }
}
