package com.ranweir.fluxangel.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun AddToDialog(vm: MainViewModel, song: Song, onDismiss: () -> Unit, onCreate: () -> Unit) {
    val ctx = LocalContext.current
    val look = LocalLook.current
    val dark = look.fg.luminance() > 0.5f
    val panel = if (dark) Color(0xF0201E2B) else Color(0xF2FFFFFF)
    var showPlaylists by remember { mutableStateOf(false) }
    val fav = vm.isFavorite(song.url)
    val downloaded = vm.isDownloaded(song.url)

    FluxDialogWindow(onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(panel)
                .border(0.8.dp, fg(0.14f), RoundedCornerShape(28.dp))
        ) {
            // header
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(fg(0.1f))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = fg(), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = fg(0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            // quick actions
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction(
                    if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    if (fav) "Liked" else "Like", if (fav) Pink else fg(), Modifier.weight(1f)
                ) { vm.toggleFavorite(song) }
                QuickAction(
                    if (downloaded) Icons.Filled.DownloadDone else Icons.Outlined.Download,
                    if (downloaded) "Remove" else "Download", fg(), Modifier.weight(1f)
                ) { if (downloaded) vm.removeDownload(song) else vm.download(song); onDismiss() }
                QuickAction(Icons.Outlined.Share, "Share", fg(), Modifier.weight(1f)) {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${song.title} – ${song.artist}\n${song.url}")
                    }
                    runCatching { ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    onDismiss()
                }
            }
            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = fg(0.1f), modifier = Modifier.padding(horizontal = 16.dp))
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                MenuItem(Icons.Outlined.SkipNext, "Play next") { vm.playNext(song); onDismiss() }
                MenuItem(Icons.Outlined.QueueMusic, "Add to queue") { vm.addToQueue(song); onDismiss() }
                if (song.artist.isNotBlank() && song.artist != "This phone") {
                    MenuItem(Icons.Outlined.PlayArrow, "Play more from ${song.artist.removeSuffix(" - Topic")}") { vm.playArtist(song.artist); onDismiss() }
                }
                MenuItem(
                    Icons.Outlined.PlaylistAdd, "Add to playlist",
                    trailing = if (showPlaylists) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore
                ) { showPlaylists = !showPlaylists }
                if (showPlaylists) {
                    Column(Modifier.padding(start = 30.dp)) {
                        vm.playlists.forEachIndexed { i, p ->
                            val inPl = p.songs.any { it.url == song.url }
                            MenuItem(
                                if (inPl) Icons.Filled.CheckCircle else Icons.Outlined.Circle, p.name,
                                tint = if (inPl) accentText() else fg(0.7f)
                            ) { vm.togglePlaylistSong(i, song) }
                        }
                        MenuItem(Icons.Outlined.Add, "New playlist", tint = accentText()) { onCreate() }
                    }
                }
                MenuItem(Icons.Outlined.OpenInNew, "Open on YouTube") {
                    runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(song.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    onDismiss()
                }
            }
        }
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(fg(0.08f)).clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = fg(0.85f), fontSize = 12.sp)
    }
}

@Composable
internal fun MenuItem(
    icon: ImageVector, label: String, tint: Color = fg(0.9f),
    trailing: ImageVector? = null, onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = fg(), fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (trailing != null) Icon(trailing, null, tint = fg(0.5f), modifier = Modifier.size(20.dp))
    }
}

/**
 * The popup window: always the full screen, so the blur and dim behind it cover everything evenly (a window that is only as
 * tall as the panel blurs / dims just a band of the screen and leaves a visible edge). Tapping outside the panel closes it.
 */
@Composable
fun FluxDialogWindow(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val view = LocalView.current
        SideEffect {
            runCatching {
                val w = (view.parent as? DialogWindowProvider)?.window ?: return@runCatching
                w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
                w.setDimAmount(0.35f)
                if (Build.VERSION.SDK_INT >= 31) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    w.attributes = w.attributes.also { it.blurBehindRadius = 40 }
                }
            }
        }
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})) { content() }
        }
    }
}

/** The one popup style used all over the app: rounded panel, blurred + dimmed background, same as the song menu. */
@Composable
fun FluxDialog(
    onDismiss: () -> Unit,
    title: String? = null,
    buttons: (@Composable RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val look = LocalLook.current
    val dark = look.fg.luminance() > 0.5f
    val panel = if (dark) Color(0xF0201E2B) else Color(0xF2FFFFFF)
    FluxDialogWindow(onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(panel)
                .border(0.8.dp, fg(0.14f), RoundedCornerShape(28.dp))
        ) {
            if (title != null) {
                Text(
                    title, color = fg(), fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 6.dp)
                )
            }
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp), content = content
            )
            if (buttons != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically, content = buttons
                )
            } else Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun DialogButton(text: String, onClick: () -> Unit, primary: Boolean = false) {
    TextButton(onClick = onClick, colors = ButtonDefaults.textButtonColors(contentColor = if (primary) accentText() else fg(0.75f))) {
        Text(text, fontWeight = if (primary) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun DialogField(value: String, onChange: (String) -> Unit, placeholder: String, trailing: (@Composable () -> Unit)? = null) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(placeholder) }, trailingIcon = trailing,
        shape = RoundedCornerShape(16.dp), colors = fieldColors()
    )
}

@Composable
fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    FluxDialog(
        onDismiss = onDismiss, title = "New playlist",
        buttons = {
            DialogButton("Cancel", onDismiss)
            DialogButton("Create", { if (name.isNotBlank()) onCreate(name.trim()) }, primary = true)
        }
    ) {
        DialogField(name, { name = it }, "Playlist name")
    }
}

/** Import a Spotify playlist (paste its link) or a CSV / text file; shows live progress while songs are matched. */
@Composable
fun ImportPlaylistDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val st = vm.importState
    var link by remember { mutableStateOf("") }
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importFromFile(uri) }
    val running = st != null && !st.finished && st.error == null

    FluxDialog(
        onDismiss = { if (!running) { vm.dismissImport(); onDismiss() } else onDismiss() },
        title = if (st == null) "Import playlist" else st.name,
        buttons = {
            when {
                st == null -> { DialogButton("Cancel", onDismiss); DialogButton("Import", { if (link.isNotBlank()) vm.importSpotify(link.trim()) }, primary = true) }
                running -> { DialogButton("Cancel import", { vm.cancelImport(); onDismiss() }); DialogButton("Hide", onDismiss, primary = true) }
                st.error != null -> { DialogButton("Try again", { vm.dismissImport() }); DialogButton("OK", { vm.dismissImport(); onDismiss() }, primary = true) }
                else -> DialogButton("OK", { vm.dismissImport(); onDismiss() }, primary = true)
            }
        }
    ) {
        when {
            st == null -> {
                Text("Paste the link of a public Spotify playlist. All its songs are matched on YouTube and saved as a new playlist.",
                    fontSize = 13.sp, color = fg(0.75f))
                DialogField(link, { link = it }, "open.spotify.com/playlist/…") {
                    TextButton(onClick = { clipboard.getText()?.text?.let { link = it } }) { Text("Paste", color = accentText()) }
                }
                Text("Private playlist, or more than 100 songs? Export a CSV (exportify.net) and import the file.",
                    fontSize = 12.sp, color = fg(0.6f))
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(20.dp)) { Text("Import from CSV / text file") }
            }
            st.error != null -> Text(st.error, color = Color(0xFFFF8A80), fontSize = 13.sp)
            else -> {
                if (st.total == 0) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Reading playlist…", fontSize = 13.sp, color = fg())
                } else {
                    LinearProgressIndicator(progress = { st.done / st.total.toFloat() }, modifier = Modifier.fillMaxWidth())
                    Text(
                        (if (st.finished) "Done: " else "Matching songs… ") + "${st.done} / ${st.total}",
                        fontSize = 13.sp, color = fg()
                    )
                    Text("${st.added} added" + if (st.failed > 0) " · ${st.failed} not found" else "",
                        fontSize = 12.sp, color = fg(0.7f))
                }
                st.note?.let { Text(it, fontSize = 12.sp, color = accentText()) }
                if (running) Text("You can hide this; the import keeps running in the background.", fontSize = 11.sp, color = fg(0.5f))
            }
        }
    }
}
