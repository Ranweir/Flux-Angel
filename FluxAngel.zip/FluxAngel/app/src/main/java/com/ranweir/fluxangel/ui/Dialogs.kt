package com.ranweir.fluxangel.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun AddToDialog(vm: MainViewModel, song: Song, onDismiss: () -> Unit, onCreate: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to…") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (vm.isDownloaded(song.url)) {
                    TextButton(onClick = { vm.removeDownload(song); onDismiss() }) { Text("✓ Downloaded – tap to remove") }
                } else {
                    TextButton(onClick = { vm.download(song); onDismiss() }) { Text("⬇ Download (best quality)") }
                }
                CheckRow("Favorites", vm.isFavorite(song.url)) { vm.toggleFavorite(song) }
                vm.playlists.forEachIndexed { i, p ->
                    CheckRow(p.name, p.songs.any { it.url == song.url }) { vm.togglePlaylistSong(i, song) }
                }
                TextButton(onClick = onCreate) { Text("+ New playlist") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = null)
        Spacer(Modifier.width(12.dp))
        Text(label)
    }
}

@Composable
fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New playlist") },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                placeholder = { Text("Playlist name") }
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
