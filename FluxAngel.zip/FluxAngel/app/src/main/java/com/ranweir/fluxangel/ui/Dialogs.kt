package com.ranweir.fluxangel.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun AddToDialog(vm: MainViewModel, song: Song, onDismiss: () -> Unit, onCreate: () -> Unit) {
    val ctx = LocalContext.current
    val look = LocalLook.current
    val dark = look.fg.luminance() > 0.5f
    val panel = if (dark) Color(0xF0201E2B) else Color(0xF2FFFFFF)
    var showPlaylists by remember { mutableStateOf(false) }
    val fav = vm.isFavorite(song.url)
    val downloaded = vm.isDownloaded(song.url)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        // blur whatever is behind the popup (Android 12+); harmless no-op elsewhere
        val view = LocalView.current
        SideEffect {
            runCatching {
                val w = (view.parent as? DialogWindowProvider)?.window ?: return@runCatching
                w.setDimAmount(0.35f)
                if (Build.VERSION.SDK_INT >= 31) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    w.attributes = w.attributes.also { it.blurBehindRadius = 40 }
                }
            }
        }
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(panel)
                .border(0.8.dp, fg(0.14f), RoundedCornerShape(28.dp))
        ) {
            // header
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(fg(0.1f))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = fg(), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = fg(0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            // quick actions
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction(
                    if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    if (fav) "Liked" else "Like", if (fav) Pink else fg(), Modifier.weight(1f)
                ) { vm.toggleFavorite(song) }
                QuickAction(
                    if (downloaded) Icons.Filled.DownloadDone else Icons.Outlined.Download,
                    if (downloaded) "Remove" else "Download", fg(), Modifier.weight(1f)
                ) { if (downloaded) vm.removeDownload(song) else vm.download(song); onDismiss() }
                QuickAction(Icons.Outlined.Share, "Share", fg(), Modifier.weight(1f)) {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${song.title} – ${song.artist}\n${song.url}")
                    }
                    runCatching { ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    onDismiss()
                }
            }
            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = fg(0.1f), modifier = Modifier.padding(horizontal = 16.dp))
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                MenuItem(Icons.Outlined.SkipNext, "Play next") { vm.playNext(song); onDismiss() }
                MenuItem(Icons.Outlined.QueueMusic, "Add to queue") { vm.addToQueue(song); onDismiss() }
                MenuItem(
                    Icons.Outlined.PlaylistAdd, "Add to playlist",
                    trailing = if (showPlaylists) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore
                ) { showPlaylists = !showPlaylists }
                if (showPlaylists) {
                    Column(Modifier.padding(start = 30.dp)) {
                        vm.playlists.forEachIndexed { i, p ->
                            val inPl = p.songs.any { it.url == song.url }
                            MenuItem(
                                if (inPl) Icons.Filled.CheckCircle else Icons.Outlined.Circle, p.name,
                                tint = if (inPl) accentText() else fg(0.7f)
                            ) { vm.togglePlaylistSong(i, song) }
                        }
                        MenuItem(Icons.Outlined.Add, "New playlist", tint = accentText()) { onCreate() }
                    }
                }
                MenuItem(Icons.Outlined.OpenInNew, "Open on YouTube") {
                    runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(song.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    onDismiss()
                }
            }
        }
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(fg(0.08f)).clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = fg(0.85f), fontSize = 12.sp)
    }
}

@Composable
private fun MenuItem(
    icon: ImageVector, label: String, tint: Color = fg(0.9f),
    trailing: ImageVector? = null, onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = fg(), fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (trailing != null) Icon(trailing, null, tint = fg(0.5f), modifier = Modifier.size(20.dp))
    }
}

@Composable
fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New playlist") },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                placeholder = { Text("Playlist name") }
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
