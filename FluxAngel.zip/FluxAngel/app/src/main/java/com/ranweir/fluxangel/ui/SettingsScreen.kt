package com.ranweir.fluxangel.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ranweir.fluxangel.MainViewModel

const val TELEGRAM_URL = "https://t.me/ranweirsinventory"

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }

        Text("App theme", fontWeight = FontWeight.SemiBold, color = Highlight)
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(8.dp)) {
            ThemeMode.values().forEach { mode ->
                Row(
                    Modifier.fillMaxWidth()
                        .selectable(selected = vm.themeMode == mode, role = Role.RadioButton) { vm.setTheme(mode) }
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = vm.themeMode == mode, onClick = null,
                        colors = RadioButtonDefaults.colors(selectedColor = Color.White, unselectedColor = Color.White.copy(alpha = 0.6f))
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(mode.label)
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("Community", fontWeight = FontWeight.SemiBold, color = Highlight)
        Button(
            onClick = { uri.openUri(TELEGRAM_URL) },
            modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(26.dp)
        ) {
            Icon(Icons.Default.Send, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Join Telegram")
        }

        Spacer(Modifier.height(22.dp))
        Text("About", fontWeight = FontWeight.SemiBold, color = Highlight)
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            Text("Flux Angel  •  v1.1.0", fontWeight = FontWeight.SemiBold)
            Text("Developer & Credits: Ranweir", color = Color.White.copy(alpha = 0.75f))
        }
    }
}
