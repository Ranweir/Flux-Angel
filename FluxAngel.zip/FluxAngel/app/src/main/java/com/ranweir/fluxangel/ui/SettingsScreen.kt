package com.ranweir.fluxangel.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ranweir.fluxangel.MainViewModel

const val TELEGRAM_URL = "https://t.me/ranweirsinventory"

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val uri = LocalUriHandler.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }

        Text("Profile", fontWeight = FontWeight.SemiBold, color = accentText())
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
            if (picked != null) vm.setProfilePhoto(picked)
        }
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(vm, 64.dp, onClick = { picker.launch("image/*") })
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Profile picture", fontWeight = FontWeight.SemiBold)
                    Text("Shown on the Home screen. Pick any photo from your gallery.", fontSize = 12.sp, color = fg(0.75f))
                }
            }
            Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { picker.launch("image/*") }, shape = RoundedCornerShape(20.dp)) {
                    Text(if (vm.profileVersion > 0L) "Change photo" else "Choose photo")
                }
                if (vm.profileVersion > 0L) {
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { vm.clearProfilePhoto() }) { Text("Remove", color = fg()) }
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("App theme", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(8.dp)) {
            ThemeMode.values().forEach { mode ->
                Row(
                    Modifier.fillMaxWidth()
                        .selectable(selected = vm.themeMode == mode, role = Role.RadioButton) { vm.setTheme(mode) }
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = vm.themeMode == mode, onClick = null,
                        colors = RadioButtonDefaults.colors(selectedColor = fg(), unselectedColor = fg(0.6f))
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(mode.label)
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("Effects", fontWeight = FontWeight.SemiBold, color = accentText())
        Row(
            Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Glass blur", fontWeight = FontWeight.SemiBold)
                Text(
                    "Frosted blur behind the navigation bar (Android 12+). Turn off for maximum smoothness on slower phones.",
                    fontSize = 12.sp, color = fg(0.75f)
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = vm.glassBlur, onCheckedChange = { vm.updateGlassBlur(it) })
        }

        Spacer(Modifier.height(22.dp))
        Text("Audio", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            Text("Max quality", fontWeight = FontWeight.SemiBold)
            Text(
                "Playback and downloads use the highest-bitrate audio stream YouTube provides. Downloads are saved in Music/Flux Angel.",
                fontSize = 12.sp, color = fg(0.75f)
            )
        }

        Spacer(Modifier.height(22.dp))
        Text("Community", fontWeight = FontWeight.SemiBold, color = accentText())
        Button(
            onClick = { uri.openUri(TELEGRAM_URL) },
            modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(26.dp)
        ) {
            Icon(Icons.Default.Send, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Join Telegram")
        }

        Spacer(Modifier.height(22.dp))
        Text("About", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "" }
            Text("Flux Angel  •  v$version", fontWeight = FontWeight.SemiBold)
            Text("Developer & Credits: Ranweir", color = fg(0.75f))
        }
        Spacer(Modifier.navigationBarsPadding().height(28.dp))
    }
}
