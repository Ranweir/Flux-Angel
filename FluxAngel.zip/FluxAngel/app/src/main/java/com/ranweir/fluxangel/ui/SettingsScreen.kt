package com.ranweir.fluxangel.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import com.ranweir.fluxangel.AppLog
import com.ranweir.fluxangel.AudioQuality
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ranweir.fluxangel.MainViewModel

const val TELEGRAM_URL = "https://t.me/ranweirsinventory"

private enum class SPage(val title: String, val sub: String, val icon: ImageVector) {
    PROFILE("Profile", "Your photo on the Home screen", Icons.Default.Person),
    APPEARANCE("Appearance", "Theme, accent color, glass blur", Icons.Default.Palette),
    NAVIGATION("Navigation", "Bar style", Icons.Default.Dock),
    AUDIO("Audio & downloads", "Download and streaming quality, Wi-Fi only", Icons.Default.GraphicEq),
    BACKUP("Backup & restore", "Save or bring back playlists, favorites, history and settings", Icons.Default.Backup),
    LOGS("Error & crash logs", "Crashes and errors recorded on this phone", Icons.Default.BugReport)
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    var pageIdx by rememberSaveable { mutableIntStateOf(-1) }
    val page = SPage.values().getOrNull(pageIdx)
    BackHandler(page != null) { pageIdx = -1 }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (page != null) pageIdx = -1 else onBack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(page?.title ?: "Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            when (page) {
                null -> {
                    SettingsMenu { pageIdx = it.ordinal }
                    // always visible on the main Settings page: credits + community
                    Spacer(Modifier.height(26.dp))
                    AboutPage()
                }
                SPage.PROFILE -> ProfilePage(vm)
                SPage.APPEARANCE -> AppearancePage(vm)
                SPage.NAVIGATION -> NavigationPage(vm)
                SPage.AUDIO -> AudioPage(vm)
                SPage.BACKUP -> BackupPage(vm)
                SPage.LOGS -> LogsPage()
            }
            Spacer(Modifier.navigationBarsPadding().height(28.dp))
        }
    }
}

@Composable
private fun SettingsMenu(onOpen: (SPage) -> Unit) {
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp))) {
        SPage.values().forEachIndexed { i, pg ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(pg) }.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(pg.icon, null, Modifier.size(26.dp), tint = accentText())
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(pg.title, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Text(pg.sub, fontSize = 12.sp, color = fg(0.65f))
                }
                Icon(Icons.Default.ChevronRight, null, tint = fg(0.5f))
            }
            if (i < SPage.values().lastIndex) HorizontalDivider(color = fg(0.1f), modifier = Modifier.padding(start = 60.dp))
        }
    }
}

@Composable
private fun ProfilePage(vm: MainViewModel) {
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
            if (picked != null) vm.setProfilePhoto(picked)
        }
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(vm, 64.dp, onClick = { picker.launch("image/*") })
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Profile picture", fontWeight = FontWeight.SemiBold)
                    Text("Shown on the Home screen. Pick any photo from your gallery.", fontSize = 12.sp, color = fg(0.75f))
                }
            }
            Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { picker.launch("image/*") }, shape = RoundedCornerShape(20.dp)) {
                    Text(if (vm.profileVersion > 0L) "Change photo" else "Choose photo")
                }
                if (vm.profileVersion > 0L) {
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { vm.clearProfilePhoto() }) { Text("Remove", color = fg()) }
                }
            }
        }
}

@Composable
private fun AppearancePage(vm: MainViewModel) {
        Text("App theme", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(8.dp)) {
            ThemeMode.values().forEach { mode ->
                Row(
                    Modifier.fillMaxWidth()
                        .selectable(selected = vm.themeMode == mode, role = Role.RadioButton) { vm.setTheme(mode) }
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = vm.themeMode == mode, onClick = null,
                        colors = RadioButtonDefaults.colors(selectedColor = fg(), unselectedColor = fg(0.6f))
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(mode.label)
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("Accent color", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(12.dp)) {
            AccentColor.values().toList().chunked(4).forEachIndexed { r, rowItems ->
                if (r > 0) Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth()) {
                    rowItems.forEach { c ->
                        Column(
                            Modifier.weight(1f).clickable { vm.updateAccent(c) }.padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(42.dp).clip(CircleShape).background(c.fill)
                                    .border(if (vm.accent == c) 3.dp else 1.dp, if (vm.accent == c) fg() else fg(0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (vm.accent == c) Icon(Icons.Default.Check, null, tint = Ink, modifier = Modifier.size(22.dp))
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(c.label, fontSize = 11.sp, color = fg(0.8f))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("Effects", fontWeight = FontWeight.SemiBold, color = accentText())
        Row(
            Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Glass blur", fontWeight = FontWeight.SemiBold)
                Text(
                    "Frosted blur behind the navigation bar (Android 12+). Turn off for maximum smoothness on slower phones.",
                    fontSize = 12.sp, color = fg(0.75f)
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = vm.glassBlur, onCheckedChange = { vm.updateGlassBlur(it) })
        }

        Spacer(Modifier.height(22.dp))
        Text("Now Playing", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Cover card size", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("${(vm.cardScale * 100).toInt()}%", color = fg(0.7f))
            }
            Slider(
                value = vm.cardScale, onValueChange = { vm.updateCardScale(it) }, valueRange = 0.8f..1.3f,
                colors = SliderDefaults.colors(thumbColor = accentText(), activeTrackColor = accentText())
            )
            Text("The player controls move up or down by themselves to fit.", fontSize = 12.sp, color = fg(0.65f))

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Background blur", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("${vm.bgBlur}%", color = fg(0.7f))
            }
            Slider(
                value = vm.bgBlur.toFloat(), onValueChange = { vm.updateBgBlur(it.toInt()) }, valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = accentText(), activeTrackColor = accentText())
            )
            Text("Lower = the cover shows more clearly, higher = softer colour wash.", fontSize = 12.sp, color = fg(0.65f))

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Open / close animation speed", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("%.1f×".format(vm.playerAnimSpeed), color = fg(0.7f))
            }
            Slider(
                value = vm.playerAnimSpeed, onValueChange = { vm.updatePlayerAnimSpeed((Math.round(it * 10f) / 10f)) }, valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = accentText(), activeTrackColor = accentText())
            )
            Text("Left = slower and more relaxed, right = quicker.", fontSize = 12.sp, color = fg(0.65f))

            TextButton(onClick = { vm.updateCardScale(1.1f); vm.updateBgBlur(0); vm.updatePlayerAnimSpeed(1f) }, modifier = Modifier.padding(top = 6.dp)) {
                Text("Reset to default", color = accentText())
            }
        }
}

@Composable
private fun NavigationPage(vm: MainViewModel) {
        Text("Navigation bar style", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(8.dp)) {
            BarStyle.values().forEach { st ->
                Row(
                    Modifier.fillMaxWidth()
                        .selectable(selected = vm.barStyle == st, role = Role.RadioButton) { vm.updateBarStyle(st) }
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = vm.barStyle == st, onClick = null,
                        colors = RadioButtonDefaults.colors(selectedColor = fg(), unselectedColor = fg(0.6f))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(st.label)
                        Text(st.desc, fontSize = 12.sp, color = fg(0.7f))
                    }
                }
            }
        }

}

@Composable
private fun QualityCard(selected: AudioQuality, onPick: (AudioQuality) -> Unit) {
    Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(8.dp)) {
        AudioQuality.values().forEach { q ->
            Row(
                Modifier.fillMaxWidth()
                    .selectable(selected = selected == q, role = Role.RadioButton) { onPick(q) }
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selected == q, onClick = null,
                    colors = RadioButtonDefaults.colors(selectedColor = fg(), unselectedColor = fg(0.6f))
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(q.label)
                    Text(q.desc, fontSize = 12.sp, color = fg(0.7f))
                }
            }
        }
    }
}

@Composable
private fun SwitchCard(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, fontSize = 12.sp, color = fg(0.75f))
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun BackupPage(vm: MainViewModel) {
    var pendingRestore by remember { mutableStateOf<android.net.Uri?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.createBackup(uri)
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }
    Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
        Text("Back up", fontWeight = FontWeight.SemiBold)
        Text(
            "Saves your favorites, playlists, history, settings and profile photo into one file. Keep it somewhere safe, " +
                "like Drive, so you can bring everything back on a new phone. Downloaded songs are not inside the file.",
            fontSize = 12.sp, color = fg(0.75f), modifier = Modifier.padding(top = 2.dp)
        )
        Button(
            onClick = {
                val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date())
                saver.launch("FluxAngel-backup-$stamp.json")
            },
            shape = RoundedCornerShape(20.dp), modifier = Modifier.padding(top = 12.dp)
        ) {
            Icon(Icons.Default.Backup, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Create backup")
        }
    }
    Column(Modifier.padding(top = 16.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
        Text("Restore", fontWeight = FontWeight.SemiBold)
        Text(
            "Pick a backup file made by Flux Angel. It replaces what is in the app now, and the app restarts to load it.",
            fontSize = 12.sp, color = fg(0.75f), modifier = Modifier.padding(top = 2.dp)
        )
        OutlinedButton(
            onClick = { opener.launch(arrayOf("application/json", "application/octet-stream", "text/plain", "*/*")) },
            shape = RoundedCornerShape(20.dp), modifier = Modifier.padding(top = 12.dp)
        ) {
            Icon(Icons.Default.Restore, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Restore from file")
        }
    }
    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore this backup?") },
            text = { Text("Your current favorites, playlists, history and settings will be replaced by the backup. The app will restart.") },
            confirmButton = { TextButton(onClick = { pendingRestore = null; vm.restoreBackup(uri) }) { Text("Restore") } },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AudioPage(vm: MainViewModel) {
    Text("Download quality", fontWeight = FontWeight.SemiBold, color = accentText())
    QualityCard(vm.downloadQuality) { vm.updateDownloadQuality(it) }
    Text("Applies to new downloads. Files are saved in Music/Flux Angel.", fontSize = 12.sp, color = fg(0.65f), modifier = Modifier.padding(top = 6.dp, start = 4.dp))

    Spacer(Modifier.height(22.dp))
    Text("Streaming quality", fontWeight = FontWeight.SemiBold, color = accentText())
    QualityCard(vm.streamQuality) { vm.updateStreamQuality(it) }
    Text("For songs you play online. Choose Standard to save mobile data.", fontSize = 12.sp, color = fg(0.65f), modifier = Modifier.padding(top = 6.dp, start = 4.dp))

    Spacer(Modifier.height(22.dp))
    Text("Downloads", fontWeight = FontWeight.SemiBold, color = accentText())
    SwitchCard("Download over Wi-Fi only", "Downloads wait until you are on Wi-Fi", vm.wifiOnly) { vm.updateWifiOnly(it) }
    SwitchCard(
        "Auto-download saved songs",
        "Songs you like or add to a playlist are downloaded automatically (also checked each time the app opens)",
        vm.autoDownload
    ) { vm.updateAutoDownload(it) }
}

@Composable
private fun AboutPage() {
    val uri = LocalUriHandler.current
        Text("Community", fontWeight = FontWeight.SemiBold, color = accentText())
        Button(
            onClick = { uri.openUri(TELEGRAM_URL) },
            modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(26.dp)
        ) {
            Icon(Icons.Default.Send, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Join Telegram")
        }

        Spacer(Modifier.height(22.dp))
        Text("About", fontWeight = FontWeight.SemiBold, color = accentText())
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "" }
            Text("Flux Angel  •  v$version", fontWeight = FontWeight.SemiBold)
            Text("Developer & Credits: Ranweir", color = fg(0.75f))
        }
        Column(
            Modifier.padding(top = 10.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("An app for an Angel", fontWeight = FontWeight.SemiBold, color = fg(0.9f))
        }
}

@Composable
private fun LogsPage() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    var entries by remember { mutableStateOf(AppLog.read()) }
    var expanded by remember { mutableStateOf(setOf<Long>()) }

    Text(
        "Every crash and error (playback, search, download) is saved here automatically. If something goes wrong, copy the log and send it to the developer.",
        fontSize = 13.sp, color = fg(0.75f)
    )
    Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(
            onClick = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(AppLog.exportText(ctx, entries))) },
            enabled = entries.isNotEmpty(), shape = RoundedCornerShape(20.dp)
        ) { Text("Copy all") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(
            onClick = {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(android.content.Intent.EXTRA_TEXT, AppLog.exportText(ctx, entries))
                }
                runCatching { ctx.startActivity(android.content.Intent.createChooser(send, null).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
            },
            enabled = entries.isNotEmpty(), shape = RoundedCornerShape(20.dp)
        ) { Text("Share") }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { AppLog.clear(); entries = emptyList() }, enabled = entries.isNotEmpty()) {
            Text("Clear", color = fg())
        }
    }
    Spacer(Modifier.height(12.dp))
    if (entries.isEmpty()) {
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.CheckCircle, null, Modifier.size(36.dp), tint = accentText())
            Spacer(Modifier.height(8.dp))
            Text("No errors or crashes recorded", fontWeight = FontWeight.SemiBold)
        }
    } else {
        entries.forEach { e ->
            val open = e.time in expanded
            val kindColor = when (e.kind) {
                "CRASH" -> Color(0xFFFF5A5F)
                "PLAYBACK" -> Color(0xFFFFA24A)
                "DOWNLOAD" -> Color(0xFF5AA9FF)
                else -> Color(0xFFB08CFF)
            }
            Column(
                Modifier.padding(bottom = 10.dp).fillMaxWidth().glass(RoundedCornerShape(18.dp))
                    .clickable { expanded = if (open) expanded - e.time else expanded + e.time }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(kindColor.copy(alpha = 0.22f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                        Text(e.kind, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = kindColor)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(AppLog.format(e.time), fontSize = 12.sp, color = fg(0.7f))
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (open) e.text else e.text.lineSequence().first(),
                    fontSize = 12.sp, color = fg(0.9f),
                    maxLines = if (open) Int.MAX_VALUE else 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    fontFamily = if (open) androidx.compose.ui.text.font.FontFamily.Monospace else null
                )
            }
        }
    }
}
