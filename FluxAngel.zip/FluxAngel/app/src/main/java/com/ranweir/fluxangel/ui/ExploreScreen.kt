package com.ranweir.fluxangel.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun ExploreScreen(vm: MainViewModel, onMore: (Song) -> Unit) {
    val focus = LocalFocusManager.current
    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(horizontal = 20.dp)) {
        ScreenTitle("Explore", Modifier.padding(top = 12.dp, bottom = 12.dp))
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp)).padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, null, tint = fg(0.7f))
            TextField(
                value = vm.query, onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search songs, artists...") },
                singleLine = true, colors = fieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search(vm.query); focus.clearFocus() })
            )
            if (vm.query.isNotEmpty()) {
                IconButton(onClick = { vm.query = "" }) { Icon(Icons.Default.Close, "Clear") }
            }
        }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = accentText())
        vm.error?.let {
            Text(
                it, color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(vertical = 8.dp).clickable { vm.dismissError() }
            )
        }
        LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp), contentPadding = PaddingValues(bottom = 16.dp + LocalBottomInset.current)) {
            itemsIndexed(vm.results, contentType = { _, _ -> "song" }) { i, s ->
                SongRow(s, s.url == vm.currentId, onPlay = { vm.play(vm.results, i) }, onMore = { onMore(s) })
            }
        }
    }
}
