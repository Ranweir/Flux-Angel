package com.ranweir.fluxangel

import android.app.Application
import org.schabi.newpipe.extractor.NewPipe

class FluxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NewPipe.init(AppDownloader())
    }
}
