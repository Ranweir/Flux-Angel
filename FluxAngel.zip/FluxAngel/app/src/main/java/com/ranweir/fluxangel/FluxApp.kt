package com.ranweir.fluxangel

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import org.schabi.newpipe.extractor.NewPipe

class FluxApp : Application(), ImageLoaderFactory {
    /** One shared image loader: big memory + disk cache, no fade animation, cheaper bitmaps => smooth scrolling. */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .crossfade(false)
        .allowRgb565(true)
        .respectCacheHeaders(false)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.30).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizePercent(0.02).build() }
        .build()

    override fun onCreate() {
        super.onCreate()
        // save any crash to a file; MainActivity shows it on the next launch
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                java.io.File(filesDir, "crash.txt").writeText(
                    "Flux Angel crash (thread ${t.name})\n" + android.util.Log.getStackTraceString(e)
                )
            }
            previous?.uncaughtException(t, e)
        }
        NewPipe.init(AppDownloader())
    }
}
