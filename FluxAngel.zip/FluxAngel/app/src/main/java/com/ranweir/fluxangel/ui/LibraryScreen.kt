package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun LibraryScreen(
    vm: MainViewModel,
    onOpenPlaylist: (Int) -> Unit,
    onCreate: () -> Unit,
    onMore: (Song) -> Unit
) {
    var section by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("My Library", Modifier.weight(1f))
            IconButton(onClick = onCreate, modifier = Modifier.glass(CircleShape)) { Icon(Icons.Default.Add, "New playlist") }
        }
        Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FluxChip("Playlists", section == 0) { section = 0 }
            FluxChip("Songs", section == 1) { section = 1 }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
            if (section == 0) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp).glass(RoundedCornerShape(20.dp))
                            .clickable(onClick = onCreate).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(46.dp).glass(RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Add, null)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Create New Playlist", fontWeight = FontWeight.SemiBold)
                            Text("Build your own collection", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
                        }
                    }
                }
                item {
                    PlaylistRow("Favorites", vm.favorites, isFavorites = true,
                        onClick = { onOpenPlaylist(-1) }, onPlay = { vm.play(vm.favorites, 0) })
                }
                itemsIndexed(vm.playlists) { i, p ->
                    PlaylistRow(p.name, p.songs, onClick = { onOpenPlaylist(i) },
                        onPlay = { vm.play(p.songs, 0) }, onDelete = { vm.deletePlaylist(i) })
                }
            } else {
                val all = vm.savedSongs()
                if (all.isEmpty()) item {
                    Text("Save songs with the ⋮ menu or the heart button.", color = Color.White.copy(alpha = 0.7f))
                }
                itemsIndexed(all) { i, s ->
                    SongRow(s, s.url == vm.currentId, onPlay = { vm.play(all, i) }, onMore = { onMore(s) })
                }
            }
        }
    }
}

@Composable
private fun PlaylistRow(
    name: String, songs: List<Song>, isFavorites: Boolean = false,
    onClick: () -> Unit, onPlay: () -> Unit, onDelete: (() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).glass(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val thumb = songs.firstOrNull()?.thumb
        if (!thumb.isNullOrBlank()) {
            AsyncImage(
                model = thumb, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(54.dp).clip(RoundedCornerShape(14.dp))
            )
        } else {
            Box(
                Modifier.size(54.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(Accent, Pink))),
                contentAlignment = Alignment.Center
            ) { if (isFavorites) Icon(Icons.Default.Favorite, null) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text("${songs.size} Songs", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
        }
        PlayCircle(onPlay)
        if (onDelete != null) {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { menu = false; onDelete() })
                }
            }
        } else Spacer(Modifier.width(8.dp))
    }
}

/** Playlist / favorites detail page. index == -1 means Favorites. */
@Composable
fun PlaylistScreen(vm: MainViewModel, index: Int, onBack: () -> Unit, onMore: (Song) -> Unit) {
    val name = if (index < 0) "Favorites" else vm.playlists.getOrNull(index)?.name ?: ""
    val songs = if (index < 0) vm.favorites else vm.playlists.getOrNull(index)?.songs ?: emptyList()
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text(name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${songs.size} Songs", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
            }
            if (songs.isNotEmpty()) PlayCircle(onClick = { vm.play(songs, 0) }, size = 44.dp)
        }
        LazyColumn(Modifier.padding(top = 10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (songs.isEmpty()) item {
                Text("Nothing here yet. Use the ⋮ menu on any song to add it.", color = Color.White.copy(alpha = 0.7f))
            }
            itemsIndexed(songs) { i, s ->
                SongRow(s, s.url == vm.currentId, onPlay = { vm.play(songs, i) }, onMore = { onMore(s) })
            }
        }
    }
}
