package com.ranweir.fluxangel

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ranweir.fluxangel.ui.*

enum class Overlay { NONE, PLAYER, SETTINGS, PLAYLIST }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT <= 28) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)
        setContent {
            val crashFile = remember { java.io.File(filesDir, "crash.txt") }
            var crash by remember { mutableStateOf(runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()) }
            if (crash != null) {
                CrashScreen(crash!!) { runCatching { crashFile.delete() }; crash = null }
            } else {
            val dark = when (vm.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                else -> true
            }
            DisposableEffect(dark) {
                val bar = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = bar, navigationBarStyle = bar)
                onDispose {}
            }
            FluxTheme(vm.themeMode) { App(vm) }
            }
        }
    }
}

/** Shown once after a crash so the error text can be copied and shared. Does not touch the ViewModel. */
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
        Column(
            Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF101418))
                .statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            androidx.compose.material3.Text("App crashed last time", color = androidx.compose.ui.graphics.Color.White)
            Row(Modifier.padding(vertical = 10.dp)) {
                androidx.compose.material3.Button(onClick = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(text)) }) {
                    androidx.compose.material3.Text("Copy error")
                }
                Spacer(Modifier.width(10.dp))
                androidx.compose.material3.Button(onClick = onContinue) { androidx.compose.material3.Text("Open app") }
            }
            androidx.compose.material3.Text(
                text, color = androidx.compose.ui.graphics.Color(0xFFFF8A80), fontSize = 11.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                modifier = Modifier.weight(1f).verticalScroll(androidx.compose.foundation.rememberScrollState())
            )
        }
    }
}

@Composable
fun App(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(NavTab.HOME) }
    var overlay by rememberSaveable { mutableStateOf(Overlay.NONE) }
    var playlistIdx by rememberSaveable { mutableStateOf(-1) }
    var dialogSong by remember { mutableStateOf<Song?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    val look = LocalLook.current

    BackHandler(overlay == Overlay.NONE && tab != NavTab.HOME) { tab = NavTab.HOME }
    BackHandler(overlay != Overlay.NONE) { overlay = Overlay.NONE }

    val onMore: (Song) -> Unit = { dialogSong = it }

    val backdrop = remember { BackdropState() }
    Box(Modifier.fillMaxSize().background(look.bg)) {
        val hasMini = vm.currentMeta?.title != null
        val navBottom = vm.navPosition == NavPosition.BOTTOM
        val navInset = if (navBottom) 76.dp else 0.dp
        // everything inside this box is what the glass nav blurs
        Box(Modifier.fillMaxSize().backdropSource(backdrop, vm.glassBlur).background(look.bg)) {
        CompositionLocalProvider(LocalBottomInset provides ((if (hasMini) 92.dp else 0.dp) + navInset)) {
            Box(Modifier.fillMaxSize().navigationBarsPadding()) {
                when (tab) {
                    NavTab.HOME -> HomeScreen(
                        vm,
                        onSettings = { overlay = Overlay.SETTINGS },
                        onOpenSearch = { tab = NavTab.EXPLORE },
                        onLibrary = { tab = NavTab.LIBRARY },
                        onOpenPlaylist = { playlistIdx = it; overlay = Overlay.PLAYLIST },
                        onCategory = { q -> vm.search(q); tab = NavTab.EXPLORE },
                        onMore = onMore
                    )
                    NavTab.EXPLORE -> ExploreScreen(vm, onMore)
                    NavTab.LIBRARY -> LibraryScreen(
                        vm,
                        onOpenPlaylist = { playlistIdx = it; overlay = Overlay.PLAYLIST },
                        onCreate = { showCreate = true },
                        onMore = onMore
                    )
                    NavTab.HISTORY -> HistoryScreen(vm, onMore)
                }
            }
        }
        }
        // floating mini player: sits above the content, which scrolls underneath it
        if (hasMini) {
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp + navInset)) {
                MiniPlayer(vm) { overlay = Overlay.PLAYER }
            }
        }
        // floats above the content, takes no layout space
        SideNav(
            tab, { tab = it }, backdrop, vm.glassBlur, vm.capsuleStyle, vm.navPosition, vm.barStyle,
            when (vm.navPosition) {
                NavPosition.RIGHT -> Modifier.align(Alignment.CenterEnd).padding(end = 10.dp)
                NavPosition.LEFT -> Modifier.align(Alignment.CenterStart).padding(start = 10.dp)
                NavPosition.BOTTOM -> Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)
            }
        )

        if (overlay != Overlay.NONE) {
            Box(Modifier.fillMaxSize().background(look.bg)) {
                when (overlay) {
                    Overlay.PLAYER -> PlayerScreen(
                        vm,
                        onBack = { overlay = Overlay.NONE },
                        onSettings = { overlay = Overlay.SETTINGS },
                        onAddTo = onMore
                    )
                    Overlay.SETTINGS -> SettingsScreen(vm) { overlay = Overlay.NONE }
                    Overlay.PLAYLIST -> PlaylistScreen(vm, playlistIdx, { overlay = Overlay.NONE }, onMore)
                    Overlay.NONE -> {}
                }
            }
        }
    }

    dialogSong?.let { s ->
        AddToDialog(vm, s, onDismiss = { dialogSong = null }, onCreate = { showCreate = true })
    }
    if (showCreate) {
        CreatePlaylistDialog(
            onDismiss = { showCreate = false },
            onCreate = { name ->
                vm.createPlaylist(name)
                dialogSong?.let { vm.togglePlaylistSong(vm.playlists.lastIndex, it) }
                showCreate = false
            }
        )
    }
}
