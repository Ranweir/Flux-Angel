package com.ranweir.fluxangel

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import com.ranweir.fluxangel.ui.*

enum class Overlay { NONE, PLAYER, SETTINGS, PLAYLIST }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT <= 28) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)
        setContent {
            FluxTheme(vm.themeMode) { App(vm) }
        }
    }
}

@Composable
fun App(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(NavTab.HOME) }
    var overlay by rememberSaveable { mutableStateOf(Overlay.NONE) }
    var playlistIdx by rememberSaveable { mutableStateOf(-1) }
    var dialogSong by remember { mutableStateOf<Song?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    val look = LocalLook.current

    BackHandler(overlay == Overlay.NONE && tab != NavTab.HOME) { tab = NavTab.HOME }
    BackHandler(overlay != Overlay.NONE) { overlay = Overlay.NONE }

    val onMore: (Song) -> Unit = { dialogSong = it }

    Box(Modifier.fillMaxSize().background(look.bg)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    NavTab.HOME -> HomeScreen(
                        vm,
                        onSettings = { overlay = Overlay.SETTINGS },
                        onOpenSearch = { tab = NavTab.EXPLORE },
                        onCategory = { q -> vm.search(q); tab = NavTab.EXPLORE },
                        onMore = onMore
                    )
                    NavTab.EXPLORE -> ExploreScreen(vm, onMore)
                    NavTab.LIBRARY -> LibraryScreen(
                        vm,
                        onOpenPlaylist = { playlistIdx = it; overlay = Overlay.PLAYLIST },
                        onCreate = { showCreate = true },
                        onMore = onMore
                    )
                    NavTab.HISTORY -> HistoryScreen(vm, onMore)
                }
            }
            if (vm.currentMeta?.title != null) MiniPlayer(vm) { overlay = Overlay.PLAYER }
            BottomNav(tab) { tab = it }
        }

        if (overlay != Overlay.NONE) {
            Box(Modifier.fillMaxSize().background(look.bg)) {
                when (overlay) {
                    Overlay.PLAYER -> PlayerScreen(
                        vm,
                        onBack = { overlay = Overlay.NONE },
                        onSettings = { overlay = Overlay.SETTINGS },
                        onAddTo = onMore
                    )
                    Overlay.SETTINGS -> SettingsScreen(vm) { overlay = Overlay.NONE }
                    Overlay.PLAYLIST -> PlaylistScreen(vm, playlistIdx, { overlay = Overlay.NONE }, onMore)
                    Overlay.NONE -> {}
                }
            }
        }
    }

    dialogSong?.let { s ->
        AddToDialog(vm, s, onDismiss = { dialogSong = null }, onCreate = { showCreate = true })
    }
    if (showCreate) {
        CreatePlaylistDialog(
            onDismiss = { showCreate = false },
            onCreate = { name ->
                vm.createPlaylist(name)
                dialogSong?.let { vm.togglePlaylistSong(vm.playlists.lastIndex, it) }
                showCreate = false
            }
        )
    }
}
