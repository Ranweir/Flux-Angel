package com.ranweir.fluxangel

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import com.ranweir.fluxangel.ui.*

enum class Screen { HOME, PLAYER, SETTINGS }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent {
            FluxTheme(vm.themeMode) {
                var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
                BackHandler(screen != Screen.HOME) { screen = Screen.HOME }
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        vm,
                        onSettings = { screen = Screen.SETTINGS },
                        onOpenPlayer = { screen = Screen.PLAYER }
                    )
                    Screen.PLAYER -> PlayerScreen(vm, onBack = { screen = Screen.HOME })
                    Screen.SETTINGS -> SettingsScreen(vm, onBack = { screen = Screen.HOME })
                }
            }
        }
    }
}
