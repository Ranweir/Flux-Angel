package com.ranweir.fluxangel

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import com.ranweir.fluxangel.ui.*

enum class Overlay { NONE, PLAYER, SETTINGS, PLAYLIST }

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT <= 28) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)
        setContent {
            val crashFile = remember { java.io.File(filesDir, "crash.txt") }
            var crash by remember { mutableStateOf(runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()) }
            if (crash != null) {
                CrashScreen(crash!!) { runCatching { crashFile.delete() }; crash = null }
            } else {
            val dark = when (vm.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                else -> true
            }
            DisposableEffect(dark) {
                val bar = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = bar, navigationBarStyle = bar)
                onDispose {}
            }
            FluxTheme(vm.themeMode, vm.accent) { App(vm) }
            }
        }
    }
}

/** Shown once after a crash so the error text can be copied and shared. Does not touch the ViewModel. */
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
        Column(
            Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF101418))
                .statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            androidx.compose.material3.Text("App crashed last time", color = androidx.compose.ui.graphics.Color.White)
            Row(Modifier.padding(vertical = 10.dp)) {
                androidx.compose.material3.Button(onClick = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(text)) }) {
                    androidx.compose.material3.Text("Copy error")
                }
                Spacer(Modifier.width(10.dp))
                androidx.compose.material3.Button(onClick = onContinue) { androidx.compose.material3.Text("Open app") }
            }
            // long-press to select and copy only the part you need
            Box(Modifier.weight(1f).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                androidx.compose.foundation.text.selection.SelectionContainer {
                    androidx.compose.material3.Text(
                        text, color = androidx.compose.ui.graphics.Color(0xFFFF8A80), fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun App(vm: MainViewModel) {
    // `tab` is only ever READ inside TabReader / draw lambdas / coroutines, so changing tab never recomposes App or the four heavy pages
    val tabState = rememberSaveable { mutableStateOf(NavTab.HOME) }
    var tab by tabState
    var overlay by rememberSaveable { mutableStateOf(Overlay.NONE) }
    var playlistIdx by rememberSaveable { mutableStateOf(-1) }
    var dialogSong by remember { mutableStateOf<Song?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    val look = LocalLook.current

    // ---- now-playing sheet: one progress value (0 = mini bar, 1 = full player) drives open / drag / close ----
    val scope = rememberCoroutineScope()
    var playerOpen by rememberSaveable { mutableStateOf(false) }
    val playerP = remember { Animatable(if (playerOpen) 1f else 0f) }
    val screenHPx = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val dragRange = screenHPx * 0.5f
    val geo = remember { SheetGeo() }
    val dens = LocalDensity.current
    // relaxed glide; the speed comes from Settings > Appearance > Now Playing (a half-way release takes proportionally less time)
    fun playerSpec(target: Float, baseMs: Int): androidx.compose.animation.core.TweenSpec<Float> {
        val part = kotlin.math.abs(target - playerP.value).coerceIn(0.35f, 1f)
        val ms = (baseMs * part / vm.playerAnimSpeed).toInt().coerceAtLeast(120)
        return androidx.compose.animation.core.tween(ms, easing = androidx.compose.animation.core.FastOutSlowInEasing)
    }
    fun openPlayer(velocity: Float = 0f) {
        playerOpen = true
        scope.launch {
            if (playerP.value <= 0.001f) {
                playerP.snapTo(0.002f)                       // makes the player compose right now ...
                androidx.compose.runtime.withFrameNanos { }  // ... and wait until that heavy first frame is done,
                androidx.compose.runtime.withFrameNanos { }  // so the timed animation doesn't start already behind
            }
            playerP.animateTo(1f, playerSpec(1f, 1300))
        }
    }
    fun closePlayer(velocity: Float = 0f) {
        playerOpen = false
        scope.launch { playerP.animateTo(0f, playerSpec(0f, 1100)) }
    }
    val playerDrag = rememberDraggableState { dy ->
        // dy < 0 = finger moving up = opening
        scope.launch { playerP.snapTo((playerP.value - dy / dragRange).coerceIn(0f, 1f)) }
    }

    TabReader(tabState) { t -> BackHandler(overlay == Overlay.NONE && !playerOpen && t != NavTab.HOME) { tab = NavTab.HOME } }
    // Predictive back: while the back gesture is held, the player / opened page shrinks along with the finger; releasing
    // finishes the close, cancelling springs it back.
    val backP = remember { Animatable(0f) }
    // Settings / playlist pages open and close like an app launch: they zoom up from slightly smaller while fading in, and back out again.
    val ovP = remember { Animatable(0f) }
    var ovShown by remember { mutableStateOf(Overlay.NONE) }
    LaunchedEffect(overlay) {
        if (overlay != Overlay.NONE) {
            ovShown = overlay
            ovP.snapTo(0f)
            ovP.animateTo(1f, tween(360, easing = androidx.compose.animation.core.CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)))
        } else if (ovShown != Overlay.NONE) {
            ovP.animateTo(0f, tween(260, easing = FastOutSlowInEasing))
            ovShown = Overlay.NONE
            backP.snapTo(0f)
        }
    }
    androidx.activity.compose.PredictiveBackHandler(playerOpen && overlay == Overlay.NONE) { progress ->
        try {
            progress.collect { ev -> playerP.snapTo(1f - 0.45f * ev.progress) }
            closePlayer()
        } catch (e: kotlin.coroutines.cancellation.CancellationException) {
            openPlayer()
        }
    }
    androidx.activity.compose.PredictiveBackHandler(overlay != Overlay.NONE) { progress ->
        try {
            progress.collect { ev -> backP.snapTo(ev.progress) }
            overlay = Overlay.NONE   // the exit animation below continues from where the finger left it
        } catch (e: kotlin.coroutines.cancellation.CancellationException) {
            scope.launch { backP.animateTo(0f, tween(180)) }
        }
    }

    val onMore: (Song) -> Unit = { dialogSong = it }

    val backdrop = remember { BackdropState() }
    // page transition state (shared by the page host and the nav bar)
    val tabAnim = remember { Animatable(1f) }
    var shown by remember { mutableStateOf(androidx.compose.runtime.snapshots.Snapshot.withoutReadObservation { tabState.value }) }     // page that is leaving (equals tab when idle)
    var animFor by remember { mutableStateOf(androidx.compose.runtime.snapshots.Snapshot.withoutReadObservation { tabState.value }) }   // tab that tabAnim currently belongs to
    // finger-following scrub between Home and Playlists while the nav pill is being dragged
    var scrubActive by remember { mutableStateOf(false) }
    var scrubDragging by remember { mutableStateOf(false) }   // finger is down on the pill
    val scrubAnim = remember { Animatable(if (androidx.compose.runtime.snapshots.Snapshot.withoutReadObservation { tabState.value } == NavTab.LIBRARY) 1f else 0f) }   // = the pill thumb position
    val uiScope = rememberCoroutineScope()
    var scrubJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    Box(Modifier.fillMaxSize().background(look.bg)) {
        val hasMini = vm.currentMeta?.title != null
        val navInset = 70.dp   // room for the bottom nav bar, so lists and the mini player clear it
        // The mini player and the navigation bar share the bottom edge: while the mini player is on, the nav bar slides away;
        // hold the mini player to hide it (the nav bar returns), swipe the nav bar down to bring the mini player back.
        var miniHidden by rememberSaveable { mutableStateOf(false) }
        val miniOn = hasMini && !miniHidden
        LaunchedEffect(vm.currentMeta?.title) { miniHidden = false }   // a new song brings the mini player back
        val miniVis = remember { Animatable(if (miniOn) 1f else 0f) }
        val navVis = remember { Animatable(if (miniOn) 0f else 1f) }
        LaunchedEffect(miniOn) {
            launch { navVis.animateTo(if (miniOn) 0f else 1f, tween(320, easing = FastOutSlowInEasing)) }
            launch { miniVis.animateTo(if (miniOn) 1f else 0f, tween(320, easing = FastOutSlowInEasing)) }
        }
        val miniShown by remember { derivedStateOf { miniVis.value > 0.01f } }
        // Pre-warm: compose / draw the player once, invisibly and underneath everything, as soon as a song is
        // loaded. Fonts, shadows, images and layout caches are then ready, so the very FIRST open doesn't stutter.
        var warm by remember { mutableStateOf(false) }
        var warmedOnce by remember { mutableStateOf(false) }
        LaunchedEffect(hasMini) {
            if (hasMini && !warmedOnce) {
                kotlinx.coroutines.delay(150)
                warm = true
                kotlinx.coroutines.delay(1200)
                warm = false
                warmedOnce = true
            }
        }
        val showWarm by remember { derivedStateOf { warm && playerP.value <= 0.001f } }
        if (showWarm) {
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = 0f }) {
                PlayerScreen(vm, enter = { 0.01f }, geo = geo, onBack = {}, onSettings = {}, onAddTo = {})
            }
        }
        // everything inside this box is what the glass nav blurs
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { val k = 1f - 0.07f * playerP.value; scaleX = k; scaleY = k; alpha = 1f - 0.35f * playerP.value }
                .backdropSource(backdrop, vm.glassBlur).background(look.bg)
        ) {
        CompositionLocalProvider(LocalBottomInset provides (if (miniOn) 92.dp else navInset)) {
            Box(Modifier.fillMaxSize().navigationBarsPadding()) {
                // Tab change = the same "push" slide as before (new page slides in while the old one slides out, 240 ms),
                // but done with graphicsLayer translations so it runs on the GPU without re-laying-out the heavy pages every
                // frame. The blurred glass is frozen while it moves, so the phone only has to move two layers.
                val tabOrder = { t: NavTab -> when (t) { NavTab.EXPLORE -> 0; NavTab.HOME -> 1; NavTab.LIBRARY -> 2; NavTab.HISTORY -> 3 } }
                LaunchedEffect(Unit) {
                    snapshotFlow { tabState.value }.collectLatest { t ->
                        if (t != shown && !scrubActive) {
                            tabAnim.snapTo(0f)
                            animFor = t
                            // the glass is not frozen: the bar keeps its live blur during the slide
                            tabAnim.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
                            shown = t
                        }
                    }
                }
                // All four tabs are built right at launch and stay composed for as long as the app lives, so switching
                // tabs never has to build a screen: it only moves layers. (Nothing is loaded "later" in the background.)
                val pages = NavTab.values().toList()
                pages.forEach { page -> key(page) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        val shownNow = when {
                            scrubActive -> page == NavTab.HOME || page == NavTab.LIBRARY
                            shown != tab -> page == shown || page == tab
                            else -> page == tab
                        }
                        if (!shownNow) {              // parked off-screen and invisible (still composed, so it is ready instantly)
                            alpha = 0f
                            translationX = size.width * 3f
                        } else if (scrubActive) {
                            // the pages follow the finger: Home at 0, Playlists at 1
                            val pos = scrubAnim.value.coerceIn(0f, 1f)
                            translationX = ((if (page == NavTab.HOME) 0f else 1f) - pos) * size.width
                        } else if (shown != tab) {
                            val p = if (animFor == tab) tabAnim.value else 0f
                            val dir = if (tabOrder(tab) > tabOrder(shown)) 1 else -1
                            translationX = if (page == tab) dir * (1f - p) * size.width else -dir * p * size.width
                        }
                    }
                ) {
                    when (page) {
                        NavTab.HOME -> HomeScreen(
                            vm,
                            onSettings = { overlay = Overlay.SETTINGS },
                            onOpenSearch = { tab = NavTab.EXPLORE },
                            onLibrary = { tab = NavTab.LIBRARY },
                            onOpenPlaylist = { playlistIdx = it; overlay = Overlay.PLAYLIST },
                            onCategory = { q -> vm.search(q); tab = NavTab.EXPLORE },
                            onMore = onMore
                        )
                        NavTab.EXPLORE -> ExploreScreen(vm, onMore)
                        NavTab.LIBRARY -> LibraryScreen(
                            vm,
                            onOpenPlaylist = { playlistIdx = it; overlay = Overlay.PLAYLIST },
                            onCreate = { showCreate = true },
                            onImport = { showImport = true },
                            onMore = onMore
                        )
                        NavTab.HISTORY -> HistoryScreen(vm, onMore)
                    }
                }
                } }
            }
        }
        }
        // bottom blur (progressive, like the system gallery): barely blurred where it starts, more and more blurred towards the bottom edge.
        // Three blurred copies with growing blur radius, each one faded in over its own band of the strip.
        if (backdrop.supported && vm.glassBlur && vm.navBlurOn) {
            val bottomTint = if (look.fg != Color.White) Color(0xFF6F757F).copy(alpha = 0.55f * vm.navFade / 100f) else Color.Transparent
            val maxR = 4 + vm.navBlurStrength * 0.8f
            val bands = listOf(Triple(0.2f, 0f, 0.35f), Triple(0.5f, 0.25f, 0.65f), Triple(1f, 0.5f, 0.95f))
            bands.forEach { (rf, from, to) ->
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(vm.navBlurHeight.dp)
                        .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
                        .backdropBlur(backdrop, (maxR * rf).coerceAtLeast(3f).dp, true)
                        .drawWithContent {
                            drawContent()
                            drawRect(
                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                    0f to Color.Transparent, from to Color.Transparent, to to Color.Black, 1f to Color.Black
                                ),
                                blendMode = androidx.compose.ui.graphics.BlendMode.DstIn
                            )
                        }
                )
            }
            // the gallery's soft grey shade, growing towards the bottom edge
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(vm.navBlurHeight.dp)
                    .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, bottomTint)))
            )
        }
        // floating mini player: sits above the content, which scrolls underneath it
        if (hasMini && miniShown) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)
                    // resting position of the bar (measured before it moves); the album art sits at a fixed spot inside it
                    .onGloballyPositioned {
                        val c = it.positionInWindow() + Offset(it.size.width / 2f, it.size.height / 2f)
                        geo.miniBar = c
                        geo.miniArt = Offset(it.positionInWindow().x + with(dens) { 105.dp.toPx() }, c.y)
                        geo.miniArtSize = with(dens) { 38.dp.toPx() }
                    }
                    // the bar rises towards the control pill while it fades into it
                    .graphicsLayer {
                        val p = playerP.value.coerceIn(0f, 1f)
                        val ready = geo.pill != Offset.Zero && geo.miniBar != Offset.Zero
                        val mv = miniVis.value
                        translationY = (if (ready) (geo.pill.y - geo.miniBar.y) * p else 0f) + (1f - mv) * 90.dp.toPx()
                        alpha = (1f - (p - 0.05f) / 0.45f).coerceIn(0f, 1f) * mv
                    }
                    // swipe the bar upwards: the player follows the finger, then settles open or closed
                    .draggable(
                        state = playerDrag, orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (playerP.value > 0.3f || v < -900f) openPlayer(-v / dragRange) else closePlayer(-v / dragRange)
                        }
                    )
            ) {
                MiniPlayer(vm, backdrop, vm.glassBlur, artAlpha = { if (playerP.value > 0.001f) 0f else 1f }, onHide = { miniHidden = true }) { openPlayer() }
            }
        }
        // floats above the content, takes no layout space
        TabReader(tabState) { tabNow ->
        SideNav(
            tabNow, { tab = it }, backdrop, vm.glassBlur, vm.barStyle,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)
                .graphicsLayer { val v = navVis.value; alpha = v; translationY = (1f - v) * 140.dp.toPx() }
                // swipe the bar downwards to bring the (hidden) mini player back
                .pointerInput(Unit) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onVerticalDrag = { _, dy ->
                            acc += dy
                            if (acc > 28.dp.toPx() && miniHidden && vm.currentMeta?.title != null) { miniHidden = false; acc = -1e9f }
                        }
                    )
                },
            thumb = scrubAnim,
            onScrub = { _ ->
                // pages follow the pill thumb directly (same animated value) - no extra delay of their own
                if (!scrubActive) {
                    shown = tab; animFor = tab
                    scrubActive = true
                    // the glass is NOT frozen while dragging: the bar and the bottom strip keep their live blur
                }
            },
            onScrubEnd = { target ->
                // the thumb (and therefore the pages) has already settled on `target`
                tab = if (target == 0) NavTab.HOME else NavTab.LIBRARY
                shown = tab; animFor = tab
                scrubActive = false
            }
        )
        }

        // read through derivedStateOf so the whole screen is NOT recomposed on every animation frame
        val playerVisible by remember { derivedStateOf { playerP.value > 0.001f } }
        if (playerVisible && hasMini) {
            Box(
                Modifier.fillMaxSize()
                    .draggable(
                        state = playerDrag, orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (playerP.value < 0.7f || v > 1000f) closePlayer(-v / dragRange) else openPlayer(-v / dragRange)
                        }
                    )
            ) {
                PlayerScreen(
                    vm,
                    enter = { playerP.value },
                    geo = geo,
                    onBack = { closePlayer() },
                    onSettings = { overlay = Overlay.SETTINGS },
                    onAddTo = onMore
                )
            }
        }
        if (ovShown != Overlay.NONE) {
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer {
                        val e = ovP.value
                        val p = backP.value
                        val k = (0.88f + 0.12f * e) * (1f - 0.1f * p)
                        scaleX = k; scaleY = k
                        alpha = (e * 1.6f).coerceIn(0f, 1f)
                        translationX = p * 28.dp.toPx()
                        val r = maxOf((1f - e) * 36f, p * 28f)
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(r.dp)
                        clip = r > 0.5f
                    }
                    .background(look.bg)
            ) {
                when (ovShown) {
                    Overlay.PLAYER -> {}
                    Overlay.SETTINGS -> SettingsScreen(vm) { overlay = Overlay.NONE }
                    Overlay.PLAYLIST -> PlaylistScreen(vm, playlistIdx, { overlay = Overlay.NONE }, onMore)
                    Overlay.NONE -> {}
                }
            }
        }
    }

    dialogSong?.let { s ->
        AddToDialog(vm, s, onDismiss = { dialogSong = null }, onCreate = { showCreate = true })
    }
    if (showImport) {
        ImportPlaylistDialog(vm, onDismiss = { showImport = false })
    }
    if (showCreate) {
        CreatePlaylistDialog(
            onDismiss = { showCreate = false },
            onCreate = { name ->
                vm.createPlaylist(name)
                dialogSong?.let { vm.togglePlaylistSong(vm.playlists.lastIndex, it) }
                showCreate = false
            }
        )
    }
}

/** Reads the selected tab inside its own recompose scope, so only this small part recomposes when the tab changes. */
@Composable
private fun TabReader(tab: State<NavTab>, content: @Composable (NavTab) -> Unit) { content(tab.value) }
