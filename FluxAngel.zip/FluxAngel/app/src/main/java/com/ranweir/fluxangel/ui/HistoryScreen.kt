package com.ranweir.fluxangel.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun HistoryScreen(vm: MainViewModel, onMore: (Song) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("History", Modifier.weight(1f))
            if (vm.history.isNotEmpty()) {
                IconButton(onClick = { vm.clearHistory() }, modifier = Modifier.glass(CircleShape)) {
                    Icon(Icons.Default.Delete, "Clear history")
                }
            }
        }
        if (vm.history.isEmpty()) {
            Text("No songs played yet.", color = fg(0.7f))
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
            itemsIndexed(vm.history) { i, s ->
                SongRow(s, s.url == vm.currentId, onPlay = { vm.play(vm.history, i) }, onMore = { onMore(s) })
            }
        }
    }
}
