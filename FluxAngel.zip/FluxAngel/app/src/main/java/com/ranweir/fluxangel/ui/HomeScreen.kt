package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

private data class Category(val name: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val query: String)

private val categories = listOf(
    Category("Pop", Icons.Default.MusicNote, "pop songs"),
    Category("Chill", Icons.Default.Cloud, "chill lofi songs"),
    Category("Workout", Icons.Default.FitnessCenter, "workout gym songs"),
    Category("Party", Icons.Default.Star, "party songs"),
    Category("Focus", Icons.Default.Mic, "focus study music")
)

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onSettings: () -> Unit,
    onOpenSearch: () -> Unit,
    onCategory: (String) -> Unit,
    onMore: (Song) -> Unit
) {
    val hour = remember { java.time.LocalTime.now().hour }
    val greeting = when {
        hour < 12 -> "Good Morning"
        hour < 17 -> "Good Afternoon"
        else -> "Good Evening"
    }
    val recent = vm.history.take(5)
    val pick = vm.trending.firstOrNull()

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greeting, fontSize = 14.sp, color = Color.White.copy(alpha = 0.75f))
                    Text("Flux Angel \uD83D\uDC4B", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onSettings, modifier = Modifier.glass(CircleShape)) {
                    Icon(Icons.Default.Settings, "Settings")
                }
            }
        }
        item {
            Row(
                Modifier.padding(top = 18.dp).fillMaxWidth().glass(RoundedCornerShape(26.dp))
                    .clickable(onClick = onOpenSearch).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = Color.White.copy(alpha = 0.7f))
                Spacer(Modifier.width(10.dp))
                Text("Search songs, artists...", color = Color.White.copy(alpha = 0.6f))
            }
        }
        if (pick != null) {
            item {
                Box(
                    Modifier.padding(top = 18.dp).fillMaxWidth().height(190.dp)
                        .clip(RoundedCornerShape(28.dp)).clickable { vm.play(vm.trending, 0) }
                ) {
                    AsyncImage(
                        model = pick.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                    Box(
                        Modifier.matchParentSize().background(
                            Brush.horizontalGradient(listOf(Color(0xE61B1240), Color(0x331B1240)))
                        )
                    )
                    Column(Modifier.align(Alignment.CenterStart).padding(20.dp).fillMaxWidth(0.7f)) {
                        Text("Today's Pick", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                        Text(
                            pick.title, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            pick.artist, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Spacer(Modifier.height(12.dp))
                        PlayCircle(onClick = { vm.play(vm.trending, 0) }, size = 44.dp)
                    }
                }
            }
        }
        item {
            Text("Categories", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 22.dp))
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                categories.forEach { c ->
                    Column(Modifier.clickable { onCategory(c.query) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(58.dp).glass(CircleShape), contentAlignment = Alignment.Center) {
                            Icon(c.icon, c.name)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(c.name, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            Text("Recently Played", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 22.dp, bottom = 6.dp))
            if (recent.isEmpty()) {
                Text("Songs you play will show up here.", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            }
        }
        itemsIndexed(recent) { i, s ->
            SongRow(s, s.url == vm.currentId, onPlay = { vm.play(recent, i) }, onMore = { onMore(s) })
        }
    }
}
