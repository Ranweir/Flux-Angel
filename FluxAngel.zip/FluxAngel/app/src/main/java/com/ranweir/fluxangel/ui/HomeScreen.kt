package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

private data class Category(val name: String, val query: String)

private val categories = listOf(
    Category("Pop", "pop songs"),
    Category("Chill", "chill lofi songs"),
    Category("Workout", "workout gym songs"),
    Category("Party", "party songs"),
    Category("Focus", "focus study music")
)

private val cardColors = listOf(Lavender, Lime, Peach, Sky)

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onSettings: () -> Unit,
    onOpenSearch: () -> Unit,
    onLibrary: () -> Unit,
    onOpenPlaylist: (Int) -> Unit,
    onCategory: (String) -> Unit,
    onMore: (Song) -> Unit
) {
    val hour = remember { java.time.LocalTime.now().hour }
    val greeting = when {
        hour < 12 -> "Good Morning"
        hour < 17 -> "Good Afternoon"
        else -> "Good Evening"
    }
    val recent = vm.history.take(5)
    val featured = vm.trending.take(5)

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)
    ) {
        // ---- top bar: avatar (opens settings) + search + favorites ----
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Violet, Pink)))
                        .clickable(onClick = onSettings),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Person, "Settings", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onOpenSearch, modifier = Modifier.glass(CircleShape)) { Icon(Icons.Default.Search, "Search") }
                Spacer(Modifier.width(10.dp))
                IconButton(onClick = onLibrary, modifier = Modifier.glass(CircleShape)) { Icon(Icons.Default.FavoriteBorder, "Library") }
            }
        }
        item {
            Text(
                "Hi, $greeting", fontSize = 32.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp)
            )
        }
        // ---- chips ----
        item {
            LazyRow(
                Modifier.padding(top = 14.dp),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { FluxChip("All", true) {} }
                categories.forEach { c -> item { FluxChip(c.name, false) { onCategory(c.query) } } }
            }
        }
        // ---- curated & trending carousel ----
        item {
            Text(
                "Curated & trending", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp)
            )
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(featured) { i, s ->
                    FeaturedCard(vm, s, cardColors[i % cardColors.size],
                        onPlay = { vm.play(vm.trending, i) }, onMore = { onMore(s) })
                }
            }
        }
        // ---- playlists ----
        item {
            SectionHeader(
                "Your playlists", Modifier.padding(start = 20.dp, end = 20.dp, top = 26.dp, bottom = 6.dp),
                action = "See all", onAction = onLibrary
            )
        }
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                PlaylistRow("Favorites", vm.favorites, isFavorites = true,
                    onClick = { onOpenPlaylist(-1) }, onPlay = { vm.play(vm.favorites, 0) })
                PlaylistRow("Downloads", vm.downloads.map { it.song }, isDownloads = true,
                    onClick = { onOpenPlaylist(-2) }, onPlay = { vm.play(vm.downloads.map { it.song }, 0) })
                vm.playlists.take(3).forEachIndexed { i, p ->
                    PlaylistRow(p.name, p.songs, onClick = { onOpenPlaylist(i) }, onPlay = { vm.play(p.songs, 0) })
                }
            }
        }
        // ---- recently played ----
        item {
            SectionHeader(
                "Recently played", Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 6.dp)
            )
            if (recent.isEmpty()) {
                Text(
                    "Songs you play will show up here.", color = Color.White.copy(alpha = 0.6f),
                    fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp)
                )
            }
        }
        itemsIndexed(recent) { i, s ->
            Box(Modifier.padding(horizontal = 20.dp)) {
                SongRow(s, s.url == vm.currentId, onPlay = { vm.play(recent, i) }, onMore = { onMore(s) })
            }
        }
    }
}

/** Big pastel card: title + actions on the left, cover peeking from the bottom-right. */
@Composable
private fun FeaturedCard(vm: MainViewModel, song: Song, color: Color, onPlay: () -> Unit, onMore: () -> Unit) {
    val fav = vm.isFavorite(song.url)
    Box(
        Modifier.width(310.dp).height(176.dp).clip(RoundedCornerShape(30.dp))
            .background(color).clickable(onClick = onPlay)
    ) {
        AsyncImage(
            model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.align(Alignment.BottomEnd).size(width = 128.dp, height = 150.dp)
                .clip(RoundedCornerShape(topStart = 40.dp))
        )
        Column(Modifier.fillMaxHeight().fillMaxWidth(0.62f).padding(start = 20.dp, top = 18.dp, bottom = 14.dp)) {
            Text(
                song.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(
                song.artist, fontSize = 12.sp, color = Ink.copy(alpha = 0.7f),
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp)
            )
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                PlayCircle(onPlay, size = 46.dp, container = Ink, tint = Color.White)
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = { vm.toggleFavorite(song) }, modifier = Modifier.size(34.dp)) {
                    Icon(
                        if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite",
                        tint = Ink, modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(onClick = onMore, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.MoreHoriz, "More", tint = Ink, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
