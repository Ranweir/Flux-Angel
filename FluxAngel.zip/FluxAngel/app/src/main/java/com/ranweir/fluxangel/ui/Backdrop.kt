package com.ranweir.fluxangel.ui

import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.draw
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp

/**
 * Real "frosted glass" backdrop blur (Android 12+).
 *
 * The screen content is recorded once into a RenderNode ([backdropSource]); a glass surface
 * ([backdropBlur]) replays that same node, blurred by the GPU, clipped to its own shape. Nothing is
 * composed twice, and the blurred copy follows scrolling automatically because it references the
 * live node. On older Android versions [supported] is false and callers use a plain frosted fill.
 */
class BackdropState {
    val supported: Boolean = Build.VERSION.SDK_INT >= 31
    internal val source: Any? = if (supported) RenderNode("flux-backdrop") else null
    var origin by mutableStateOf(Offset.Zero)
}

fun Modifier.backdropSource(state: BackdropState, enabled: Boolean = true): Modifier {
    if (!state.supported || !enabled) return this
    return this
        .onGloballyPositioned { state.origin = it.positionInWindow() }
        .drawWithContent {
            var hw = false
            drawIntoCanvas { hw = it.nativeCanvas.isHardwareAccelerated }
            if (hw) recordSource(state.source as RenderNode) else drawContent()
        }
}

@RequiresApi(31)
private fun ContentDrawScope.recordSource(node: RenderNode) {
    node.setPosition(0, 0, size.width.toInt(), size.height.toInt())
    val rec = node.beginRecording()
    try {
        draw(this, layoutDirection, Canvas(rec), size) { this@recordSource.drawContent() }
    } finally {
        node.endRecording()
    }
    drawIntoCanvas { it.nativeCanvas.drawRenderNode(node) }
}

/** Draws a blurred copy of the [backdropSource] content behind this modifier. Put it right after `.clip(shape)`. */
@Composable
fun Modifier.backdropBlur(state: BackdropState, blurRadius: Dp, enabled: Boolean = true): Modifier {
    if (!state.supported || !enabled) return this
    val radiusPx = with(LocalDensity.current) { blurRadius.toPx() }
    val blurNode = remember(state) { RenderNode("flux-blur") }
    var pos by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { pos = it.positionInWindow() }
        .drawBehind { drawBlurred(state.source as RenderNode, blurNode, pos - state.origin, radiusPx) }
}

@RequiresApi(31)
private fun DrawScope.drawBlurred(src: RenderNode, dst: RenderNode, offset: Offset, radius: Float) {
    var hw = false
    drawIntoCanvas { hw = it.nativeCanvas.isHardwareAccelerated }
    if (!hw) return
    val pad = (radius * 2f).toInt()
    dst.setPosition(-pad, -pad, size.width.toInt() + pad, size.height.toInt() + pad)
    dst.setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP))
    val rec = dst.beginRecording()
    try {
        rec.translate(pad - offset.x, pad - offset.y)
        rec.drawRenderNode(src)
    } finally {
        dst.endRecording()
    }
    drawIntoCanvas { it.nativeCanvas.drawRenderNode(dst) }
}
