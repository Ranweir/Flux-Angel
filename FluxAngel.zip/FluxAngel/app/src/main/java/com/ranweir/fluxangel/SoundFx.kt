package com.ranweir.fluxangel

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Sound effects (equalizer, bass boost, surround, loudness) built on Android's standard audio-effect classes, attached to
 * the player's audio session. Every effect is optional: phones differ in what they allow, so each one is probed first, and
 * anything unsupported is simply hidden. Nothing here can crash playback (all effect calls are guarded).
 *
 * Dolby Atmos itself is a licensed feature of the phone's own audio system; apps cannot switch it on. What this class does
 * is announce the player's audio session (the standard way) so that the phone's system effects, Dolby included, can attach
 * to it, and it offers a shortcut to the phone's own sound settings ([openSystemPanel]).
 */
object SoundFx {
    class Info(
        val eq: Boolean, val bands: Int, val centerHz: List<Int>, val minMb: Int, val maxMb: Int, val presets: List<String>,
        val bass: Boolean, val surround: Boolean, val loud: Boolean
    ) {
        val anything get() = eq || bass || surround || loud
    }

    var enabled by mutableStateOf(false); private set
    var preset by mutableIntStateOf(-1); private set            // -1 = custom
    val bandLevels = mutableStateListOf<Int>()                  // millibels per band
    var bass by mutableIntStateOf(0); private set               // 0..1000
    var surround by mutableIntStateOf(0); private set           // 0..1000
    var loud by mutableIntStateOf(0); private set               // 0..1000 (millibels of extra gain)
    var info by mutableStateOf<Info?>(null); private set

    private var prefs: android.content.SharedPreferences? = null
    private var appCtx: Context? = null
    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var vz: Virtualizer? = null
    private var le: LoudnessEnhancer? = null
    private var session = 0

    private inline fun <T> safe(block: () -> T): T? = try { block() } catch (_: Throwable) { null }

    fun init(ctx: Context) {
        if (appCtx != null) return
        appCtx = ctx.applicationContext
        prefs = appCtx!!.getSharedPreferences("flux", Context.MODE_PRIVATE)
        probe()
        load()
    }

    /** Asks the phone what it supports, using a throw-away audio session (nothing is heard, nothing is left running). */
    private fun probe() {
        val am = appCtx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val sid = safe { am?.generateAudioSessionId() } ?: -1
        if (sid <= 0) { info = Info(false, 0, emptyList(), 0, 0, emptyList(), false, false, false); return }
        var eqOk = false; var n = 0; var freqs = emptyList<Int>(); var lo = 0; var hi = 0; var names = emptyList<String>()
        safe {
            val e = Equalizer(0, sid)
            n = e.numberOfBands.toInt()
            freqs = (0 until n).map { e.getCenterFreq(it.toShort()) / 1000 }
            lo = e.bandLevelRange[0].toInt(); hi = e.bandLevelRange[1].toInt()
            names = (0 until e.numberOfPresets).map { e.getPresetName(it.toShort()) }
            eqOk = n > 0 && hi > lo
            e.release()
        }
        val bassOk = safe { val b = BassBoost(0, sid); val ok = b.strengthSupported; b.release(); ok } ?: false
        val surroundOk = safe { val v = Virtualizer(0, sid); val ok = v.strengthSupported; v.release(); ok } ?: false
        val loudOk = safe { val l = LoudnessEnhancer(sid); l.release(); true } ?: false
        info = Info(eqOk, n, freqs, lo, hi, names, bassOk, surroundOk, loudOk)
    }

    private fun load() {
        val p = prefs ?: return
        enabled = p.getBoolean("fx_on", false)
        preset = p.getInt("fx_preset", -1)
        bass = p.getInt("fx_bass", 0).coerceIn(0, 1000)
        surround = p.getInt("fx_surround", 0).coerceIn(0, 1000)
        loud = p.getInt("fx_loud", 0).coerceIn(0, 1000)
        val n = info?.bands ?: 0
        val saved = p.getString("fx_bands", "")!!.split(",").mapNotNull { it.toIntOrNull() }
        bandLevels.clear()
        for (i in 0 until n) bandLevels.add(saved.getOrNull(i)?.coerceIn(info!!.minMb, info!!.maxMb) ?: 0)
    }

    private fun save() {
        prefs?.edit()
            ?.putBoolean("fx_on", enabled)?.putInt("fx_preset", preset)?.putInt("fx_bass", bass)
            ?.putInt("fx_surround", surround)?.putInt("fx_loud", loud)
            ?.putString("fx_bands", bandLevels.joinToString(","))?.apply()
    }

    // ---------- attached to the player ----------

    /** Called by the music service whenever the player's audio session id is known or changes. */
    fun attach(ctx: Context, sessionId: Int) {
        init(ctx)
        detach()
        if (sessionId <= 0) return
        session = sessionId
        // standard announcement: lets the phone's own effects (Dolby etc.) attach to this player
        safe {
            ctx.sendBroadcast(
                Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                    .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                    .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.packageName)
                    .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            )
        }
        val i = info
        if (i?.eq == true) eq = safe { Equalizer(0, sessionId) }
        if (i?.bass == true) bb = safe { BassBoost(0, sessionId) }
        if (i?.surround == true) vz = safe { Virtualizer(0, sessionId) }
        if (i?.loud == true) le = safe { LoudnessEnhancer(sessionId) }
        apply()
    }

    fun detach() {
        val ctx = appCtx
        if (session > 0 && ctx != null) {
            val s = session
            safe {
                ctx.sendBroadcast(
                    Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
                        .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, s)
                        .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.packageName)
                )
            }
        }
        safe { eq?.release() }; safe { bb?.release() }; safe { vz?.release() }; safe { le?.release() }
        eq = null; bb = null; vz = null; le = null; session = 0
    }

    private fun apply() {
        val i = info ?: return
        eq?.let { e ->
            safe {
                e.setEnabled(enabled)
                if (enabled) for (b in 0 until minOf(i.bands, bandLevels.size)) e.setBandLevel(b.toShort(), bandLevels[b].toShort())
            }
        }
        bb?.let { b -> safe { val on = enabled && bass > 0; b.setEnabled(on); if (on) b.setStrength(bass.toShort()) } }
        vz?.let { v -> safe { val on = enabled && surround > 0; v.setEnabled(on); if (on) v.setStrength(surround.toShort()) } }
        le?.let { l -> safe { val on = enabled && loud > 0; l.setEnabled(on); if (on) l.setTargetGain(loud) } }
    }

    // ---------- settings screen actions ----------

    fun updateEnabled(on: Boolean) { enabled = on; save(); apply() }

    fun setBand(index: Int, millibels: Int) {
        val i = info ?: return
        if (index !in bandLevels.indices) return
        bandLevels[index] = millibels.coerceIn(i.minMb, i.maxMb)
        preset = -1
        save(); apply()
    }

    /** Loads a preset's band levels from the phone (via a throw-away session, so it also works while nothing is playing). */
    fun choosePreset(index: Int) {
        val i = info ?: return
        val am = appCtx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val sid = safe { am?.generateAudioSessionId() } ?: return
        safe {
            val e = Equalizer(0, sid)
            e.usePreset(index.toShort())
            for (b in 0 until minOf(i.bands, bandLevels.size)) bandLevels[b] = e.getBandLevel(b.toShort()).toInt()
            e.release()
        }
        preset = index
        save(); apply()
    }

    fun updateBass(v: Int) { bass = v.coerceIn(0, 1000); save(); apply() }
    fun updateSurround(v: Int) { surround = v.coerceIn(0, 1000); save(); apply() }
    fun updateLoud(v: Int) { loud = v.coerceIn(0, 1000); save(); apply() }

    fun reset() {
        for (b in bandLevels.indices) bandLevels[b] = 0
        preset = -1; bass = 0; surround = 0; loud = 0
        save(); apply()
    }

    /** Opens the phone's own sound-effect screen (Dolby Atmos, Samsung SoundAlive, etc.) when it has one. */
    fun openSystemPanel(ctx: Context): Boolean {
        val panel = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, session)
            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.packageName)
            .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (safe { panel.resolveActivity(ctx.packageManager) } != null && safe { ctx.startActivity(panel); true } == true) return true
        val sound = Intent(android.provider.Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return safe { ctx.startActivity(sound); true } == true
    }
}
