package com.ranweir.fluxangel.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun PlayerScreen(vm: MainViewModel, onBack: () -> Unit, onSettings: () -> Unit, onAddTo: (Song) -> Unit) {
    val ctx = LocalContext.current
    val song = vm.currentSong()
    val fav = song?.let { vm.isFavorite(it.url) } == true
    val downloaded = song?.let { vm.isDownloaded(it.url) } == true

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ---- header: close · title · favourite ----
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.glass(CircleShape)) {
                Icon(Icons.Default.KeyboardArrowDown, "Close", Modifier.size(28.dp))
            }
            Text(
                "Now Playing", fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = { song?.let { vm.toggleFavorite(it) } },
                modifier = Modifier.glass(CircleShape)
            ) {
                Icon(
                    if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite",
                    tint = if (fav) Pink else fg()
                )
            }
        }
        Spacer(Modifier.height(26.dp))

        // ---- round cover with a soft ring ----
        Box(
            Modifier.fillMaxWidth(0.82f).aspectRatio(1f).clip(CircleShape)
                .background(fg(0.06f)).padding(10.dp)
        ) {
            AsyncImage(
                model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().clip(CircleShape).border(2.dp, accentText().copy(alpha = 0.5f), CircleShape)
            )
        }
        Spacer(Modifier.height(26.dp))

        Text(
            vm.currentMeta?.title?.toString() ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
        Text(
            vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = fg(0.65f), modifier = Modifier.padding(top = 4.dp)
        )
        Spacer(Modifier.height(18.dp))

        var dragging by remember { mutableStateOf<Float?>(null) }
        val dur = vm.duration.coerceAtLeast(1L).toFloat()
        Slider(
            value = (dragging ?: vm.position.toFloat()).coerceIn(0f, dur),
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.seekTo(it.toLong()) }
                dragging = null
            },
            valueRange = 0f..dur,
            colors = SliderDefaults.colors(
                thumbColor = accentText(), activeTrackColor = accentText(),
                inactiveTrackColor = fg(0.2f)
            )
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime((dragging ?: vm.position.toFloat()).toLong()), fontSize = 12.sp, color = fg(0.65f))
            Text(formatTime(vm.duration), fontSize = 12.sp, color = fg(0.65f))
        }
        Spacer(Modifier.height(12.dp))

        // ---- transport controls ----
        Row(
            Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (vm.shuffle) accentText() else fg())
            }
            IconButton(onClick = { vm.previous() }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(34.dp))
            }
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(Cyan).clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                if (vm.buffering) CircularProgressIndicator(Modifier.size(30.dp), strokeWidth = 3.dp, color = Ink)
                else Icon(
                    if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "Play/Pause", Modifier.size(42.dp), tint = Ink
                )
            }
            IconButton(onClick = { vm.next() }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.SkipNext, "Next", Modifier.size(34.dp))
            }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    "Repeat",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) fg() else accentText()
                )
            }
        }
        Spacer(Modifier.height(24.dp))

        // ---- actions ----
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { song?.let(onAddTo) }) { Icon(Icons.Default.Add, "Add to playlist") }
            IconButton(onClick = { song?.let { vm.download(it) } }) {
                Icon(
                    if (downloaded) Icons.Default.DownloadDone else Icons.Default.FileDownload, "Download",
                    tint = if (downloaded) accentText() else fg()
                )
            }
            IconButton(onClick = {
                song?.let {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, it.url)
                    }
                    ctx.startActivity(Intent.createChooser(i, "Share"))
                }
            }) { Icon(Icons.Default.Share, "Share") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
        }
        vm.error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}
