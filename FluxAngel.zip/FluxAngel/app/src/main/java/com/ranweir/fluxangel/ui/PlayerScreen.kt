package com.ranweir.fluxangel.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun PlayerScreen(vm: MainViewModel, onBack: () -> Unit, onSettings: () -> Unit, onAddTo: (Song) -> Unit) {
    val ctx = LocalContext.current
    val song = vm.currentSong()
    val fav = song?.let { vm.isFavorite(it.url) } == true

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.KeyboardArrowDown, "Close", Modifier.size(30.dp)) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Now Playing", fontWeight = FontWeight.SemiBold)
                Text("Flux Angel", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
            }
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(16.dp))
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f).glass(RoundedCornerShape(32.dp))
        )
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    vm.currentMeta?.title?.toString() ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = Color.White.copy(alpha = 0.75f)
                )
            }
            Spacer(Modifier.width(12.dp))
            IconButton(
                onClick = { song?.let { vm.toggleFavorite(it) } },
                modifier = Modifier.glass(CircleShape)
            ) {
                Icon(
                    if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite",
                    tint = if (fav) Pink else Color.White
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        var dragging by remember { mutableStateOf<Float?>(null) }
        val dur = vm.duration.coerceAtLeast(1L).toFloat()
        Slider(
            value = (dragging ?: vm.position.toFloat()).coerceIn(0f, dur),
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.seekTo(it.toLong()) }
                dragging = null
            },
            valueRange = 0f..dur,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Pink,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f)
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime((dragging ?: vm.position.toFloat()).toLong()), fontSize = 12.sp)
            Text(formatTime(vm.duration), fontSize = 12.sp)
        }
        Spacer(Modifier.height(14.dp))

        Row(
            Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (vm.shuffle) Highlight else Color.White)
            }
            IconButton(onClick = { vm.previous() }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(34.dp))
            }
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                if (vm.buffering) CircularProgressIndicator(Modifier.size(30.dp), strokeWidth = 3.dp, color = Accent)
                else Icon(
                    if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "Play/Pause", Modifier.size(40.dp), tint = Accent
                )
            }
            IconButton(onClick = { vm.next() }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.SkipNext, "Next", Modifier.size(34.dp))
            }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    "Repeat",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) Color.White else Highlight
                )
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { song?.let(onAddTo) }) { Icon(Icons.Default.Add, "Add to playlist") }
            IconButton(onClick = {
                song?.let {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, it.url)
                    }
                    ctx.startActivity(Intent.createChooser(i, "Share"))
                }
            }) { Icon(Icons.Default.Share, "Share") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
        }
        vm.error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}
