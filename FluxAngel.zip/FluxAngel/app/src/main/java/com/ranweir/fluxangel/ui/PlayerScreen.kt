package com.ranweir.fluxangel.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/*
 * Now Playing page, built to match the silver "frosted glass cover-flow" reference design:
 *   the cover itself, blurred, as the background (+ film grain), 5 glass cards (centre one big),
 *   a long pill bar (shuffle, previous, mini track + progress, equaliser, downloaded, cast, volume)
 *   and the big rewind / pause / forward row with the split volume line.
 * All sizes are measured from the reference image (736 px wide) and scaled with [u] = screen width / 736.
 */

private val SilverTop = Color(0xFF8D8D8F)
private val SilverMid = Color(0xFF9B9B9D)
private val SilverLow = Color(0xFF7C7C7E)
private val SilverBottom = Color(0xFF707072)
private val CheckGreen = Color(0xFF1ED760)

@Composable
fun PlayerScreen(vm: MainViewModel, onBack: () -> Unit, onSettings: () -> Unit, onAddTo: (Song) -> Unit) {
    val ctx = LocalContext.current
    val song = vm.currentSong()
    val fav = song?.let { vm.isFavorite(it.url) } == true
    val downloaded = song?.let { vm.isDownloaded(it.url) } == true
    var showMore by remember { mutableStateOf(false) }
    BackHandler(showMore) { showMore = false }

    // ---- system music volume (drives the split line under the pill) ----
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var volTouch by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            if (!volTouch) vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol
            delay(500)
        }
    }
    val setVol: (Float) -> Unit = { f ->
        volTouch = true
        vol = f.coerceIn(0f, 1f)
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (vol * maxVol).roundToInt(), 0) }
    }
    val volDone: () -> Unit = { volTouch = false }

    // seek preview while the pill progress line is being dragged
    val seekState = remember { mutableStateOf<Float?>(null) }

    val silver = remember {
        Brush.verticalGradient(0f to SilverTop, 0.4f to SilverMid, 0.75f to SilverLow, 1f to SilverBottom)
    }
    val grain = remember {
        val s = 160
        val rnd = java.util.Random(7L)
        val px = IntArray(s * s)
        for (i in px.indices) {
            val v = rnd.nextInt(256)
            val a = rnd.nextInt(70)
            px[i] = (a shl 24) or (v shl 16) or (v shl 8) or v
        }
        val bmp = android.graphics.Bitmap.createBitmap(px, s, s, android.graphics.Bitmap.Config.ARGB_8888)
        ShaderBrush(ImageShader(bmp.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
    }

    val shareSong: () -> Unit = {
        song?.let {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, it.url)
            }
            ctx.startActivity(Intent.createChooser(i, "Share"))
        }
    }

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        BoxWithConstraints(
            Modifier.fillMaxSize().pointerInput(Unit) {
                // swipe down anywhere to close the player (there is no header button in this design)
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, d -> total += d },
                    onDragEnd = { if (total > 140.dp.toPx()) onBack() },
                    onDragCancel = { }
                )
            }
        ) {
            val sw = maxWidth
            val sh = maxHeight

            // ---- background = the current cover itself, blurred (colours follow the song) ----
            Box(Modifier.fillMaxSize().background(Color(0xFF3A3A3C))) {
                Crossfade(targetState = vm.currentMeta?.artworkUri, animationSpec = tween(700), label = "bgArt") { uri ->
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(uri).size(96).build(),
                        contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().blur(60.dp)
                    )
                }
                // soft veil: keeps the white text readable on bright covers and adds the frosted look
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(0.10f), Color.Black.copy(0.10f), Color.Black.copy(0.28f))
                        )
                    )
                }
            }

            // ---- main block, centred on the screen ----
            val u = minOf(sw / 736f, (sh - 40.dp) / 700f)
            Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    RefCarousel(vm, u, onMore = { showMore = true })
                    Spacer(Modifier.height(u * 18f))
                    RefPill(
                        vm = vm, u = u, downloaded = downloaded, seekState = seekState,
                        onMore = { showMore = true },
                        onDownload = {
                            song?.let {
                                if (downloaded) Toast.makeText(ctx, "Already downloaded", Toast.LENGTH_SHORT).show()
                                else vm.download(it)
                            }
                        },
                        onCast = {
                            runCatching { ctx.startActivity(Intent(android.provider.Settings.ACTION_CAST_SETTINGS)) }
                        },
                        onVolumeIcon = {
                            runCatching { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI) }
                        }
                    )
                    Spacer(Modifier.height(u * 24f))
                    RefControls(vm, u, vol, onVolChange = setVol, onVolDone = volDone)
                }
            }

            // ---- film grain over everything (never takes touches) ----
            Canvas(Modifier.fillMaxSize()) { drawRect(grain, alpha = 0.6f) }

            vm.error?.let {
                Text(
                    it, color = Color(0xFFFFB4AB), fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(16.dp)
                )
            }

            // ---- "more" sheet: favourite, add to playlist, share, repeat, settings ----
            AnimatedVisibility(visible = showMore, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f)).tap { showMore = false })
            }
            AnimatedVisibility(
                visible = showMore, modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                        .background(Color(0xFF2C2C2E))
                        .navigationBarsPadding().padding(top = 10.dp, bottom = 10.dp)
                ) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).padding(bottom = 6.dp)
                            .size(36.dp, 4.dp).clip(CircleShape).background(Color.White.copy(0.3f))
                    )
                    SheetRow(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (fav) "Remove from favourites" else "Add to favourites",
                        if (fav) Pink else Color.White
                    ) { song?.let { vm.toggleFavorite(it) }; showMore = false }
                    SheetRow(Icons.Rounded.PlaylistAdd, "Add to playlist") { showMore = false; song?.let(onAddTo) }
                    SheetRow(Icons.Rounded.Share, "Share") { showMore = false; shareSong() }
                    SheetRow(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (vm.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Repeat: one song"
                            Player.REPEAT_MODE_ALL -> "Repeat: all"
                            else -> "Repeat: off"
                        },
                        if (vm.repeatMode == Player.REPEAT_MODE_OFF) Color.White else LocalLook.current.accentFill
                    ) { vm.cycleRepeat() }
                    SheetRow(Icons.Rounded.Settings, "Settings") { showMore = false; onSettings() }
                }
            }
        }
    }
}

// ───────────────────────────── helpers ─────────────────────────────

/** Positions a box by its centre (cx, cy) and size, all in reference pixels scaled by [u]. */
private fun Modifier.at(u: Dp, cx: Float, cy: Float, w: Float, h: Float): Modifier =
    this.offset(x = u * (cx - w / 2f), y = u * (cy - h / 2f)).size(u * w, u * h)

/** Click without the ripple (the design has none). */
@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }

@Composable
private fun SheetRow(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tap(onClick).padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = Color.White, fontSize = 15.sp)
    }
}

// carousel geometry: how far, how small and how dark the cards get with distance from the centre
private fun cfDisp(a: Float): Float = when {
    a <= 1f -> 0.37f * a
    a <= 2f -> 0.37f + 0.33f * (a - 1f)
    else -> 0.70f + 0.16f * (a - 2f)
}

private fun cfScale(a: Float): Float = when {
    a <= 1f -> 1f - 0.12f * a
    a <= 2f -> 0.88f - 0.09f * (a - 1f)
    else -> 0.79f - 0.06f * (a - 2f)
}

private fun cfDim(a: Float): Float = when {
    a <= 1f -> 0.15f * a
    a <= 2f -> 0.15f + 0.11f * (a - 1f)
    else -> 0.26f + 0.10f * (a - 2f).coerceAtMost(1f)
}

// ───────────────────────────── cover-flow ─────────────────────────────

@Composable
private fun RefCarousel(vm: MainViewModel, u: Dp, onMore: () -> Unit) {
    val queue = vm.queue
    val n = queue.size
    val last = maxOf(n - 1, 0)
    val cardW = u * 312f
    val scope = rememberCoroutineScope()
    val density = androidx.compose.ui.platform.LocalDensity.current
    val slotPx = with(density) { (cardW * 0.37f).toPx() }

    val pos = remember { Animatable(vm.currentIndex.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    var pending by remember { mutableIntStateOf(-1) }   // index requested by a swipe, not yet confirmed by the player

    // player -> carousel (next/previous buttons, auto advance)
    LaunchedEffect(vm.currentIndex, n) {
        if (pending != -1) {
            if (vm.currentIndex == pending) pending = -1 else return@LaunchedEffect
        }
        val t = vm.currentIndex.coerceIn(0, last).toFloat()
        if (!dragging && abs(pos.value - t) > 0.001f) {
            pos.animateTo(t, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow))
        }
    }

    val select: (Int) -> Unit = { t ->
        if (n > 0) {
            val target = t.coerceIn(0, last)
            if (target != vm.currentIndex) { pending = target; vm.skipTo(target) }
            scope.launch { pos.animateTo(target.toFloat(), spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) }
        }
    }

    val dragState = rememberDraggableState { delta ->
        scope.launch { pos.snapTo((pos.value - delta / slotPx).coerceIn(0f, last.toFloat())) }
    }

    val center by remember { derivedStateOf { pos.value.roundToInt().coerceIn(0, last) } }
    val lo = maxOf(center - 3, 0)
    val hi = minOf(center + 3, last)
    val order = if (n == 0) emptyList() else (lo..hi).sortedByDescending { abs(it - center) }   // far cards first, centre card on top

    Box(
        Modifier.fillMaxWidth().height(u * 460f)
            .draggable(
                state = dragState, orientation = Orientation.Horizontal,
                onDragStarted = { dragging = true },
                onDragStopped = { velocity ->
                    dragging = false
                    if (n > 0) {
                        val extra = (-velocity / slotPx * 0.2f).roundToInt().coerceIn(-1, 1)
                        val target = (pos.value.roundToInt() + extra).coerceIn(0, last)
                        if (target != vm.currentIndex) { pending = target; vm.skipTo(target) }
                        pos.animateTo(target.toFloat(), spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow))
                    }
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        order.forEach { i ->
            key(i) {
                val s = queue.getOrNull(i)
                CoverCard(
                    index = i, posProvider = { pos.value }, cardW = cardW,
                    art = s?.thumb?.takeIf { it.isNotBlank() } ?: vm.currentMeta?.artworkUri,
                    title = s?.title ?: vm.currentMeta?.title?.toString() ?: "",
                    artist = s?.artist ?: vm.currentMeta?.artist?.toString() ?: "",
                    isCenter = i == center, playing = vm.isPlaying,
                    onTap = { if (i != center) select(i) },
                    onLong = onMore, onWave = onMore
                )
            }
        }
        if (n == 0) {
            CoverCard(
                index = 0, posProvider = { 0f }, cardW = cardW, art = vm.currentMeta?.artworkUri,
                title = vm.currentMeta?.title?.toString() ?: "", artist = vm.currentMeta?.artist?.toString() ?: "",
                isCenter = true, playing = vm.isPlaying, onTap = {}, onLong = onMore, onWave = onMore
            )
        }
    }
}

@Composable
private fun CoverCard(
    index: Int, posProvider: () -> Float, cardW: Dp, art: Any?, title: String, artist: String,
    isCenter: Boolean, playing: Boolean, onTap: () -> Unit, onLong: () -> Unit, onWave: () -> Unit
) {
    val shape = RoundedCornerShape(cardW * 0.10f)
    Box(
        Modifier.width(cardW).height(cardW * 1.4f)
            .graphicsLayer {
                val o = index - posProvider()          // 0 centred, negative = left, positive = right
                val a = abs(o)
                val d = cfDisp(a)
                translationX = (if (o < 0f) -d else d) * size.width
                val sc = cfScale(a)
                scaleX = sc; scaleY = sc
                // side cards lean towards the centre: the edge nearer the middle goes further away
                val tilt = when {
                    a <= 1f -> 34f * a
                    a <= 2f -> 34f + 10f * (a - 1f)
                    else -> 44f + 6f * (a - 2f)
                }.coerceAtMost(52f)
                rotationY = if (o < 0f) tilt else -tilt
                alpha = (3.3f - a).coerceIn(0f, 1f)
                cameraDistance = 14f * density
            }
            .shadow(14.dp, shape, ambientColor = Color.Black.copy(0.25f), spotColor = Color.Black.copy(0.35f))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFB4B4B6), Color(0xFFA3A3A5))))
            .border(
                0.9.dp,
                Brush.linearGradient(listOf(Color.White.copy(0.75f), Color.White.copy(0.10f), Color.White.copy(0.40f))),
                shape
            )
            .pointerInput(isCenter) {
                detectTapGestures(onTap = { onTap() }, onLongPress = { onLong() })
            }
    ) {
        Column(Modifier.fillMaxSize().padding(cardW * 0.02f)) {
            // cover
            Box(
                Modifier.fillMaxWidth().aspectRatio(0.9f)
                    .clip(RoundedCornerShape(topStart = cardW * 0.075f, topEnd = cardW * 0.075f, bottomStart = cardW * 0.06f, bottomEnd = cardW * 0.06f))
                    .background(Color.White.copy(0.15f))
            ) {
                AsyncImage(model = art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxWidth().fillMaxHeight(0.35f)
                        .background(Brush.verticalGradient(listOf(Color.White.copy(0.16f), Color.Transparent)))
                )
            }
            // title / artist (+ equaliser on the centre card)
            Row(
                Modifier.fillMaxWidth().weight(1f).padding(horizontal = cardW * 0.07f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        title, color = Color.White, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        artist, color = Color.White.copy(0.62f), fontSize = 11.sp, lineHeight = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                if (isCenter) {
                    Box(Modifier.size(cardW * 0.14f, cardW * 0.12f).tap(onWave), contentAlignment = Alignment.Center) {
                        EqBars(playing, Color.White.copy(0.85f), Modifier.size(cardW * 0.10f, cardW * 0.08f))
                    }
                }
            }
        }
        // distance shading: side cards are darker
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { alpha = cfDim(abs(index - posProvider())) }
                .background(Color.Black)
        )
    }
}

/** Seven thin bars like the reference's sound-wave icon; they move while music plays. */
@Composable
private fun EqBars(playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "eq").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "eqT"
    )
    val base = remember { floatArrayOf(0.35f, 0.7f, 0.5f, 1f, 0.6f, 0.85f, 0.4f) }
    Canvas(modifier) {
        val count = base.size
        val bw = size.width / (count * 2f - 1f)
        for (i in 0 until count) {
            val k = if (playing) 0.55f + 0.45f * ((sin((t + i * 0.17f) * 2f * PI.toFloat()) + 1f) / 2f) else 1f
            val h = size.height * base[i] * k
            drawRoundRect(color, Offset(i * bw * 2f, (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f))
        }
    }
}

// ───────────────────────────── pill bar ─────────────────────────────

@Composable
private fun RefPill(
    vm: MainViewModel, u: Dp, downloaded: Boolean, seekState: MutableState<Float?>,
    onMore: () -> Unit, onDownload: () -> Unit, onCast: () -> Unit, onVolumeIcon: () -> Unit
) {
    val w = Color.White
    val dur = vm.duration.coerceAtLeast(1L).toFloat()
    val frac = ((seekState.value ?: vm.position.toFloat()) / dur).coerceIn(0f, 1f)
    val accent = LocalLook.current.accentFill

    Box(
        Modifier.size(u * 672f, u * 93f).clip(CircleShape)
            .background(Color.White.copy(0.11f), CircleShape)
            .border(0.8.dp, Brush.linearGradient(listOf(Color.White.copy(0.35f), Color.White.copy(0.12f), Color.White.copy(0.25f))), CircleShape)
    ) {
        // shuffle
        Box(Modifier.at(u, 60f, 46f, 56f, 70f).tap { vm.toggleShuffle() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (vm.shuffle) accent else w.copy(0.88f), modifier = Modifier.size(u * 36f))
        }
        // previous
        Box(Modifier.at(u, 121f, 46f, 56f, 70f).tap { vm.previous() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.SkipPrevious, "Previous", tint = w.copy(0.88f), modifier = Modifier.size(u * 38f))
        }
        // mini cover
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.at(u, 205f, 46f, 52f, 52f).clip(RoundedCornerShape(u * 7f)).background(Color.White.copy(0.2f))
        )
        // title + artist
        Column(Modifier.offset(x = u * 246f, y = u * 20f).width(u * 184f)) {
            Text(
                vm.currentMeta?.title?.toString() ?: "", color = w, fontSize = 11.sp, lineHeight = 13.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                vm.currentMeta?.artist?.toString() ?: "", color = w.copy(0.6f), fontSize = 9.5.sp, lineHeight = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        // thin progress line under the mini track (tap or drag to seek)
        ThinSlider(
            fraction = frac, modifier = Modifier.at(u, 320f, 78f, 282f, 30f),
            onChange = { seekState.value = it * dur },
            onDone = { seekState.value?.let { vm.seekTo(it.toLong()) }; seekState.value = null },
            glow = accent, playing = vm.isPlaying
        )
        // equaliser (opens the more sheet)
        Box(Modifier.at(u, 448f, 46f, 52f, 70f).tap(onMore), contentAlignment = Alignment.Center) {
            EqBars(vm.isPlaying, w.copy(0.9f), Modifier.size(u * 32f, u * 28f))
        }
        // downloaded
        Box(Modifier.at(u, 506f, 46f, 52f, 70f).tap(onDownload), contentAlignment = Alignment.Center) {
            if (downloaded) {
                Box(Modifier.size(u * 34f).clip(CircleShape).background(CheckGreen), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Check, "Downloaded", tint = Color(0xFF101010), modifier = Modifier.size(u * 24f))
                }
            } else {
                Icon(Icons.Rounded.AddCircleOutline, "Download", tint = w.copy(0.85f), modifier = Modifier.size(u * 34f))
            }
        }
        // cast
        Box(Modifier.at(u, 563f, 46f, 52f, 70f).tap(onCast), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Cast, "Cast", tint = w.copy(0.88f), modifier = Modifier.size(u * 34f))
        }
        // volume
        Box(Modifier.at(u, 618f, 46f, 52f, 70f).tap(onVolumeIcon), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.VolumeUp, "Volume", tint = w.copy(0.88f), modifier = Modifier.size(u * 34f))
        }
    }
}

// ───────────────────────────── rewind · pause · forward ─────────────────────────────

@Composable
private fun RefControls(vm: MainViewModel, u: Dp, vol: Float, onVolChange: (Float) -> Unit, onVolDone: () -> Unit) {
    val w = Color.White
    Box(Modifier.size(u * 736f, u * 70f)) {
        // left half of the volume line
        Icon(Icons.Rounded.VolumeDown, null, tint = w.copy(0.7f), modifier = Modifier.at(u, 92f, 35f, 38f, 38f))
        ThinSlider(
            fraction = (vol * 2f).coerceIn(0f, 1f), modifier = Modifier.at(u, 163.5f, 35f, 87f, 44f),
            onChange = { onVolChange(it / 2f) }, onDone = onVolDone
        )
        // rewind = previous song
        Box(Modifier.at(u, 257f, 35f, 76f, 64f).tap { vm.previous() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.FastRewind, "Previous", tint = w, modifier = Modifier.size(u * 58f))
        }
        // pause / play
        Box(Modifier.at(u, 367f, 35f, 76f, 64f).tap { vm.togglePlay() }, contentAlignment = Alignment.Center) {
            when {
                vm.buffering -> CircularProgressIndicator(Modifier.size(u * 40f), color = w, strokeWidth = 2.dp)
                vm.isPlaying -> Row(horizontalArrangement = Arrangement.spacedBy(u * 11f)) {
                    repeat(2) {
                        Box(Modifier.size(u * 12f, u * 46f).clip(RoundedCornerShape(u * 3.5f)).background(w))
                    }
                }
                else -> Icon(Icons.Rounded.PlayArrow, "Play", tint = w, modifier = Modifier.size(u * 60f))
            }
        }
        // forward = next song
        Box(Modifier.at(u, 478f, 35f, 76f, 64f).tap { vm.next() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.FastForward, "Next", tint = w, modifier = Modifier.size(u * 58f))
        }
        // right half of the volume line
        ThinSlider(
            fraction = (vol * 2f - 1f).coerceIn(0f, 1f), modifier = Modifier.at(u, 571.5f, 35f, 89f, 44f),
            onChange = { onVolChange(0.5f + it / 2f) }, onDone = onVolDone
        )
        Icon(Icons.Rounded.VolumeUp, null, tint = w.copy(0.5f), modifier = Modifier.at(u, 645f, 35f, 38f, 38f))
    }
}

/** Hair-thin line with a bright filled part. Tap or drag anywhere on it. */
@Composable
private fun ThinSlider(
    fraction: Float, modifier: Modifier, onChange: (Float) -> Unit, onDone: () -> Unit,
    glow: Color? = null, playing: Boolean = false
) {
    // soft breathing of the glow while music plays
    val pulse by rememberInfiniteTransition(label = "barGlow").animateFloat(
        0.75f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "barGlowV"
    )
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    change((o.x / size.width).coerceIn(0f, 1f))
                    done()
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { c, _ ->
                        c.consume()
                        change((c.position.x / size.width).coerceIn(0f, 1f))
                    }
                )
            }
    ) {
        val y = size.height / 2f
        val t = 2.dp.toPx()
        drawLine(Color.White.copy(0.28f), Offset(0f, y), Offset(size.width, y), t, StrokeCap.Round)
        if (fraction > 0f) {
            val x = size.width * fraction
            val k = if (playing) pulse else 0.8f
            if (glow != null) {
                // layered halo around the filled part
                drawLine(glow.copy(alpha = 0.10f * k), Offset(0f, y), Offset(x, y), t * 4.4f, StrokeCap.Round)
                drawLine(glow.copy(alpha = 0.18f * k), Offset(0f, y), Offset(x, y), t * 3.0f, StrokeCap.Round)
                drawLine(glow.copy(alpha = 0.34f * k), Offset(0f, y), Offset(x, y), t * 1.9f, StrokeCap.Round)
            }
            drawLine(Color.White.copy(0.92f), Offset(0f, y), Offset(x, y), t, StrokeCap.Round)
            if (glow != null) {
                // small glowing dot at the end of the fill
                val r = 3.dp.toPx()
                drawCircle(
                    Brush.radialGradient(listOf(glow.copy(alpha = 0.6f * k), Color.Transparent), Offset(x, y), r * 3.4f),
                    r * 3.4f, Offset(x, y)
                )
                drawCircle(Color.White, r * 0.85f, Offset(x, y))
            }
        }
    }
}
