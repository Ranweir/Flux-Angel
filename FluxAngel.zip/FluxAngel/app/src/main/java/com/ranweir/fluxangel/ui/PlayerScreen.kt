package com.ranweir.fluxangel.ui

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.animation.core.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import kotlin.math.abs
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

@Composable
fun PlayerScreen(vm: MainViewModel, onBack: () -> Unit, onSettings: () -> Unit, onAddTo: (Song) -> Unit) {
    val ctx = LocalContext.current
    val song = vm.currentSong()
    val fav = song?.let { vm.isFavorite(it.url) } == true
    val downloaded = song?.let { vm.isDownloaded(it.url) } == true

    Box(Modifier.fillMaxSize()) {
    if (android.os.Build.VERSION.SDK_INT >= 31) {
        // soft ambient glow made from the current cover
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().blur(90.dp).alpha(0.42f)
        )
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ---- header: close · title · favourite ----
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.glass(CircleShape)) {
                Icon(Icons.Default.KeyboardArrowDown, "Close", Modifier.size(28.dp))
            }
            Text(
                "Now Playing", fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = { song?.let { vm.toggleFavorite(it) } },
                modifier = Modifier.glass(CircleShape)
            ) {
                Icon(
                    if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite",
                    tint = if (fav) Pink else fg()
                )
            }
        }
        Spacer(Modifier.height(26.dp))

        // ---- cover-flow carousel: neighbours peek in from both sides, swipe with spring physics ----
        CoverFlow(vm)
        Spacer(Modifier.height(24.dp))

        Text(
            vm.currentMeta?.title?.toString() ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
        Text(
            vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = fg(0.65f), modifier = Modifier.padding(top = 4.dp)
        )
        Spacer(Modifier.height(18.dp))

        var dragging by remember { mutableStateOf<Float?>(null) }
        val dur = vm.duration.coerceAtLeast(1L).toFloat()
        GlowSlider(
            fraction = ((dragging ?: vm.position.toFloat()) / dur).coerceIn(0f, 1f),
            playing = vm.isPlaying,
            onDrag = { dragging = it * dur },
            onDone = { dragging?.let { vm.seekTo(it.toLong()) }; dragging = null }
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime((dragging ?: vm.position.toFloat()).toLong()), fontSize = 12.sp, color = fg(0.65f))
            Text(formatTime(vm.duration), fontSize = 12.sp, color = fg(0.65f))
        }
        Spacer(Modifier.height(12.dp))

        // ---- transport controls ----
        Row(
            Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (vm.shuffle) accentText() else fg())
            }
            IconButton(onClick = { vm.previous() }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(34.dp))
            }
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(LocalLook.current.accentFill).clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                if (vm.buffering) CircularProgressIndicator(Modifier.size(30.dp), strokeWidth = 3.dp, color = Ink)
                else Icon(
                    if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "Play/Pause", Modifier.size(42.dp), tint = Ink
                )
            }
            IconButton(onClick = { vm.next() }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.SkipNext, "Next", Modifier.size(34.dp))
            }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    "Repeat",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) fg() else accentText()
                )
            }
        }
        Spacer(Modifier.height(24.dp))

        // ---- actions ----
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { song?.let(onAddTo) }) { Icon(Icons.Default.Add, "Add to playlist") }
            IconButton(onClick = { song?.let { vm.download(it) } }) {
                Icon(
                    if (downloaded) Icons.Default.DownloadDone else Icons.Default.FileDownload, "Download",
                    tint = if (downloaded) accentText() else fg()
                )
            }
            IconButton(onClick = {
                song?.let {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, it.url)
                    }
                    ctx.startActivity(Intent.createChooser(i, "Share"))
                }
            }) { Icon(Icons.Default.Share, "Share") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
        }
        vm.error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CoverFlow(vm: MainViewModel) {
    val queue = vm.queue
    val n = queue.size
    val pages = maxOf(n, 1)
    val pager = rememberPagerState(initialPage = vm.currentIndex.coerceIn(0, pages - 1)) { pages }

    // player -> carousel (next/previous buttons, auto advance)
    var pending by remember { mutableIntStateOf(-1) }   // index requested by a swipe, not yet confirmed by the player
    LaunchedEffect(vm.currentIndex, pages) {
        if (pending != -1) { if (vm.currentIndex == pending) pending = -1 else return@LaunchedEffect }
        val t = vm.currentIndex.coerceIn(0, pages - 1)
        if (pager.currentPage != t && !pager.isScrollInProgress) {
            pager.animateScrollToPage(t, animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow))
        }
    }
    // carousel -> player (user swiped to another cover)
    LaunchedEffect(pager, n) {
        snapshotFlow { pager.settledPage }.collect { p -> if (n > 0 && p != vm.currentIndex) { pending = p; vm.skipTo(p) } }
    }

    BoxWithConstraints(Modifier.fillMaxWidth().layout { m, c ->
        // let the carousel use the full screen width, ignoring the 24dp side padding of the page
        val extra = 48.dp.roundToPx()
        val pl = m.measure(c.copy(minWidth = c.maxWidth + extra, maxWidth = c.maxWidth + extra))
        layout(c.maxWidth, pl.height) { pl.place(-extra / 2, 0) }
    }) {
        val screenW = maxWidth
        val cardW = screenW * 0.64f
        HorizontalPager(
            state = pager,
            contentPadding = PaddingValues(horizontal = (screenW - cardW) / 2),
            pageSpacing = 0.dp,
            beyondBoundsPageCount = 2,
            modifier = Modifier.fillMaxWidth().height(cardW + 36.dp)
        ) { page ->
            val song = queue.getOrNull(page)
            val art = song?.thumb?.takeIf { it.isNotBlank() } ?: vm.currentMeta?.artworkUri
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.width(cardW).aspectRatio(1f)
                        .graphicsLayer {
                            val off = (pager.currentPage - page) + pager.currentPageOffsetFraction   // 0 centred, +left, -right
                            val a = abs(off).coerceAtMost(2f)
                            val s = 1f - 0.20f * a.coerceAtMost(1f) - 0.06f * (a - 1f).coerceAtLeast(0f)
                            scaleX = s; scaleY = s
                            alpha = 1f - 0.38f * a.coerceAtMost(1f) - 0.2f * (a - 1f).coerceAtLeast(0f)
                            rotationY = (off * 26f).coerceIn(-48f, 48f)
                            translationX = off.coerceIn(-2f, 2f) * size.width * 0.14f
                            cameraDistance = 14f * density
                        }
                        .shadow(18.dp, RoundedCornerShape(30.dp), ambientColor = Color.Black.copy(0.4f), spotColor = Color.Black.copy(0.5f))
                        .clip(RoundedCornerShape(30.dp))
                        .background(fg(0.08f))
                        .border(
                            1.2.dp,
                            Brush.linearGradient(listOf(Color.White.copy(0.75f), Color.White.copy(0.08f), Color.White.copy(0.4f))),
                            RoundedCornerShape(30.dp)
                        )
                ) {
                    AsyncImage(model = art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    // glass sheen across the top of the card
                    Box(
                        Modifier.fillMaxWidth().fillMaxHeight(0.4f)
                            .background(Brush.verticalGradient(listOf(Color.White.copy(0.20f), Color.Transparent)))
                    )
                }
            }
        }
    }
}

/** Progress bar with a soft glowing fill and a glowing thumb. Tap or drag to seek. */
@Composable
private fun GlowSlider(fraction: Float, playing: Boolean, onDrag: (Float) -> Unit, onDone: () -> Unit) {
    val accent = LocalLook.current.accentFill
    val smooth by animateFloatAsState(fraction, tween(450, easing = LinearEasing), label = "progress")
    val pulse by rememberInfiniteTransition(label = "glow").animateFloat(
        0.75f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    var touching by remember { mutableStateOf(false) }
    val thumbScale by animateFloatAsState(if (touching) 1.35f else 1f, spring(0.55f, Spring.StiffnessMedium), label = "thumb")
    val glow = if (playing) pulse else 0.8f
    val dark = LocalLook.current.fg == Color.White
    Canvas(
        Modifier.fillMaxWidth().height(44.dp)
            .pointerInput(Unit) {
                detectTapGestures(onPress = { o ->
                    touching = true
                    onDrag((o.x / size.width).coerceIn(0f, 1f))
                    tryAwaitRelease()
                    touching = false
                    onDone()
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { touching = true },
                    onHorizontalDrag = { c, _ -> c.consume(); onDrag((c.position.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { touching = false; onDone() },
                    onDragCancel = { touching = false; onDone() }
                )
            }
    ) {
        val pad = 14.dp.toPx()
        val w = size.width - pad * 2
        val y = size.height / 2
        val x = pad + w * smooth
        val track = 5.dp.toPx()
        // inactive track
        drawLine(
            if (dark) Color.White.copy(0.16f) else Color.Black.copy(0.13f),
            Offset(pad, y), Offset(pad + w, y), track, StrokeCap.Round
        )
        if (x > pad) {
            // layered halo (soft glow around the filled part)
            drawLine(accent.copy(alpha = 0.10f * glow), Offset(pad, y), Offset(x, y), track * 5.2f, StrokeCap.Round)
            drawLine(accent.copy(alpha = 0.16f * glow), Offset(pad, y), Offset(x, y), track * 3.4f, StrokeCap.Round)
            drawLine(accent.copy(alpha = 0.28f * glow), Offset(pad, y), Offset(x, y), track * 2.0f, StrokeCap.Round)
            // bright core
            drawLine(
                Brush.horizontalGradient(listOf(accent.copy(alpha = 0.75f), accent, Color.White.copy(alpha = 0.95f)), pad, x),
                Offset(pad, y), Offset(x, y), track, StrokeCap.Round
            )
        }
        // glowing thumb
        val r = 7.dp.toPx() * thumbScale
        drawCircle(Brush.radialGradient(listOf(accent.copy(0.55f * glow), Color.Transparent), Offset(x, y), r * 3.4f), r * 3.4f, Offset(x, y))
        drawCircle(Color.White, r, Offset(x, y))
        drawCircle(accent, r * 0.55f, Offset(x, y))
    }
}
