package com.ranweir.fluxangel.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.transform.Transformation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.ranweir.fluxangel.LyricsRepo
import com.ranweir.fluxangel.LyricsResult
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/*
 * Now Playing page, built to match the silver "frosted glass cover-flow" reference design:
 *   the cover itself, blurred, as the background (+ film grain), 5 glass cards (centre one big),
 *   a long pill bar (shuffle, previous, mini track + progress, equaliser, downloaded, cast, volume)
 *   and the big rewind / pause / forward row with the split volume line.
 * All sizes are measured from the reference image (736 px wide) and scaled with [u] = screen width / 736.
 */

private val SilverTop = Color(0xFF8D8D8F)
private val SilverMid = Color(0xFF9B9B9D)
private val SilverLow = Color(0xFF7C7C7E)
private val SilverBottom = Color(0xFF707072)
private val CheckGreen = Color(0xFF1ED760)

@Composable
fun PlayerScreen(vm: MainViewModel, onBack: () -> Unit, onSettings: () -> Unit, onAddTo: (Song) -> Unit) {
    val ctx = LocalContext.current
    val song = vm.currentSong()
    val fav = song?.let { vm.isFavorite(it.url) } == true
    val downloaded = song?.let { vm.isDownloaded(it.url) } == true
    var showMore by remember { mutableStateOf(false) }
    BackHandler(showMore) { showMore = false }
    var showLyrics by remember { mutableStateOf(false) }
    BackHandler(showLyrics) { showLyrics = false }

    // cover-flow controller; the swipe is caught by the whole screen (see the root modifier below)
    val scope = rememberCoroutineScope()
    val ctl = remember { CarouselCtl(vm, vm.currentIndex.toFloat(), scope) }
    val carouselDrag = rememberDraggableState { ctl.dragBy(it) }

    // ---- system music volume (drives the split line under the pill) ----
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var volTouch by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            if (!volTouch) vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol
            delay(500)
        }
    }
    val setVol: (Float) -> Unit = { f ->
        volTouch = true
        vol = f.coerceIn(0f, 1f)
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (vol * maxVol).roundToInt(), 0) }
    }
    val volDone: () -> Unit = { volTouch = false }

    // seek preview while the pill progress line is being dragged
    val seekState = remember { mutableStateOf<Float?>(null) }

    val silver = remember {
        Brush.verticalGradient(0f to SilverTop, 0.4f to SilverMid, 0.75f to SilverLow, 1f to SilverBottom)
    }
    val shareSong: () -> Unit = {
        song?.let {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, it.url)
            }
            ctx.startActivity(Intent.createChooser(i, "Share"))
        }
    }

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        BoxWithConstraints(
            Modifier.fillMaxSize()
                .draggable(
                    state = carouselDrag, orientation = Orientation.Horizontal,
                    onDragStarted = { ctl.dragStarted() },
                    onDragStopped = { v -> ctl.dragStopped(v) }
                )
                .pointerInput(Unit) {
                // swipe down anywhere to close the player (there is no header button in this design)
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, d -> total += d },
                    onDragEnd = { if (total > 140.dp.toPx()) onBack() },
                    onDragCancel = { }
                )
            }
        ) {
            val sw = maxWidth
            val sh = maxHeight

            // ---- background = the current cover itself, blurred (colours follow the song) ----
            Box(Modifier.fillMaxSize().graphicsLayer { }.background(Color(0xFF3A3A3C))) {
                Crossfade(targetState = vm.currentMeta?.artworkUri, animationSpec = tween(700), label = "bgArt") { uri ->
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(uri).size(256)
                            .allowRgb565(false).bitmapConfig(android.graphics.Bitmap.Config.ARGB_8888)
                            .transformations(SoftBlur(size = 96, radius = 9)).build(),
                        contentDescription = null, contentScale = ContentScale.Crop,
                        filterQuality = FilterQuality.High,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                // soft veil: keeps the white text readable on bright covers and adds the frosted look
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(0.10f), Color.Black.copy(0.10f), Color.Black.copy(0.28f))
                        )
                    )
                }
            }

            // ---- main block, centred on the screen ----
            val u = minOf(sw / 736f, (sh - 40.dp) / 700f)
            Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    RefCarousel(vm, u, ctl, onMore = { showMore = true }, onLyrics = { showLyrics = true })
                    Spacer(Modifier.height(u * 18f))
                    RefPill(
                        vm = vm, u = u, downloaded = downloaded, seekState = seekState,
                        onMore = { showMore = true },
                        onDownload = {
                            song?.let {
                                if (downloaded) Toast.makeText(ctx, "Already downloaded", Toast.LENGTH_SHORT).show()
                                else vm.download(it)
                            }
                        },
                        onCast = {
                            runCatching { ctx.startActivity(Intent(android.provider.Settings.ACTION_CAST_SETTINGS)) }
                        },
                        onVolumeIcon = {
                            runCatching { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI) }
                        }
                    )
                    Spacer(Modifier.height(u * 24f))
                    RefControls(vm, u, vol, onVolChange = setVol, onVolDone = volDone)
                }
            }


            vm.error?.let {
                Text(
                    it, color = Color(0xFFFFB4AB), fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(16.dp)
                )
            }

            // ---- live lyrics (tap the centre cover, or Lyrics in the more sheet) ----
            AnimatedVisibility(
                visible = showLyrics,
                enter = fadeIn() + slideInVertically { it / 6 }, exit = fadeOut() + slideOutVertically { it / 6 }
            ) { LyricsPanel(vm) { showLyrics = false } }

            // ---- "more" sheet: favourite, add to playlist, share, repeat, settings ----
            AnimatedVisibility(visible = showMore, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f)).tap { showMore = false })
            }
            AnimatedVisibility(
                visible = showMore, modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                        .background(Color(0xFF2C2C2E))
                        .navigationBarsPadding().padding(top = 10.dp, bottom = 10.dp)
                ) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).padding(bottom = 6.dp)
                            .size(36.dp, 4.dp).clip(CircleShape).background(Color.White.copy(0.3f))
                    )
                    SheetRow(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (fav) "Remove from favourites" else "Add to favourites",
                        if (fav) Pink else Color.White
                    ) { song?.let { vm.toggleFavorite(it) }; showMore = false }
                    SheetRow(Icons.Rounded.PlaylistAdd, "Add to playlist") { showMore = false; song?.let(onAddTo) }
                    SheetRow(Icons.Rounded.Lyrics, "Lyrics") { showMore = false; showLyrics = true }
                    SheetRow(Icons.Rounded.Share, "Share") { showMore = false; shareSong() }
                    SheetRow(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        when (vm.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Repeat: one song"
                            Player.REPEAT_MODE_ALL -> "Repeat: all"
                            else -> "Repeat: off"
                        },
                        if (vm.repeatMode == Player.REPEAT_MODE_OFF) Color.White else LocalLook.current.accentFill
                    ) { vm.cycleRepeat() }
                    SheetRow(Icons.Rounded.Settings, "Settings") { showMore = false; onSettings() }
                }
            }
        }
    }
}

// ───────────────────────────── helpers ─────────────────────────────

/** Positions a box by its centre (cx, cy) and size, all in reference pixels scaled by [u]. */
private fun Modifier.at(u: Dp, cx: Float, cy: Float, w: Float, h: Float): Modifier =
    this.offset(x = u * (cx - w / 2f), y = u * (cy - h / 2f)).size(u * w, u * h)

/** Click without the ripple (the design has none). */
@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }

@Composable
private fun SheetRow(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tap(onClick).padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = Color.White, fontSize = 15.sp)
    }
}

// carousel geometry: how far, how small and how dark the cards get with distance from the centre
private fun cfDisp(a: Float): Float = when {
    a <= 1f -> 0.37f * a
    a <= 2f -> 0.37f + 0.33f * (a - 1f)
    else -> 0.70f + 0.16f * (a - 2f)
}

private fun cfScale(a: Float): Float = when {
    a <= 1f -> 1f - 0.12f * a
    a <= 2f -> 0.88f - 0.09f * (a - 1f)
    else -> 0.79f - 0.06f * (a - 2f)
}

private fun cfDim(a: Float): Float = when {
    a <= 1f -> 0.15f * a
    a <= 2f -> 0.15f + 0.11f * (a - 1f)
    else -> 0.26f + 0.10f * (a - 2f).coerceAtMost(1f)
}

// ───────────────────────────── cover-flow ─────────────────────────────

/**
 * Carousel controller. Lives above the whole screen so a swipe works from ANY empty place on the page,
 * and nothing slow ever runs inside the drag callbacks (that used to freeze the swipe after the first change).
 */
@Stable
private class CarouselCtl(
    private val vm: MainViewModel,
    initial: Float,
    private val scope: CoroutineScope
) {
    /** Continuous position in songs (2.0 = song 2 centred). Plain state, so a drag is applied in the same frame. */
    var pos by mutableFloatStateOf(initial)
    var slotPx: Float = 150f
    var dragging by mutableStateOf(false)
    /** Song index we asked the player for and are still waiting to see confirmed. */
    var pending by mutableIntStateOf(-1)
    private var commitJob: Job? = null
    private var animJob: Job? = null
    private val last: Int get() = maxOf(vm.queue.size - 1, 0)

    fun settle(index: Int, velocity: Float = 0f) {
        animJob?.cancel()
        animJob = scope.launch {
            animate(pos, index.toFloat(), velocity.coerceIn(-12f, 12f), spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { v, _ ->
                pos = v
            }
        }
    }

    fun dragStarted() {
        dragging = true
        commitJob?.cancel()
        animJob?.cancel()
    }

    fun dragBy(delta: Float) {
        pos = (pos - delta / slotPx).coerceIn(0f, last.toFloat())
    }

    fun dragStopped(velocity: Float) {
        dragging = false
        val perSec = -velocity / slotPx
        val extra = (perSec * 0.2f).roundToInt().coerceIn(-1, 1)
        commit(pos.roundToInt() + extra, perSec)
    }

    /** Show [target] right away; ask the player only once the user has stopped swiping (each song costs a network lookup). */
    fun commit(target: Int, velocity: Float = 0f) {
        if (vm.queue.isEmpty()) return
        val t = target.coerceIn(0, last)
        settle(t, velocity)
        commitJob?.cancel()
        if (t == vm.currentIndex) { pending = -1; return }
        commitJob = scope.launch {
            delay(450)
            if (t != vm.currentIndex) { pending = t; vm.skipTo(t) }
        }
    }
}

@Composable
private fun RefCarousel(vm: MainViewModel, u: Dp, ctl: CarouselCtl, onMore: () -> Unit, onLyrics: () -> Unit) {
    val queue = vm.queue
    val n = queue.size
    val last = maxOf(n - 1, 0)
    val cardW = u * 312f
    val density = androidx.compose.ui.platform.LocalDensity.current
    SideEffect { ctl.slotPx = with(density) { (cardW * 0.37f).toPx() } }

    // player -> carousel (next/previous buttons, auto advance, confirmation of our own request)
    LaunchedEffect(vm.currentIndex, n) {
        if (ctl.pending != -1) {
            if (vm.currentIndex == ctl.pending) ctl.pending = -1 else return@LaunchedEffect
        }
        val t = vm.currentIndex.coerceIn(0, last)
        if (!ctl.dragging && abs(ctl.pos - t) > 0.001f) ctl.settle(t)
    }
    // the player never confirmed our request: show what is really playing again
    LaunchedEffect(ctl.pending) {
        val p = ctl.pending
        if (p != -1) {
            delay(5000)
            if (ctl.pending == p) {
                ctl.pending = -1
                if (!ctl.dragging) ctl.settle(vm.currentIndex.coerceIn(0, last))
            }
        }
    }

    val center by remember { derivedStateOf { ctl.pos.roundToInt().coerceIn(0, last) } }
    val lo = maxOf(center - 3, 0)
    val hi = minOf(center + 3, last)
    val order = if (n == 0) emptyList() else (lo..hi).sortedByDescending { abs(it - center) }   // far cards first, centre on top

    Box(Modifier.fillMaxWidth().height(u * 460f), contentAlignment = Alignment.Center) {
        order.forEach { i ->
            key(i) {
                val s = queue.getOrNull(i)
                CoverCard(
                    index = i, posProvider = { ctl.pos }, cardW = cardW,
                    art = s?.thumb?.takeIf { it.isNotBlank() } ?: vm.currentMeta?.artworkUri,
                    title = s?.title ?: vm.currentMeta?.title?.toString() ?: "",
                    artist = s?.artist ?: vm.currentMeta?.artist?.toString() ?: "",
                    isCenter = i == center, playing = vm.isPlaying,
                    onTap = { if (i != center) ctl.commit(i) else onLyrics() },
                    onLong = onMore, onWave = onMore
                )
            }
        }
        if (n == 0) {
            CoverCard(
                index = 0, posProvider = { 0f }, cardW = cardW, art = vm.currentMeta?.artworkUri,
                title = vm.currentMeta?.title?.toString() ?: "", artist = vm.currentMeta?.artist?.toString() ?: "",
                isCenter = true, playing = vm.isPlaying, onTap = onLyrics, onLong = onMore, onWave = onMore
            )
        }
    }
}

@Composable
private fun CoverCard(
    index: Int, posProvider: () -> Float, cardW: Dp, art: Any?, title: String, artist: String,
    isCenter: Boolean, playing: Boolean, onTap: () -> Unit, onLong: () -> Unit, onWave: () -> Unit
) {
    val shape = RoundedCornerShape(cardW * 0.10f)
    Box(
        Modifier.width(cardW).height(cardW * 1.4f)
            .graphicsLayer {
                val o = index - posProvider()          // 0 centred, negative = left, positive = right
                val a = abs(o)
                val d = cfDisp(a)
                translationX = (if (o < 0f) -d else d) * size.width
                val sc = cfScale(a)
                scaleX = sc; scaleY = sc
                // side cards lean towards the centre: the edge nearer the middle goes further away
                val tilt = when {
                    a <= 1f -> 34f * a
                    a <= 2f -> 34f + 10f * (a - 1f)
                    else -> 44f + 6f * (a - 2f)
                }.coerceAtMost(52f)
                rotationY = if (o < 0f) tilt else -tilt
                alpha = (3.3f - a).coerceIn(0f, 1f)
                cameraDistance = 14f * density
            }
            .drawBehind {
                // smooth blurred shadow, pre-rendered once per card size (no stacked rectangles = no banding lines)
                val sh = cardShadow(size.width.toInt(), size.height.toInt(), (cardW.toPx() * 0.10f), 22.dp.toPx(), 10.dp.toPx())
                drawImage(sh.image, Offset(-sh.margin, -sh.margin))
            }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFB4B4B6), Color(0xFFA3A3A5))))
            .border(
                0.9.dp,
                Brush.linearGradient(listOf(Color.White.copy(0.75f), Color.White.copy(0.10f), Color.White.copy(0.40f))),
                shape
            )
            .pointerInput(isCenter) {
                detectTapGestures(onTap = { onTap() }, onLongPress = { onLong() })
            }
    ) {
        Column(Modifier.fillMaxSize().padding(cardW * 0.02f)) {
            // cover
            Box(
                Modifier.fillMaxWidth().aspectRatio(0.9f)
                    .clip(RoundedCornerShape(topStart = cardW * 0.075f, topEnd = cardW * 0.075f, bottomStart = cardW * 0.06f, bottomEnd = cardW * 0.06f))
                    .background(Color.White.copy(0.15f))
            ) {
                HiResImage(
                    art?.toString(), px = 640,
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        // the picture slides a little against its card while swiping (depth / parallax)
                        val o = (index - posProvider()).coerceIn(-1f, 1f)
                        val z = 1f + 0.08f * abs(o)
                        scaleX = z; scaleY = z
                        translationX = -o * size.width * 0.04f
                    }
                )
                Box(
                    Modifier.fillMaxWidth().fillMaxHeight(0.35f)
                        .background(Brush.verticalGradient(listOf(Color.White.copy(0.16f), Color.Transparent)))
                )
            }
            // title / artist (+ equaliser on the centre card)
            Row(
                Modifier.fillMaxWidth().weight(1f).padding(horizontal = cardW * 0.07f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        title, color = Color.White, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        artist, color = Color.White.copy(0.62f), fontSize = 11.sp, lineHeight = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                if (isCenter) {
                    Box(Modifier.size(cardW * 0.14f, cardW * 0.12f).tap(onWave), contentAlignment = Alignment.Center) {
                        EqBars(playing, Color.White.copy(0.85f), Modifier.size(cardW * 0.10f, cardW * 0.08f))
                    }
                }
            }
        }
        // distance shading: side cards are darker
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { alpha = cfDim(abs(index - posProvider())) }
                .background(Color.Black)
        )
    }
}

/** Seven thin bars like the reference's sound-wave icon; they move while music plays. */
@Composable
private fun EqBars(playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val tState: State<Float> = if (playing) {
        rememberInfiniteTransition(label = "eq").animateFloat(
            0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "eqT"
        )
    } else remember { mutableFloatStateOf(0f) }
    val base = remember { floatArrayOf(0.35f, 0.7f, 0.5f, 1f, 0.6f, 0.85f, 0.4f) }
    Canvas(modifier.graphicsLayer { }) {
        val t = tState.value
        val count = base.size
        val bw = size.width / (count * 2f - 1f)
        for (i in 0 until count) {
            val k = if (playing) 0.55f + 0.45f * ((sin((t + i * 0.17f) * 2f * PI.toFloat()) + 1f) / 2f) else 1f
            val h = size.height * base[i] * k
            drawRoundRect(color, Offset(i * bw * 2f, (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f))
        }
    }
}

// ───────────────────────────── pill bar ─────────────────────────────

@Composable
private fun RefPill(
    vm: MainViewModel, u: Dp, downloaded: Boolean, seekState: MutableState<Float?>,
    onMore: () -> Unit, onDownload: () -> Unit, onCast: () -> Unit, onVolumeIcon: () -> Unit
) {
    val w = Color.White
    val dur = vm.duration.coerceAtLeast(1L).toFloat()
    val frac = ((seekState.value ?: vm.position.toFloat()) / dur).coerceIn(0f, 1f)
    val accent = LocalLook.current.accentFill

    Box(
        Modifier.size(u * 672f, u * 93f).clip(CircleShape)
            .background(Color.White.copy(0.11f), CircleShape)
            .border(0.8.dp, Brush.linearGradient(listOf(Color.White.copy(0.35f), Color.White.copy(0.12f), Color.White.copy(0.25f))), CircleShape)
    ) {
        // shuffle
        Box(Modifier.at(u, 60f, 46f, 56f, 70f).tap { vm.toggleShuffle() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (vm.shuffle) accent else w.copy(0.88f), modifier = Modifier.size(u * 36f))
        }
        // previous
        Box(Modifier.at(u, 121f, 46f, 56f, 70f).tap { vm.previous() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.SkipPrevious, "Previous", tint = w.copy(0.88f), modifier = Modifier.size(u * 38f))
        }
        // mini cover (cross-fades when the song changes)
        Crossfade(
            targetState = vm.currentMeta?.artworkUri, animationSpec = tween(350), label = "pillArt",
            modifier = Modifier.at(u, 205f, 46f, 52f, 52f).clip(RoundedCornerShape(u * 7f)).background(Color.White.copy(0.2f))
        ) { uri ->
            HiResImage(uri?.toString(), Modifier.fillMaxSize(), px = 160)
        }
        // title + artist (cross-fade as well)
        Crossfade(
            targetState = (vm.currentMeta?.title?.toString() ?: "") to (vm.currentMeta?.artist?.toString() ?: ""),
            animationSpec = tween(300), label = "pillText",
            modifier = Modifier.offset(x = u * 246f, y = u * 20f).width(u * 184f)
        ) { (t, a) ->
            Column {
                Text(
                    t, color = w, fontSize = 11.sp, lineHeight = 13.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    a, color = w.copy(0.6f), fontSize = 9.5.sp, lineHeight = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        // thin progress line under the mini track (tap or drag to seek)
        ThinSlider(
            fraction = frac, modifier = Modifier.at(u, 320f, 78f, 282f, 30f),
            onChange = { seekState.value = it * dur },
            onDone = { seekState.value?.let { vm.seekTo(it.toLong()) }; seekState.value = null },
            glow = accent, playing = vm.isPlaying
        )
        // equaliser (opens the more sheet)
        Box(Modifier.at(u, 448f, 46f, 52f, 70f).tap(onMore), contentAlignment = Alignment.Center) {
            EqBars(vm.isPlaying, w.copy(0.9f), Modifier.size(u * 32f, u * 28f))
        }
        // downloaded
        Box(Modifier.at(u, 506f, 46f, 52f, 70f).tap(onDownload), contentAlignment = Alignment.Center) {
            if (downloaded) {
                Box(Modifier.size(u * 34f).clip(CircleShape).background(CheckGreen), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Check, "Downloaded", tint = Color(0xFF101010), modifier = Modifier.size(u * 24f))
                }
            } else {
                Icon(Icons.Rounded.AddCircleOutline, "Download", tint = w.copy(0.85f), modifier = Modifier.size(u * 34f))
            }
        }
        // cast
        Box(Modifier.at(u, 563f, 46f, 52f, 70f).tap(onCast), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Cast, "Cast", tint = w.copy(0.88f), modifier = Modifier.size(u * 34f))
        }
        // volume
        Box(Modifier.at(u, 618f, 46f, 52f, 70f).tap(onVolumeIcon), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.VolumeUp, "Volume", tint = w.copy(0.88f), modifier = Modifier.size(u * 34f))
        }
    }
}

// ───────────────────────────── rewind · pause · forward ─────────────────────────────

@Composable
private fun RefControls(vm: MainViewModel, u: Dp, vol: Float, onVolChange: (Float) -> Unit, onVolDone: () -> Unit) {
    val w = Color.White
    Box(Modifier.size(u * 736f, u * 70f)) {
        // left half of the volume line
        Icon(Icons.Rounded.VolumeDown, null, tint = w.copy(0.7f), modifier = Modifier.at(u, 92f, 35f, 38f, 38f))
        ThinSlider(
            fraction = (vol * 2f).coerceIn(0f, 1f), modifier = Modifier.at(u, 163.5f, 35f, 87f, 44f),
            onChange = { onVolChange(it / 2f) }, onDone = onVolDone
        )
        // rewind = previous song
        Box(Modifier.at(u, 257f, 35f, 76f, 64f).tap { vm.previous() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.FastRewind, "Previous", tint = w, modifier = Modifier.size(u * 58f))
        }
        // pause / play
        Box(Modifier.at(u, 367f, 35f, 76f, 64f).tap { vm.togglePlay() }, contentAlignment = Alignment.Center) {
            when {
                vm.buffering -> CircularProgressIndicator(Modifier.size(u * 40f), color = w, strokeWidth = 2.dp)
                vm.isPlaying -> Row(horizontalArrangement = Arrangement.spacedBy(u * 11f)) {
                    repeat(2) {
                        Box(Modifier.size(u * 12f, u * 46f).clip(RoundedCornerShape(u * 3.5f)).background(w))
                    }
                }
                else -> Icon(Icons.Rounded.PlayArrow, "Play", tint = w, modifier = Modifier.size(u * 60f))
            }
        }
        // forward = next song
        Box(Modifier.at(u, 478f, 35f, 76f, 64f).tap { vm.next() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.FastForward, "Next", tint = w, modifier = Modifier.size(u * 58f))
        }
        // right half of the volume line
        ThinSlider(
            fraction = (vol * 2f - 1f).coerceIn(0f, 1f), modifier = Modifier.at(u, 571.5f, 35f, 89f, 44f),
            onChange = { onVolChange(0.5f + it / 2f) }, onDone = onVolDone
        )
        Icon(Icons.Rounded.VolumeUp, null, tint = w.copy(0.5f), modifier = Modifier.at(u, 645f, 35f, 38f, 38f))
    }
}

/** Hair-thin line with a bright filled part. Tap or drag anywhere on it. */
@Composable
private fun ThinSlider(
    fraction: Float, modifier: Modifier, onChange: (Float) -> Unit, onDone: () -> Unit,
    glow: Color? = null, playing: Boolean = false
) {
    // soft breathing of the glow while music plays
    val pulseState: State<Float> = if (glow != null && playing) {
        rememberInfiniteTransition(label = "barGlow").animateFloat(
            0.75f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "barGlowV"
        )
    } else remember { mutableFloatStateOf(0.8f) }
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    Canvas(
        modifier
            .graphicsLayer { }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    change((o.x / size.width).coerceIn(0f, 1f))
                    done()
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { c, _ ->
                        c.consume()
                        change((c.position.x / size.width).coerceIn(0f, 1f))
                    }
                )
            }
    ) {
        val y = size.height / 2f
        val t = 2.dp.toPx()
        drawLine(Color.White.copy(0.28f), Offset(0f, y), Offset(size.width, y), t, StrokeCap.Round)
        if (fraction > 0f) {
            val x = size.width * fraction
            val k = pulseState.value
            if (glow != null) {
                // layered halo around the filled part
                drawLine(glow.copy(alpha = 0.10f * k), Offset(0f, y), Offset(x, y), t * 4.4f, StrokeCap.Round)
                drawLine(glow.copy(alpha = 0.18f * k), Offset(0f, y), Offset(x, y), t * 3.0f, StrokeCap.Round)
                drawLine(glow.copy(alpha = 0.34f * k), Offset(0f, y), Offset(x, y), t * 1.9f, StrokeCap.Round)
            }
            drawLine(Color.White.copy(0.92f), Offset(0f, y), Offset(x, y), t, StrokeCap.Round)
            if (glow != null) {
                // small glowing dot at the end of the fill
                val r = 3.dp.toPx()
                drawCircle(
                    Brush.radialGradient(listOf(glow.copy(alpha = 0.6f * k), Color.Transparent), Offset(x, y), r * 3.4f),
                    r * 3.4f, Offset(x, y)
                )
                drawCircle(Color.White, r * 0.85f, Offset(x, y))
            }
        }
    }
}

// ───────────────────────────── album art helpers ─────────────────────────────

/** Sharper version of a YouTube / Google thumbnail URL. */
private fun hiResUrl(url: String): String {
    Regex("""(https?://i\d?\.ytimg\.com)/vi(?:_webp)?/([^/?]+)/""").find(url)?.let {
        return "${it.groupValues[1]}/vi/${it.groupValues[2]}/maxresdefault.jpg"
    }
    if ("googleusercontent.com" in url || "ggpht.com" in url) {
        return url.replace(Regex("=w\\d+-h\\d+"), "=w900-h900").replace(Regex("=s\\d+"), "=s900")
    }
    return url
}

/** Full-quality image: 8-bit colour (no grainy RGB565) and the biggest cover available, falls back to the small one. */
@Composable
private fun HiResImage(url: String?, modifier: Modifier, px: Int) {
    val ctx = LocalContext.current
    var hi by remember(url) { mutableStateOf(true) }
    val data = when {
        url.isNullOrBlank() -> null
        hi -> hiResUrl(url)
        else -> url
    }
    AsyncImage(
        model = ImageRequest.Builder(ctx).data(data).size(px, px)
            .allowRgb565(false).bitmapConfig(android.graphics.Bitmap.Config.ARGB_8888).build(),
        contentDescription = null, contentScale = ContentScale.Crop, filterQuality = FilterQuality.High,
        onError = { if (hi) hi = false },
        modifier = modifier
    )
}

// ───────────────────────────── live lyrics ─────────────────────────────

@Composable
private fun LyricsPanel(vm: MainViewModel, onClose: () -> Unit) {
    val title = vm.currentMeta?.title?.toString().orEmpty()
    val artist = vm.currentMeta?.artist?.toString().orEmpty()
    val durSec = vm.currentSong()?.durationSec ?: (vm.duration / 1000)
    var result by remember(title, artist) { mutableStateOf<LyricsResult?>(null) }
    var retry by remember(title, artist) { mutableIntStateOf(0) }
    LaunchedEffect(title, artist, retry) {
        if (title.isBlank()) { result = LyricsResult.None; return@LaunchedEffect }
        result = null
        result = withContext(Dispatchers.IO) { runCatching { LyricsRepo.fetch(title, artist, durSec) }.getOrDefault(LyricsResult.None) }
    }
    val accent = LocalLook.current.accentFill
    val ctx = LocalContext.current
    val seek = remember { mutableStateOf<Float?>(null) }
    val dur = vm.duration.coerceAtLeast(1L).toFloat()

    Box(
        Modifier.fillMaxSize().background(Color(0xFF2A2A2C))
            .pointerInput(Unit) {
                // eat swipes so they never move the cover-flow behind; swipe down closes the lyrics
                var dy = 0f
                detectDragGestures(
                    onDragStart = { dy = 0f },
                    onDrag = { c, d -> c.consume(); dy += d.y },
                    onDragEnd = { if (dy > 140.dp.toPx()) onClose() }
                )
            }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(vm.currentMeta?.artworkUri).size(256)
                .allowRgb565(false).bitmapConfig(android.graphics.Bitmap.Config.ARGB_8888)
                .transformations(SoftBlur(size = 96, radius = 9)).build(),
            contentDescription = null, contentScale = ContentScale.Crop, filterQuality = FilterQuality.High,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(36.dp, 4.dp).clip(CircleShape).background(Color.White.copy(0.3f)).tap(onClose))
                Spacer(Modifier.height(12.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist, color = Color.White.copy(0.65f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when (val r = result) {
                    null -> CircularProgressIndicator(color = accent)
                    is LyricsResult.None -> Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No lyrics found for this song", color = Color.White, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                        Text(
                            "Lyrics come from LRCLIB and some songs are not there yet.",
                            color = Color.White.copy(0.6f), fontSize = 12.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        Text("Try again", color = accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp).tap { retry++ })
                    }
                    is LyricsResult.Found ->
                        if (r.synced.isNotEmpty()) SyncedLyrics(vm, r)
                        else Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 16.dp)) {
                            Text(
                                r.plain, color = Color.White.copy(0.92f),
                                style = TextStyle(
                                    fontSize = 20.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold,
                                    shadow = Shadow(accent.copy(alpha = 0.55f), Offset.Zero, 22f)
                                )
                            )
                        }
                }
            }
            // keep the controls reachable while reading
            Column(Modifier.padding(horizontal = 28.dp)) {
                ThinSlider(
                    fraction = ((seek.value ?: vm.position.toFloat()) / dur).coerceIn(0f, 1f),
                    modifier = Modifier.fillMaxWidth().height(30.dp),
                    onChange = { seek.value = it * dur },
                    onDone = { seek.value?.let { vm.seekTo(it.toLong()) }; seek.value = null },
                    glow = accent, playing = vm.isPlaying
                )
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.FastRewind, "Previous", tint = Color.White, modifier = Modifier.size(40.dp).tap { vm.previous() })
                    Spacer(Modifier.width(36.dp))
                    Icon(
                        if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        "Play/Pause", tint = Color.White, modifier = Modifier.size(52.dp).tap { vm.togglePlay() }
                    )
                    Spacer(Modifier.width(36.dp))
                    Icon(Icons.Rounded.FastForward, "Next", tint = Color.White, modifier = Modifier.size(40.dp).tap { vm.next() })
                }
            }
        }
    }
}

@Composable
private fun SyncedLyrics(vm: MainViewModel, r: LyricsResult.Found) {
    val lines = r.synced
    val accent = LocalLook.current.accentFill
    val pos = vm.position + 250          // show a line slightly before it is sung
    val active = remember(lines, pos) {
        var lo = 0; var hi = lines.lastIndex; var ans = -1
        while (lo <= hi) { val mid = (lo + hi) / 2; if (lines[mid].timeMs <= pos) { ans = mid; lo = mid + 1 } else hi = mid - 1 }
        ans
    }
    val state = rememberLazyListState()
    LaunchedEffect(active) {
        if (active >= 0) {
            val vp = state.layoutInfo.viewportSize.height
            state.animateScrollToItem(active, scrollOffset = -(vp / 3))
        }
    }
    LazyColumn(
        state = state, modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 28.dp, vertical = 120.dp)
    ) {
        itemsIndexed(lines) { i, line ->
            val on = i == active
            val a by animateFloatAsState(if (on) 1f else if (i < active) 0.28f else 0.42f, tween(350), label = "a")
            val sc by animateFloatAsState(if (on) 1f else 0.9f, spring(0.7f, Spring.StiffnessLow), label = "s")
            Text(
                line.text.ifBlank { "♪" },
                style = TextStyle(
                    fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold,
                    shadow = Shadow(accent.copy(alpha = if (on) 1f else 0.4f), Offset.Zero, if (on) 46f else 16f)
                ),
                color = if (on) Color.White else Color.White.copy(alpha = a),
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
                    .graphicsLayer { scaleX = sc; scaleY = sc; transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f) }
                    .tap { vm.seekTo(line.timeMs) }
            )
        }
    }
}

// ───────────────────────────── smooth blur + smooth shadow ─────────────────────────────

/** Soft background blur: shrink the cover to a tiny bitmap, box-blur it three times (≈ gaussian), the GPU then upscales it smoothly. */
private class SoftBlur(private val size: Int, private val radius: Int) : Transformation {
    override val cacheKey: String = "softblur-$size-$radius"

    override suspend fun transform(input: android.graphics.Bitmap, size: coil.size.Size): android.graphics.Bitmap {
        val w = this.size
        val h = (w * input.height / input.width.toFloat()).roundToInt().coerceAtLeast(1)
        val small = android.graphics.Bitmap.createScaledBitmap(input, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        repeat(3) { boxBlur(px, w, h, radius) }
        return android.graphics.Bitmap.createBitmap(px, w, h, android.graphics.Bitmap.Config.ARGB_8888)
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        pass(px, tmp, w, h, r, horizontal = true)
        pass(tmp, px, w, h, r, horizontal = false)
    }

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        val win = 2 * r + 1
        for (l in 0 until lines) {
            var a = 0; var rr = 0; var g = 0; var b = 0
            fun at(i: Int) = if (horizontal) l * w + i.coerceIn(0, len - 1) else i.coerceIn(0, len - 1) * w + l
            for (k in -r..r) {
                val c = src[at(k)]
                a += c ushr 24; rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255
            }
            for (i in 0 until len) {
                val o = if (horizontal) l * w + i else i * w + l
                dst[o] = ((a / win) shl 24) or ((rr / win) shl 16) or ((g / win) shl 8) or (b / win)
                val add = src[at(i + r + 1)]; val rem = src[at(i - r)]
                a += (add ushr 24) - (rem ushr 24)
                rr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                g += ((add shr 8) and 255) - ((rem shr 8) and 255)
                b += (add and 255) - (rem and 255)
            }
        }
    }
}

private class CardShadow(val image: androidx.compose.ui.graphics.ImageBitmap, val margin: Float)

private val shadowCache = HashMap<String, CardShadow>()

/** A blurred rounded-rect shadow bitmap, drawn once with a software canvas (BlurMaskFilter) and reused by every card. */
private fun cardShadow(w: Int, h: Int, corner: Float, blur: Float, dy: Float): CardShadow {
    val key = "$w-$h-${corner.toInt()}-${blur.toInt()}"
    synchronized(shadowCache) {
        shadowCache[key]?.let { return it }
        val m = blur * 2f
        val bmp = android.graphics.Bitmap.createBitmap((w + 2 * m).toInt(), (h + 2 * m).toInt(), android.graphics.Bitmap.Config.ARGB_8888)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.argb(120, 0, 0, 0)
            maskFilter = android.graphics.BlurMaskFilter(blur, android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
        android.graphics.Canvas(bmp).drawRoundRect(
            android.graphics.RectF(m, m + dy, m + w, m + dy + h), corner, corner, paint
        )
        return CardShadow(bmp.asImageBitmap(), m).also { shadowCache[key] = it }
    }
}
