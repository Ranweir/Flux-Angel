package com.ranweir.fluxangel

import java.nio.charset.Charset

/** Replacement for the Java 10 URLDecoder/URLEncoder Charset overloads (missing before Android 13). */
object CompatUrl {
    @JvmStatic
    fun decode(s: String, charset: Charset): String = java.net.URLDecoder.decode(s, charset.name())

    @JvmStatic
    fun encode(s: String, charset: Charset): String = java.net.URLEncoder.encode(s, charset.name())
}
