package com.ranweir.fluxangel

import android.net.Uri
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

enum class AudioQuality(val label: String, val desc: String) {
    HIGH("High", "Best audio YouTube offers, ~8 MB per track"),
    STANDARD("Standard", "About 128 kbps, uses less data and storage, ~4 MB per track")
}

class ResolvedAudio(val url: String, val ext: String, val mime: String, val kbps: Int)

object YouTubeRepo {
    private val service = ServiceList.YouTube

    /**
     * The extractor calls URLEncoder.encode(String, Charset), which only exists on Android 13+.
     * On older phones that throws NoSuchMethodError, so we build the search handler ourselves.
     */
    private fun searchHandler(query: String): SearchQueryHandler {
        val filters = listOf(YoutubeSearchQueryHandlerFactory.VIDEOS)
        return try {
            service.searchQHFactory.fromQuery(query, filters, "")
        } catch (e: NoSuchMethodError) {
            val url = "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(query, "UTF-8")
            SearchQueryHandler::class.java.getConstructor(
                String::class.java, String::class.java, String::class.java, List::class.java, String::class.java
            ).newInstance(url, url, query, filters, "")
        }
    }

    /** Blocking – call from a background thread. */
    fun search(query: String): List<Song> {
        val info = try {
            SearchInfo.getInfo(service, searchHandler(query))
        } catch (e: LinkageError) {
            throw IOException("Search is not supported on this Android version: ${e.message}", e)
        }
        return info.relatedItems.filterIsInstance<StreamInfoItem>().map {
            Song(
                url = it.url,
                title = it.name ?: "Unknown",
                artist = it.uploaderName ?: "",
                thumb = it.thumbnails.maxByOrNull { t -> t.height }?.url ?: "",
                durationSec = it.duration
            )
        }
    }

    private class Cached(val audio: ResolvedAudio, val time: Long)
    private val cache = ConcurrentHashMap<String, Cached>()

    /**
     * Blocking. Picks the highest-bitrate audio-only stream YouTube offers.
     * forDownload = true prefers M4A (AAC) so the saved file plays in every music app.
     */
    @Volatile var streamQuality: AudioQuality = AudioQuality.HIGH

    fun resolve(watchUrl: String, forDownload: Boolean, quality: AudioQuality = AudioQuality.HIGH): ResolvedAudio {
        val key = "$watchUrl|$forDownload|$quality"
        val now = System.currentTimeMillis()
        cache[key]?.let { if (now - it.time < 4 * 3600_000L) return it.audio }

        val info = try {
            StreamInfo.getInfo(watchUrl)
        } catch (e: LinkageError) {
            throw IOException("Playback is not supported on this Android version: ${e.message}", e)
        }
        val all = info.audioStreams.filter {
            it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val pool = if (forDownload) {
            all.filter { it.format == MediaFormat.M4A }.ifEmpty { all }
        } else all
        if (pool.isEmpty()) throw IOException("No playable audio stream found")

        // wanted stream first (by the chosen quality), then every other one as a fallback
        val wanted = (if (quality == AudioQuality.STANDARD)
            pool.filter { it.averageBitrate in 1..140 }.maxByOrNull { it.averageBitrate }
                ?: pool.minByOrNull { it.averageBitrate }
        else pool.maxByOrNull { it.averageBitrate })
        val ordered = (listOfNotNull(wanted) + pool.sortedByDescending { it.averageBitrate })
            .distinctBy { it.content }
            // URLs made for the Android / iOS clients are the ones googlevideo accepts without a PO token;
            // web-client URLs are often answered with HTTP 403. Try the safe ones first.
            .sortedBy { clientRank(it.content) }

        // Don't hand out a link that googlevideo refuses (403/410): probe it, and fall back to the next stream.
        var chosen = ordered.first()
        for (st in ordered.take(6)) {
            if (usable(st.content)) { chosen = st; break }
        }
        val fmt = chosen.format
        val audio = ResolvedAudio(
            url = chosen.content,
            ext = fmt?.suffix ?: "m4a",
            mime = fmt?.mimeType ?: "audio/mp4",
            kbps = chosen.averageBitrate
        )
        cache[key] = Cached(audio, now)
        return audio
    }

    /** Forget resolved links of one song (used after a 403 so the next try fetches fresh ones). */
    fun invalidate(watchUrl: String) {
        cache.keys.filter { it.startsWith("$watchUrl|") }.forEach { cache.remove(it) }
    }

    private fun clientOf(streamUrl: String): String? =
        runCatching { Uri.parse(streamUrl).getQueryParameter("c") }.getOrNull()

    private fun clientRank(streamUrl: String): Int = when (clientOf(streamUrl)) {
        "ANDROID", "IOS", "ANDROID_VR" -> 0
        else -> 1
    }

    private val probeClient = okhttp3.OkHttpClient.Builder()
        .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /** False only when the server clearly refuses the link; network hiccups count as "usable" (ExoPlayer retries those). */
    private fun usable(streamUrl: String): Boolean = try {
        val req = okhttp3.Request.Builder().url(streamUrl)
            .header("User-Agent", userAgentFor(streamUrl))
            .header("Range", "bytes=0-1")
            .build()
        probeClient.newCall(req).execute().use { it.code !in listOf(401, 403, 404, 410) }
    } catch (e: Exception) {
        true
    }

    fun audioUrl(watchUrl: String): String = resolve(watchUrl, false, streamQuality).url

    /** googlevideo expects the same client UA that the stream URL was created for. */
    fun userAgentFor(streamUrl: String): String = when (Uri.parse(streamUrl).getQueryParameter("c")) {
        "ANDROID" -> "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
        "IOS" -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        "ANDROID_VR" -> "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
        else -> USER_AGENT
    }

    fun isYouTube(uri: Uri): Boolean {
        val h = uri.host ?: return false
        return h.contains("youtube.com") || h.contains("youtu.be")
    }
}
