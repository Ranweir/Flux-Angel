package com.ranweir.fluxangel

import android.net.Uri
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

class ResolvedAudio(val url: String, val ext: String, val mime: String, val kbps: Int)

object YouTubeRepo {
    private val service = ServiceList.YouTube

    /**
     * The extractor calls URLEncoder.encode(String, Charset), which only exists on Android 13+.
     * On older phones that throws NoSuchMethodError, so we build the search handler ourselves.
     */
    private fun searchHandler(query: String): SearchQueryHandler {
        val filters = listOf(YoutubeSearchQueryHandlerFactory.VIDEOS)
        return try {
            service.searchQHFactory.fromQuery(query, filters, "")
        } catch (e: NoSuchMethodError) {
            val url = "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(query, "UTF-8")
            SearchQueryHandler::class.java.getConstructor(
                String::class.java, String::class.java, String::class.java, List::class.java, String::class.java
            ).newInstance(url, url, query, filters, "")
        }
    }

    /** Blocking – call from a background thread. */
    fun search(query: String): List<Song> {
        val info = try {
            SearchInfo.getInfo(service, searchHandler(query))
        } catch (e: LinkageError) {
            throw IOException("Search is not supported on this Android version: ${e.message}", e)
        }
        return info.relatedItems.filterIsInstance<StreamInfoItem>().map {
            Song(
                url = it.url,
                title = it.name ?: "Unknown",
                artist = it.uploaderName ?: "",
                thumb = it.thumbnails.firstOrNull()?.url ?: "",
                durationSec = it.duration
            )
        }
    }

    private class Cached(val audio: ResolvedAudio, val time: Long)
    private val cache = ConcurrentHashMap<String, Cached>()

    /**
     * Blocking. Picks the highest-bitrate audio-only stream YouTube offers.
     * forDownload = true prefers M4A (AAC) so the saved file plays in every music app.
     */
    fun resolve(watchUrl: String, forDownload: Boolean): ResolvedAudio {
        val key = "$watchUrl|$forDownload"
        val now = System.currentTimeMillis()
        cache[key]?.let { if (now - it.time < 4 * 3600_000L) return it.audio }

        val info = try {
            StreamInfo.getInfo(watchUrl)
        } catch (e: LinkageError) {
            throw IOException("Playback is not supported on this Android version: ${e.message}", e)
        }
        val all = info.audioStreams.filter {
            it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val pool = if (forDownload) {
            all.filter { it.format == MediaFormat.M4A }.ifEmpty { all }
        } else all
        val best = pool.maxByOrNull { it.averageBitrate }
            ?: throw IOException("No playable audio stream found")
        val fmt = best.format
        val audio = ResolvedAudio(
            url = best.content,
            ext = fmt?.suffix ?: "m4a",
            mime = fmt?.mimeType ?: "audio/mp4",
            kbps = best.averageBitrate
        )
        cache[key] = Cached(audio, now)
        return audio
    }

    fun audioUrl(watchUrl: String): String = resolve(watchUrl, false).url

    /** googlevideo expects the same client UA that the stream URL was created for. */
    fun userAgentFor(streamUrl: String): String = when (Uri.parse(streamUrl).getQueryParameter("c")) {
        "ANDROID" -> "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
        "IOS" -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        else -> USER_AGENT
    }

    fun isYouTube(uri: Uri): Boolean {
        val h = uri.host ?: return false
        return h.contains("youtube.com") || h.contains("youtu.be")
    }
}
