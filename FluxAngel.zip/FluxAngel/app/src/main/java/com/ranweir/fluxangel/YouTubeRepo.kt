package com.ranweir.fluxangel

import android.net.Uri
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

object YouTubeRepo {
    private val service = ServiceList.YouTube

    /** Blocking – call from a background thread. */
    fun search(query: String): List<Song> {
        val handler = service.searchQHFactory.fromQuery(
            query, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), ""
        )
        val info = SearchInfo.getInfo(service, handler)
        return info.relatedItems.filterIsInstance<StreamInfoItem>().map {
            Song(
                url = it.url,
                title = it.name ?: "Unknown",
                artist = it.uploaderName ?: "",
                thumb = it.thumbnails.firstOrNull()?.url ?: "",
                durationSec = it.duration
            )
        }
    }

    private class Cached(val url: String, val time: Long)
    private val cache = ConcurrentHashMap<String, Cached>()

    /** Blocking – resolves a YouTube watch URL to a direct audio stream URL. */
    fun audioUrl(watchUrl: String): String {
        val now = System.currentTimeMillis()
        cache[watchUrl]?.let { if (now - it.time < 4 * 3600_000L) return it.url }
        val info = StreamInfo.getInfo(watchUrl)
        val list = info.audioStreams.filter {
            it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val best = list.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
            ?: list.maxByOrNull { it.averageBitrate }
            ?: throw IOException("No playable audio stream found")
        val url = best.content
        cache[watchUrl] = Cached(url, now)
        return url
    }

    /** googlevideo expects the same client UA that the stream URL was created for. */
    fun userAgentFor(streamUrl: String): String = when (Uri.parse(streamUrl).getQueryParameter("c")) {
        "ANDROID" -> "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
        "IOS" -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        else -> USER_AGENT
    }

    fun isYouTube(uri: Uri): Boolean {
        val h = uri.host ?: return false
        return h.contains("youtube.com") || h.contains("youtu.be")
    }
}
