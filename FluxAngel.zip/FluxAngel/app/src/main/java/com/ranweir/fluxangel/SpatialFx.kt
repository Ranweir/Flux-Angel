package com.ranweir.fluxangel

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.tanh

/**
 * Spatial surround: a software "wide and immersive" effect that runs inside the app's own audio pipeline, so it works on
 * every phone, with speakers or headphones, and needs nothing from the phone's hardware or from Dolby.
 *
 * It is NOT Dolby Atmos (that is a licensed technology of Dolby). It widens the stereo image (mid/side) and adds a little
 * side ambience (two short, quiet reflections with opposite polarity left and right) so the sound seems to come from around you.
 */
object SpatialFx {
    var enabled by mutableStateOf(false); private set
    var width by mutableIntStateOf(600); private set      // 0..1000
    var depth by mutableIntStateOf(400); private set      // 0..1000

    // plain copies read by the audio thread
    @Volatile internal var on = false
    @Volatile internal var widthF = 0.6f
    @Volatile internal var depthF = 0.4f

    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("flux", Context.MODE_PRIVATE)
        prefs = p
        enabled = p.getBoolean("sp_on", false)
        width = p.getInt("sp_width", 600).coerceIn(0, 1000)
        depth = p.getInt("sp_depth", 400).coerceIn(0, 1000)
        sync()
    }

    private fun sync() { on = enabled; widthF = width / 1000f; depthF = depth / 1000f }
    private fun save() { prefs?.edit()?.putBoolean("sp_on", enabled)?.putInt("sp_width", width)?.putInt("sp_depth", depth)?.apply() }

    fun updateEnabled(v: Boolean) { enabled = v; sync(); save() }
    fun updateWidth(v: Int) { width = v.coerceIn(0, 1000); sync(); save() }
    fun updateDepth(v: Int) { depth = v.coerceIn(0, 1000); sync(); save() }
    fun reset() { width = 600; depth = 400; sync(); save() }
}

/** Plugs into ExoPlayer's audio pipeline. Handles 16-bit stereo; anything else is passed through untouched. */
class SpatialProcessor : BaseAudioProcessor() {
    private var rate = 44100
    private var delayA = 0
    private var delayB = 0
    private var ring = FloatArray(1)
    private var pos = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET      // processor stays inactive for this stream
        }
        rate = inputAudioFormat.sampleRate
        delayA = max(1, (rate * 0.017f).toInt())           // 17 ms
        delayB = max(2, (rate * 0.029f).toInt())           // 29 ms
        ring = FloatArray(delayB + 1)
        pos = 0
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        if (!SpatialFx.on) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        inputBuffer.order(ByteOrder.nativeOrder())
        out.order(ByteOrder.nativeOrder())
        val w = SpatialFx.widthF
        val d = SpatialFx.depthF
        val sideGain = 1f + w * 1.2f
        val amb = d * 0.30f
        val headroom = 1f / (1f + 0.25f * w + 0.2f * d)
        val n = ring.size
        var i = inputBuffer.position()
        val end = inputBuffer.limit()
        while (i + 3 < end) {
            val l = inputBuffer.getShort(i) / 32768f
            val r = inputBuffer.getShort(i + 2) / 32768f
            val m = (l + r) * 0.5f
            val s = (l - r) * 0.5f * sideGain
            ring[pos] = s
            val a = ring[(pos - delayA + n) % n]
            val b = ring[(pos - delayB + n) % n]
            val ambience = (a * 0.6f + b * 0.4f) * amb
            pos = (pos + 1) % n
            val outL = soft((m + s + ambience) * headroom)
            val outR = soft((m - s - ambience) * headroom)
            out.putShort((outL * 32767f).toInt().toShort())
            out.putShort((outR * 32767f).toInt().toShort())
            i += 4
        }
        inputBuffer.position(end)
        out.flip()
    }

    /** Gentle limiter so boosted peaks never click. */
    private fun soft(x: Float): Float {
        val a = abs(x)
        return if (a <= 0.9f) x else (if (x > 0f) 1f else -1f) * (0.9f + 0.1f * tanh((a - 0.9f) / 0.1f))
    }
}
