package com.ranweir.fluxangel

import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException

class MusicService : MediaSessionService() {

    private var session: MediaSession? = null
    val player get() = session?.player

    private val ticker = android.os.Handler(android.os.Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val p = session?.player ?: return
            if (p.isPlaying) {
                WidgetUpdater.tick(this@MusicService, p)
                ticker.postDelayed(this, 1000)
            }
        }
    }

    companion object {
        @Volatile var instance: MusicService? = null
    }

    override fun onCreate() {
        super.onCreate()

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)

        val resolving = ResolvingDataSource.Factory(DefaultDataSource.Factory(this, http)) { spec ->
            if (YouTubeRepo.isYouTube(spec.uri)) {
                try {
                    val direct = YouTubeRepo.audioUrl(spec.uri.toString())
                    spec.withUri(Uri.parse(direct))
                        .withAdditionalHeaders(mapOf("User-Agent" to YouTubeRepo.userAgentFor(direct)))
                } catch (e: Exception) {
                    throw IOException("Could not load song: ${e.message}", e)
                }
            } else spec
        }

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(resolving))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)   // keeps CPU + Wi-Fi alive when screen is locked
            .build()

        session = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>
                ): ListenableFuture<MutableList<MediaItem>> {
                    val fixed = mediaItems.map { it.buildUpon().setUri(it.requestMetadata.mediaUri ?: Uri.parse(it.mediaId)).build() }.toMutableList()
                    return Futures.immediateFuture(fixed)
                }
            })
            .build()

        instance = this
        SoundFx.attach(this, player.audioSessionId)
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { SoundFx.attach(this@MusicService, audioSessionId) }

            override fun onEvents(p: androidx.media3.common.Player, events: androidx.media3.common.Player.Events) {
                WidgetUpdater.update(this@MusicService, p)
                ticker.removeCallbacks(tick)
                if (p.isPlaying) ticker.post(tick)
            }
        })
        WidgetUpdater.update(this, player)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        ticker.removeCallbacks(tick)
        SoundFx.detach()
        instance = null
        WidgetUpdater.update(this, null)
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
