package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED (pure black)")
}

enum class CapsuleStyle(val label: String, val desc: String) {
    SMOKE_GLASS("Smoke glass", "Dark smoky glass, white icon"),
    DEEP_SMOKE("Deep smoke", "Darker, stronger contrast"),
    SMOKE_CYAN("Smoke and cyan", "Smoke glass with cyan icon and rim"),
    BRIGHT_RIM("Bright rim", "Smoke glass with a bright glass edge"),
    FROSTED_SMOKE("Light smoke", "Lighter, more see-through smoke"),
    SMOKE_GRADIENT("Smoke gradient", "Lighter at the top, darker at the bottom"),
    ORIGINAL("Original liquid glass", "The earlier white glass capsule")
}

class FluxLook(val bg: Brush, val glass: Color, val border: Color, val fg: Color = Color.White, val accent: Color = Cyan)

val LocalLook = staticCompositionLocalOf {
    FluxLook(SolidColor(Color.Black), Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.2f))
}

/** Main text/icon colour for the current theme (white on dark, ink on light), with optional alpha. */
@Composable
fun fg(alpha: Float = 1f): Color = LocalLook.current.fg.copy(alpha = alpha)

/** Accent usable as text/icon colour: cyan on dark, deep teal on light (bright cyan is unreadable on white). */
@Composable
fun accentText(): Color = LocalLook.current.accent

val Cyan = Color(0xFF2FE3F2)          // main accent
val Ink = Color(0xFF14101C)           // dark text/icons on lime & pastel cards
val Accent = Cyan
val Highlight = Cyan
val Pink = Color(0xFFFF7BD5)
val Violet = Color(0xFF7C5CFF)
val Lavender = Color(0xFFC9A3F5)
val Peach = Color(0xFFF6BFA3)
val Sky = Color(0xFF9FD8F2)
val NavBg = Color(0xFF161B24)

@Composable
fun FluxTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        else -> true
    }
    val look = when {
        mode == ThemeMode.AMOLED -> FluxLook(
            SolidColor(Color.Black), Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.12f)
        )
        dark -> FluxLook(
            // near-black with a soft purple glow at the top
            Brush.verticalGradient(0f to Color(0xFF12344A), 0.35f to Color(0xFF0E1218), 1f to Color(0xFF0A0B10)),
            Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.12f)
        )
        else -> FluxLook(
            // soft lavender-white
            Brush.verticalGradient(0f to Color(0xFFD3F1F8), 0.4f to Color(0xFFEFF8FB), 1f to Color(0xFFFAFDFE)),
            Color.Black.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.10f),
            fg = Ink, accent = Color(0xFF0A8DA6)
        )
    }
    val scheme = darkColorScheme(
        primary = Accent, onPrimary = Ink,
        secondary = Highlight,
        background = Color.Transparent, onBackground = Color.White,
        surface = Color(0xFF1E1A2B), onSurface = Color.White,
        onSurfaceVariant = Color.White.copy(alpha = 0.72f),
        error = Color(0xFFFF8A80)
    )
    CompositionLocalProvider(LocalLook provides look) {
        MaterialTheme(colorScheme = scheme) {
            Surface(color = Color.Transparent, contentColor = look.fg, content = content)
        }
    }
}

/** Frosted-glass look used by every card. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp)): Modifier {
    val look = LocalLook.current
    return this.clip(shape).background(look.glass, shape).border(1.dp, look.border, shape)
}

/** Where the floating navigation glass sits. */
enum class NavPosition(val label: String) { RIGHT("Right"), LEFT("Left"), BOTTOM("Bottom") }

/** Look of the navigation bar itself (the capsule inside it is [CapsuleStyle]). */
enum class BarStyle(val label: String, val desc: String) {
    DEFAULT("Default", "The current frosted glass pill"),
    LIQUID("Liquid glass", "Clear glass with bright rim and light reflections"),
    FROSTED("Frosted glass", "Milky, denser frost like iOS sheets"),
    BLUR("Blur", "Very strong blur, almost no tint or border"),
    GLOW("Glow", "Cyan to violet neon rim with a soft glow"),
    MIDNIGHT("Midnight", "Dark smoked glass, same in every theme")
}
