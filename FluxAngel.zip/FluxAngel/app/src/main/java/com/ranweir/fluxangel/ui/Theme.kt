package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED (pure black)")
}

class FluxLook(val bg: Brush, val glass: Color, val border: Color)

val LocalLook = staticCompositionLocalOf {
    FluxLook(SolidColor(Color.Black), Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.2f))
}

val Accent = Color(0xFF7C5CFF)
val Highlight = Color(0xFF7FE9FF)
val Pink = Color(0xFFFF7BD5)

@Composable
fun FluxTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        else -> true
    }
    val look = when {
        mode == ThemeMode.AMOLED -> FluxLook(
            SolidColor(Color.Black), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.14f)
        )
        dark -> FluxLook(
            Brush.linearGradient(listOf(Color(0xFF1C1745), Color(0xFF2E2268), Color(0xFF171238))),
            Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.18f)
        )
        else -> FluxLook(
            Brush.linearGradient(listOf(Color(0xFFB7B0FA), Color(0xFF9D8DF1), Color(0xFFC6AFF6))),
            Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.45f)
        )
    }
    val scheme = darkColorScheme(
        primary = Accent, onPrimary = Color.White,
        secondary = Highlight,
        background = Color.Transparent, onBackground = Color.White,
        surface = Color(0xFF1E1B36), onSurface = Color.White,
        onSurfaceVariant = Color.White.copy(alpha = 0.72f),
        error = Color(0xFFFF8A80)
    )
    CompositionLocalProvider(LocalLook provides look) {
        MaterialTheme(colorScheme = scheme) {
            Surface(color = Color.Transparent, contentColor = Color.White, content = content)
        }
    }
}

/** Frosted-glass look used by every card. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp)): Modifier {
    val look = LocalLook.current
    return this.clip(shape).background(look.glass, shape).border(1.dp, look.border, shape)
}
