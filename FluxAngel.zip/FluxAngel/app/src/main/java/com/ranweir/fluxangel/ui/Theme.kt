package com.ranweir.fluxangel.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED (pure black)")
}

private val Violet = Color(0xFF8E6BFF)
private val Cyan = Color(0xFF14C8E8)

@Composable
fun FluxTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        else -> true
    }
    val scheme = when {
        mode == ThemeMode.AMOLED -> darkColorScheme(
            primary = Violet, secondary = Cyan,
            background = Color.Black, surface = Color.Black,
            surfaceVariant = Color(0xFF151515),
            onBackground = Color.White, onSurface = Color.White,
            onSurfaceVariant = Color(0xFFB8B8B8)
        )
        dark -> darkColorScheme(
            primary = Violet, secondary = Cyan,
            background = Color(0xFF121218), surface = Color(0xFF121218),
            surfaceVariant = Color(0xFF22222C)
        )
        else -> lightColorScheme(
            primary = Color(0xFF5B34E0), secondary = Color(0xFF0A8FA8),
            background = Color(0xFFFAF9FF), surface = Color(0xFFFAF9FF),
            surfaceVariant = Color(0xFFEAE6F7)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
