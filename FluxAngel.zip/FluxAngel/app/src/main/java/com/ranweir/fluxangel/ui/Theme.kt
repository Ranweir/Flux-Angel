package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED (pure black)")
}

class FluxLook(val bg: Brush, val glass: Color, val border: Color)

val LocalLook = staticCompositionLocalOf {
    FluxLook(SolidColor(Color.Black), Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.2f))
}

val Lime = Color(0xFFC9EA4B)          // main accent
val Ink = Color(0xFF14101C)           // dark text/icons on lime & pastel cards
val Accent = Lime
val Highlight = Lime
val Pink = Color(0xFFFF7BD5)
val Violet = Color(0xFF7C5CFF)
val Lavender = Color(0xFFC9A3F5)
val Peach = Color(0xFFF6BFA3)
val Sky = Color(0xFF9FD8F2)
val NavBg = Color(0xFF1B1823)

@Composable
fun FluxTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        else -> true
    }
    val look = when {
        mode == ThemeMode.AMOLED -> FluxLook(
            SolidColor(Color.Black), Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.12f)
        )
        dark -> FluxLook(
            // near-black with a soft purple glow at the top
            Brush.verticalGradient(0f to Color(0xFF2E1B4A), 0.35f to Color(0xFF110E18), 1f to Color(0xFF0B0A10)),
            Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.12f)
        )
        else -> FluxLook(
            Brush.linearGradient(listOf(Color(0xFFB7B0FA), Color(0xFF9D8DF1), Color(0xFFC6AFF6))),
            Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.45f)
        )
    }
    val scheme = darkColorScheme(
        primary = Accent, onPrimary = Ink,
        secondary = Highlight,
        background = Color.Transparent, onBackground = Color.White,
        surface = Color(0xFF1E1A2B), onSurface = Color.White,
        onSurfaceVariant = Color.White.copy(alpha = 0.72f),
        error = Color(0xFFFF8A80)
    )
    CompositionLocalProvider(LocalLook provides look) {
        MaterialTheme(colorScheme = scheme) {
            Surface(color = Color.Transparent, contentColor = Color.White, content = content)
        }
    }
}

/** Frosted-glass look used by every card. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp)): Modifier {
    val look = LocalLook.current
    return this.clip(shape).background(look.glass, shape).border(1.dp, look.border, shape)
}
