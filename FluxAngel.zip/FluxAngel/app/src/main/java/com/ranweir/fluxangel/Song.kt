package com.ranweir.fluxangel

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val url: String,
    val title: String,
    val artist: String,
    val thumb: String,
    val durationSec: Long
) {
    fun toMediaItem(): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .apply { if (thumb.isNotBlank()) setArtworkUri(Uri.parse(thumb)) }
            .build()
        return MediaItem.Builder()
            .setMediaId(url)
            .setUri(url)
            .setMediaMetadata(meta)
            .build()
    }
}
