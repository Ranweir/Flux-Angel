package com.ranweir.fluxangel

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONObject

data class Song(
    val url: String,
    val title: String,
    val artist: String,
    val thumb: String,
    val durationSec: Long
) {
    fun toMediaItem(): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .apply { if (thumb.isNotBlank()) setArtworkUri(Uri.parse(thumb)) }
            .build()
        return MediaItem.Builder()
            .setMediaId(url)
            .setUri(url)
            .setMediaMetadata(meta)
            .build()
    }

    fun toJson(): JSONObject = JSONObject()
        .put("u", url).put("t", title).put("a", artist).put("i", thumb).put("d", durationSec)
}

fun JSONObject.toSong() = Song(getString("u"), getString("t"), getString("a"), getString("i"), getLong("d"))

data class Playlist(val name: String, val songs: List<Song>)
