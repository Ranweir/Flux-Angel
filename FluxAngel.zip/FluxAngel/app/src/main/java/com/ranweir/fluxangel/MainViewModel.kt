package com.ranweir.fluxangel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.ranweir.fluxangel.ui.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("flux", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(
        runCatching { ThemeMode.valueOf(prefs.getString("theme", "SYSTEM")!!) }
            .getOrDefault(ThemeMode.SYSTEM)
    )
        private set

    var results by mutableStateOf<List<Song>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    var currentMeta by mutableStateOf<MediaMetadata?>(null); private set
    var currentId by mutableStateOf<String?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var position by mutableStateOf(0L); private set
    var duration by mutableStateOf(0L); private set

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@MainViewModel.isPlaying = isPlaying }
        override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) { currentMeta = mediaMetadata }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentId = mediaItem?.mediaId
            position = 0L
        }
        override fun onPlayerError(error: PlaybackException) {
            this@MainViewModel.error = "Playback error: ${error.cause?.message ?: error.message}"
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            currentMeta = c.mediaMetadata
            currentId = c.currentMediaItem?.mediaId
            isPlaying = c.isPlaying
        }, MoreExecutors.directExecutor())

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let {
                    position = it.currentPosition.coerceAtLeast(0L)
                    duration = it.duration.coerceAtLeast(0L)
                }
            }
        }
        search("latest songs")
    }

    fun search(query: String) {
        if (query.isBlank()) return
        loading = true
        error = null
        viewModelScope.launch {
            try {
                results = withContext(Dispatchers.IO) { YouTubeRepo.search(query.trim()) }
            } catch (e: Exception) {
                error = "Search failed: ${e.message}"
            }
            loading = false
        }
    }

    fun play(index: Int) {
        val c = controller ?: return
        error = null
        c.setMediaItems(results.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun dismissError() { error = null }

    fun setTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putString("theme", mode.name).apply()
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
