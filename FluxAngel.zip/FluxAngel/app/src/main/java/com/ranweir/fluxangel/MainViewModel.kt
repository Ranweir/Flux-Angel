package com.ranweir.fluxangel

import android.app.Application
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.ranweir.fluxangel.ui.CapsuleStyle
import com.ranweir.fluxangel.ui.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("flux", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(
        runCatching { ThemeMode.valueOf(prefs.getString("theme", "DARK")!!) }
            .getOrDefault(ThemeMode.DARK)
    )
        private set

    var capsuleStyle by mutableStateOf(
        runCatching { CapsuleStyle.valueOf(prefs.getString("capsule_style", "SMOKE_GLASS")!!) }
            .getOrDefault(CapsuleStyle.SMOKE_GLASS)
    )
        private set

    var glassBlur by mutableStateOf(prefs.getBoolean("glass_blur", true))
        private set

    // ---- profile picture (stored as a small square JPEG in the app's private files) ----
    var profileVersion by mutableStateOf(prefs.getLong("profile_v", 0L))
        private set
    val profileFile: java.io.File get() = java.io.File(getApplication<Application>().filesDir, "profile.jpg")

    fun setProfilePhoto(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { saveProfile(uri) }.getOrDefault(false) }
            if (ok) {
                profileVersion = System.currentTimeMillis()
                prefs.edit().putLong("profile_v", profileVersion).apply()
            } else toast("Could not use that photo")
        }
    }

    fun clearProfilePhoto() {
        runCatching { profileFile.delete() }
        profileVersion = 0L
        prefs.edit().putLong("profile_v", 0L).apply()
    }

    /** Decodes the picked image (down-sampled), fixes rotation, centre-crops to a square and saves 512x512. */
    private fun saveProfile(uri: Uri): Boolean {
        val cr = getApplication<Application>().contentResolver
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        val src = cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
            ?: return false
        val rotation = cr.openInputStream(uri)?.use { s ->
            when (android.media.ExifInterface(s).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
        } ?: 0f
        val side = minOf(src.width, src.height)
        val matrix = android.graphics.Matrix().apply { postRotate(rotation) }
        val square = android.graphics.Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side, matrix, true)
        val out = android.graphics.Bitmap.createScaledBitmap(square, 512, 512, true)
        profileFile.outputStream().use { out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
        return true
    }

    // ---- search / home data ----
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Song>>(emptyList()); private set
    var trending by mutableStateOf<List<Song>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    // ---- library data (saved on device) ----
    var history by mutableStateOf(loadSongs("history")); private set
    var favorites by mutableStateOf(loadSongs("favorites")); private set
    var playlists by mutableStateOf(loadPlaylists()); private set
    /** Songs saved offline on the device (shown as "Downloads" in Library). */
    var downloads by mutableStateOf(loadDownloads()); private set

    // ---- player state ----
    var currentMeta by mutableStateOf<MediaMetadata?>(null); private set
    var currentId by mutableStateOf<String?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var position by mutableStateOf(0L); private set
    var duration by mutableStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF); private set

    private var controller: MediaController? = null
    private var queue: List<Song> = emptyList()

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@MainViewModel.isPlaying = isPlaying }
        override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) { currentMeta = mediaMetadata }
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle = shuffleModeEnabled }
        override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentId = mediaItem?.mediaId
            position = 0L
            queue.firstOrNull { it.url == mediaItem?.mediaId }?.let { addHistory(it) }
        }
        override fun onPlayerError(error: PlaybackException) {
            this@MainViewModel.error = "Playback error: ${error.cause?.message ?: error.message}"
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            currentMeta = c.mediaMetadata
            currentId = c.currentMediaItem?.mediaId
            isPlaying = c.isPlaying
            shuffle = c.shuffleModeEnabled
            repeatMode = c.repeatMode
        }, MoreExecutors.directExecutor())

        registerDownloadReceiver()
        syncDownloads()

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let {
                    position = it.currentPosition.coerceAtLeast(0L)
                    duration = it.duration.coerceAtLeast(0L)
                }
            }
        }
        viewModelScope.launch {
            try {
                trending = withContext(Dispatchers.IO) { YouTubeRepo.search("trending songs") }
                if (results.isEmpty()) results = trending
            } catch (e: Exception) {
                error = "Could not load songs: ${e.message}"
            }
        }
    }

    // ---------- search ----------
    fun search(q: String) {
        if (q.isBlank()) return
        query = q
        loading = true
        error = null
        viewModelScope.launch {
            try {
                results = withContext(Dispatchers.IO) { YouTubeRepo.search(q.trim()) }
            } catch (e: Exception) {
                error = "Search failed: ${e.message}"
            }
            loading = false
        }
    }

    // ---------- playback ----------
    fun play(songs: List<Song>, index: Int) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        queue = songs
        error = null
        c.setMediaItems(songs.map { it.toMediaItem(downloadUri(it.url)) }, index.coerceIn(0, songs.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun dismissError() { error = null }

    fun currentSong(): Song? {
        val id = currentId ?: return null
        queue.firstOrNull { it.url == id }?.let { return it }
        val m = currentMeta ?: return null
        return Song(id, m.title?.toString() ?: "", m.artist?.toString() ?: "", m.artworkUri?.toString() ?: "", duration / 1000)
    }

    // ---------- history ----------
    private fun addHistory(song: Song) {
        history = (listOf(song) + history.filterNot { it.url == song.url }).take(50)
        saveSongs("history", history)
    }
    fun clearHistory() { history = emptyList(); saveSongs("history", history) }

    // ---------- favorites & playlists ----------
    fun isFavorite(url: String) = favorites.any { it.url == url }
    fun toggleFavorite(song: Song) {
        favorites = if (isFavorite(song.url)) favorites.filterNot { it.url == song.url } else listOf(song) + favorites
        saveSongs("favorites", favorites)
    }
    fun createPlaylist(name: String) {
        playlists = playlists + Playlist(name, emptyList())
        savePlaylists()
    }
    fun deletePlaylist(index: Int) {
        playlists = playlists.filterIndexed { i, _ -> i != index }
        savePlaylists()
    }
    fun togglePlaylistSong(index: Int, song: Song) {
        playlists = playlists.mapIndexed { i, p ->
            if (i != index) p
            else if (p.songs.any { it.url == song.url }) p.copy(songs = p.songs.filterNot { it.url == song.url })
            else p.copy(songs = p.songs + song)
        }
        savePlaylists()
    }
    fun savedSongs(): List<Song> = (favorites + playlists.flatMap { it.songs } + downloads.map { it.song }).distinctBy { it.url }

    private fun loadSongs(key: String): List<Song> = runCatching {
        val arr = JSONArray(prefs.getString(key, "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).toSong() }
    }.getOrDefault(emptyList())

    private fun saveSongs(key: String, list: List<Song>) {
        prefs.edit().putString(key, JSONArray(list.map { it.toJson() }).toString()).apply()
    }

    private fun loadPlaylists(): List<Playlist> = runCatching {
        val arr = JSONArray(prefs.getString("playlists", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val s = o.getJSONArray("s")
            Playlist(o.getString("n"), (0 until s.length()).map { j -> s.getJSONObject(j).toSong() })
        }
    }.getOrDefault(emptyList())

    private fun savePlaylists() {
        val arr = JSONArray(playlists.map { p ->
            JSONObject().put("n", p.name).put("s", JSONArray(p.songs.map { it.toJson() }))
        })
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    // ---------- download (best quality, audio only) ----------
    private fun toast(msg: String) {
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_LONG).show()
    }

    private val dm get() = getApplication<Application>().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun isDownloaded(url: String) = downloads.any { it.song.url == url }
    private fun downloadUri(url: String): String? = downloads.firstOrNull { it.song.url == url }?.uri

    fun download(song: Song) {
        if (isDownloaded(song.url)) { toast("Already downloaded"); return }
        if (pendingDownloads().containsValue(song.url)) { toast("Already downloading"); return }
        toast("Preparing download…")
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { YouTubeRepo.resolve(song.url, forDownload = true) }
                val safe = song.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(100).ifBlank { "song" }
                val req = DownloadManager.Request(Uri.parse(r.url))
                    .setTitle(song.title)
                    .setDescription("Flux Angel")
                    .setMimeType(r.mime)
                    .addRequestHeader("User-Agent", YouTubeRepo.userAgentFor(r.url))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "Flux Angel/$safe.${r.ext}")
                val id = dm.enqueue(req)
                // remember id -> song so it still lands in Library even if the app is closed meanwhile
                savePending(pendingDownloads() + (id to song.url), song)
                toast("Downloading (${r.kbps} kbps): ${song.title}")
            } catch (e: Exception) {
                toast("Download failed: ${e.message}")
            }
        }
    }

    fun removeDownload(song: Song) {
        val d = downloads.firstOrNull { it.song.url == song.url } ?: return
        runCatching { dm.remove(d.id) }
        downloads = downloads.filterNot { it.song.url == song.url }
        saveDownloads()
        toast("Download removed")
    }

    // pending: downloadId -> song url (songs themselves kept in "pending_songs")
    private fun pendingDownloads(): Map<Long, String> = runCatching {
        val o = JSONObject(prefs.getString("pending", "{}")!!)
        o.keys().asSequence().associate { it.toLong() to o.getString(it) }
    }.getOrDefault(emptyMap())

    private fun savePending(map: Map<Long, String>, newSong: Song? = null) {
        val o = JSONObject(); map.forEach { (k, v) -> o.put(k.toString(), v) }
        val e = prefs.edit().putString("pending", o.toString())
        if (newSong != null) {
            val songs = loadSongs("pending_songs").filterNot { it.url == newSong.url } + newSong
            e.putString("pending_songs", JSONArray(songs.map { it.toJson() }).toString())
        }
        e.apply()
    }

    private fun registerDownloadReceiver() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) { syncDownloads() }
        }
        ContextCompat.registerReceiver(
            getApplication<Application>(), receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED
        )
    }

    /** Moves finished downloads into [downloads] and drops ones the user deleted. */
    private fun syncDownloads() {
        val pending = pendingDownloads().toMutableMap()
        val songs = loadSongs("pending_songs")
        var list = downloads
        for ((id, url) in pending.toMap()) {
            val c = dm.query(DownloadManager.Query().setFilterById(id))
            c.use {
                if (!it.moveToFirst()) { pending.remove(id); return@use }   // cancelled / removed
                when (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val song = songs.firstOrNull { s -> s.url == url }
                        val uri = dm.getUriForDownloadedFile(id)
                        if (song != null && uri != null) {
                            list = listOf(DownloadedSong(song, uri.toString(), id)) + list.filterNot { d -> d.song.url == url }
                        }
                        pending.remove(id)
                    }
                    DownloadManager.STATUS_FAILED -> pending.remove(id)
                    else -> {}
                }
                Unit
            }
        }
        // drop downloads whose entry was removed from the system Downloads app
        list = list.filter { d ->
            dm.query(DownloadManager.Query().setFilterById(d.id)).use { c -> c.moveToFirst() }
        }
        val remaining = songs.filter { s -> pending.containsValue(s.url) }
        prefs.edit().putString("pending_songs", JSONArray(remaining.map { it.toJson() }).toString()).apply()
        savePending(pending)
        if (list != downloads) { downloads = list; saveDownloads() }
    }

    private fun loadDownloads(): List<DownloadedSong> = runCatching {
        val arr = JSONArray(prefs.getString("downloads", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            DownloadedSong(o.getJSONObject("song").toSong(), o.getString("uri"), o.getLong("id"))
        }
    }.getOrDefault(emptyList())

    private fun saveDownloads() {
        val arr = JSONArray(downloads.map {
            JSONObject().put("song", it.song.toJson()).put("uri", it.uri).put("id", it.id)
        })
        prefs.edit().putString("downloads", arr.toString()).apply()
    }

    // ---------- settings ----------
    fun updateGlassBlur(on: Boolean) {
        glassBlur = on
        prefs.edit().putBoolean("glass_blur", on).apply()
    }

    fun updateCapsuleStyle(style: CapsuleStyle) {
        capsuleStyle = style
        prefs.edit().putString("capsule_style", style.name).apply()
    }

    fun setTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putString("theme", mode.name).apply()
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
