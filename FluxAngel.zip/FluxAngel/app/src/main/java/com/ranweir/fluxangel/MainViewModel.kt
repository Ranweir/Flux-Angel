package com.ranweir.fluxangel

import android.app.Application
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.ranweir.fluxangel.ui.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("flux", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(
        runCatching { ThemeMode.valueOf(prefs.getString("theme", "SYSTEM")!!) }
            .getOrDefault(ThemeMode.SYSTEM)
    )
        private set

    // ---- search / home data ----
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Song>>(emptyList()); private set
    var trending by mutableStateOf<List<Song>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    // ---- library data (saved on device) ----
    var history by mutableStateOf(loadSongs("history")); private set
    var favorites by mutableStateOf(loadSongs("favorites")); private set
    var playlists by mutableStateOf(loadPlaylists()); private set

    // ---- player state ----
    var currentMeta by mutableStateOf<MediaMetadata?>(null); private set
    var currentId by mutableStateOf<String?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var position by mutableStateOf(0L); private set
    var duration by mutableStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF); private set

    private var controller: MediaController? = null
    private var queue: List<Song> = emptyList()

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@MainViewModel.isPlaying = isPlaying }
        override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) { currentMeta = mediaMetadata }
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle = shuffleModeEnabled }
        override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentId = mediaItem?.mediaId
            position = 0L
            queue.firstOrNull { it.url == mediaItem?.mediaId }?.let { addHistory(it) }
        }
        override fun onPlayerError(error: PlaybackException) {
            this@MainViewModel.error = "Playback error: ${error.cause?.message ?: error.message}"
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            currentMeta = c.mediaMetadata
            currentId = c.currentMediaItem?.mediaId
            isPlaying = c.isPlaying
            shuffle = c.shuffleModeEnabled
            repeatMode = c.repeatMode
        }, MoreExecutors.directExecutor())

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let {
                    position = it.currentPosition.coerceAtLeast(0L)
                    duration = it.duration.coerceAtLeast(0L)
                }
            }
        }
        viewModelScope.launch {
            try {
                trending = withContext(Dispatchers.IO) { YouTubeRepo.search("trending songs") }
                if (results.isEmpty()) results = trending
            } catch (e: Exception) {
                error = "Could not load songs: ${e.message}"
            }
        }
    }

    // ---------- search ----------
    fun search(q: String) {
        if (q.isBlank()) return
        query = q
        loading = true
        error = null
        viewModelScope.launch {
            try {
                results = withContext(Dispatchers.IO) { YouTubeRepo.search(q.trim()) }
            } catch (e: Exception) {
                error = "Search failed: ${e.message}"
            }
            loading = false
        }
    }

    // ---------- playback ----------
    fun play(songs: List<Song>, index: Int) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        queue = songs
        error = null
        c.setMediaItems(songs.map { it.toMediaItem() }, index.coerceIn(0, songs.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun dismissError() { error = null }

    fun currentSong(): Song? {
        val id = currentId ?: return null
        queue.firstOrNull { it.url == id }?.let { return it }
        val m = currentMeta ?: return null
        return Song(id, m.title?.toString() ?: "", m.artist?.toString() ?: "", m.artworkUri?.toString() ?: "", duration / 1000)
    }

    // ---------- history ----------
    private fun addHistory(song: Song) {
        history = (listOf(song) + history.filterNot { it.url == song.url }).take(50)
        saveSongs("history", history)
    }
    fun clearHistory() { history = emptyList(); saveSongs("history", history) }

    // ---------- favorites & playlists ----------
    fun isFavorite(url: String) = favorites.any { it.url == url }
    fun toggleFavorite(song: Song) {
        favorites = if (isFavorite(song.url)) favorites.filterNot { it.url == song.url } else listOf(song) + favorites
        saveSongs("favorites", favorites)
    }
    fun createPlaylist(name: String) {
        playlists = playlists + Playlist(name, emptyList())
        savePlaylists()
    }
    fun deletePlaylist(index: Int) {
        playlists = playlists.filterIndexed { i, _ -> i != index }
        savePlaylists()
    }
    fun togglePlaylistSong(index: Int, song: Song) {
        playlists = playlists.mapIndexed { i, p ->
            if (i != index) p
            else if (p.songs.any { it.url == song.url }) p.copy(songs = p.songs.filterNot { it.url == song.url })
            else p.copy(songs = p.songs + song)
        }
        savePlaylists()
    }
    fun savedSongs(): List<Song> = (favorites + playlists.flatMap { it.songs }).distinctBy { it.url }

    private fun loadSongs(key: String): List<Song> = runCatching {
        val arr = JSONArray(prefs.getString(key, "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).toSong() }
    }.getOrDefault(emptyList())

    private fun saveSongs(key: String, list: List<Song>) {
        prefs.edit().putString(key, JSONArray(list.map { it.toJson() }).toString()).apply()
    }

    private fun loadPlaylists(): List<Playlist> = runCatching {
        val arr = JSONArray(prefs.getString("playlists", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val s = o.getJSONArray("s")
            Playlist(o.getString("n"), (0 until s.length()).map { j -> s.getJSONObject(j).toSong() })
        }
    }.getOrDefault(emptyList())

    private fun savePlaylists() {
        val arr = JSONArray(playlists.map { p ->
            JSONObject().put("n", p.name).put("s", JSONArray(p.songs.map { it.toJson() }))
        })
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    // ---------- download (best quality, audio only) ----------
    private fun toast(msg: String) {
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_LONG).show()
    }

    fun download(song: Song) {
        toast("Preparing download…")
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { YouTubeRepo.resolve(song.url, forDownload = true) }
                val safe = song.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(100).ifBlank { "song" }
                val req = DownloadManager.Request(Uri.parse(r.url))
                    .setTitle(song.title)
                    .setDescription("Flux Angel")
                    .setMimeType(r.mime)
                    .addRequestHeader("User-Agent", YouTubeRepo.userAgentFor(r.url))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "Flux Angel/$safe.${r.ext}")
                val dm = getApplication<Application>().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(req)
                toast("Downloading (${r.kbps} kbps): ${song.title}")
            } catch (e: Exception) {
                toast("Download failed: ${e.message}")
            }
        }
    }

    // ---------- settings ----------
    fun setTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putString("theme", mode.name).apply()
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
