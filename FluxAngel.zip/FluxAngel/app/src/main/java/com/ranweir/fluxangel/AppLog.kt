package com.ranweir.fluxangel

import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Persistent record of crashes and errors, shown in Settings, Error & crash logs. */
object AppLog {
    class Entry(val time: Long, val kind: String, val text: String)

    private var file: File? = null
    private const val MARK = "\n### "
    private const val MAX_BYTES = 300_000
    private const val KEEP_BYTES = 200_000

    fun init(ctx: Context) { file = File(ctx.filesDir, "app_log.txt") }

    /** kind: CRASH, PLAYBACK, DOWNLOAD, NETWORK or ERROR */
    @Synchronized
    fun add(kind: String, message: String, t: Throwable? = null) {
        runCatching {
            val f = file ?: return
            val body = buildString {
                append(message.replace(MARK, "\n## "))
                if (t != null) append("\n").append(android.util.Log.getStackTraceString(t).replace(MARK, "\n## "))
            }.trimEnd()
            f.appendText("### ${System.currentTimeMillis()}|$kind\n$body\n")
            if (f.length() > MAX_BYTES) {
                val txt = f.readText()
                val cut = txt.indexOf("### ", txt.length - KEEP_BYTES).let { if (it < 0) txt.length - KEEP_BYTES else it }
                f.writeText(txt.substring(cut))
            }
        }
    }

    /** Newest first. */
    @Synchronized
    fun read(): List<Entry> = runCatching {
        val f = file ?: return emptyList()
        if (!f.exists()) return emptyList()
        ("\n" + f.readText()).split(MARK).drop(1).mapNotNull { chunk ->
            val nl = chunk.indexOf('\n')
            val head = if (nl < 0) chunk else chunk.substring(0, nl)
            val parts = head.split("|")
            val time = parts.getOrNull(0)?.toLongOrNull() ?: return@mapNotNull null
            Entry(time, parts.getOrNull(1) ?: "ERROR", if (nl < 0) "" else chunk.substring(nl + 1).trimEnd())
        }.reversed()
    }.getOrDefault(emptyList())

    @Synchronized
    fun clear() { runCatching { file?.delete() } }

    fun format(time: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault()).format(Date(time))

    fun exportText(ctx: Context, entries: List<Entry>): String {
        val ver = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
        return buildString {
            append("Flux Angel v$ver | Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | ${Build.MANUFACTURER} ${Build.MODEL}\n")
            entries.forEach { append("\n[").append(format(it.time)).append("] ").append(it.kind).append("\n").append(it.text).append("\n") }
        }
    }
}
