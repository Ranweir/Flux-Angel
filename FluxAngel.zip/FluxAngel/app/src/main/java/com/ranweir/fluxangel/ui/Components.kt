package com.ranweir.fluxangel.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

enum class NavTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    EXPLORE("Explore", Icons.Default.Search),
    LIBRARY("Library", Icons.Default.LibraryMusic),
    HISTORY("History", Icons.Default.History)
}

/** Provided by App: extra bottom space so lists scroll clear of the floating mini player. */
val LocalBottomInset = compositionLocalOf { 0.dp }

/**
 * Floating liquid-glass pill on the right edge. Tap a tab, or drag a finger up/down along the
 * pill: the glass bubble follows the finger smoothly (no tab rebuilds while dragging) and the
 * tab is switched once when the finger is released.
 */
@Composable
fun SideNav(
    selected: NavTab, onSelect: (NavTab) -> Unit, backdrop: BackdropState, blur: Boolean, modifier: Modifier = Modifier
) {
    val tabs = NavTab.values()
    val slot = 66.dp            // height of one tab
    val padV = 7.dp
    val pillW = 52.dp
    val inset = 3.dp            // gap between pill edge and the glass capsule
    val shape = RoundedCornerShape(30.dp)
    val capsule = RoundedCornerShape(50)
    val dark = LocalLook.current.fg == Color.White
    val tabAccent = if (dark) Cyan else Color(0xFF0A8DA6)

    val density = LocalDensity.current
    val stepPx = with(density) { slot.toPx() }
    val padPx = with(density) { padV.toPx() }
    val lastIdx = tabs.lastIndex
    val currentOnSelect by rememberUpdatedState(onSelect)
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // capsule position as a fractional tab index; read only inside graphicsLayer => no recomposition per frame
    val settled = remember { Animatable(selected.ordinal.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(selected.ordinal.toFloat()) }
    val scale = animateFloatAsState(
        if (dragging) 1.07f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "capsuleScale"
    )
    LaunchedEffect(selected, dragging) {
        if (!dragging) settled.animateTo(
            selected.ordinal.toFloat(), spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)
        )
    }
    val hover by remember {
        derivedStateOf { (if (dragging) dragPos else settled.value).roundToInt().coerceIn(0, lastIdx) }
    }
    LaunchedEffect(hover) {
        if (dragging) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    fun posAt(y: Float) = ((y - padPx - stepPx / 2f) / stepPx).coerceIn(0f, lastIdx.toFloat())
    fun finishDrag() {
        val target = dragPos.roundToInt().coerceIn(0, lastIdx)
        scope.launch {
            settled.snapTo(dragPos)
            dragging = false
            currentOnSelect(tabs[target])
        }
    }

    // neutral frosted tint (no colour cast). With real blur it is light; without blur (Android < 12) it is denser.
    val real = backdrop.supported && blur
    val tintTop = when {
        real && dark -> Color.White.copy(alpha = 0.16f)
        real -> Color.White.copy(alpha = 0.50f)
        dark -> Color(0xFF2A303A).copy(alpha = 0.90f)
        else -> Color(0xFFF3F9FB).copy(alpha = 0.92f)
    }
    val tintBottom = when {
        real && dark -> Color.White.copy(alpha = 0.06f)
        real -> Color.White.copy(alpha = 0.24f)
        dark -> Color(0xFF1B2027).copy(alpha = 0.90f)
        else -> Color(0xFFE2EFF3).copy(alpha = 0.92f)
    }
    val specular = if (dark) 0.28f else 0.70f
    val capTop = if (dark) Color.White.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.85f)
    val capBottom = if (dark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.45f)

    Box(
        modifier
            .width(pillW)
            .height(slot * tabs.size + padV * 2)
            .shadow(
                10.dp, shape,
                ambientColor = Color.Black.copy(alpha = 0.20f), spotColor = Color.Black.copy(alpha = 0.30f)
            )
            .clip(shape)
            .backdropBlur(backdrop, 18.dp, blur)
            .background(Brush.verticalGradient(listOf(tintTop, tintBottom)))
            .drawBehind {
                // soft specular glow from the top-left = "liquid glass" sheen
                drawRect(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = specular), Color.Transparent),
                        center = Offset(size.width * 0.2f, size.height * 0.04f), radius = size.height * 0.5f
                    )
                )
            }
            .border(
                1.4.dp,
                Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.90f), Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.50f))
                ),
                shape
            )
            .pointerInput(Unit) { detectTapGestures { currentOnSelect(tabs[posAt(it.y).roundToInt()]) } }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { dragPos = posAt(it.y); dragging = true },
                    onVerticalDrag = { change, _ -> change.consume(); dragPos = posAt(change.position.y) },
                    onDragEnd = { finishDrag() },
                    onDragCancel = { finishDrag() }
                )
            }
    ) {
        // glass capsule that slides to the active tab / follows the finger
        Box(
            Modifier.offset(x = inset).width(pillW - inset * 2).height(slot)
                .graphicsLayer {
                    val p = if (dragging) dragPos else settled.value
                    translationY = padPx + p * stepPx
                    scaleX = scale.value; scaleY = scale.value
                }
                .clip(capsule)
                .background(Brush.verticalGradient(listOf(capTop, capBottom)))
                .drawBehind {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = if (dark) 0.25f else 0.60f), Color.Transparent),
                            endY = size.height * 0.5f
                        )
                    )
                }
                .border(
                    1.2.dp,
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.35f))),
                    capsule
                )
        )
        Column(Modifier.padding(vertical = padV)) {
            tabs.forEach { tab ->
                val on = tab.ordinal == hover
                Box(Modifier.fillMaxWidth().height(slot), contentAlignment = Alignment.Center) {
                    if (on) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(tab.icon, tab.label, Modifier.size(22.dp), tint = tabAccent)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                tab.label, fontSize = 9.5.sp, fontWeight = FontWeight.Bold,
                                color = tabAccent, maxLines = 1
                            )
                        }
                    } else {
                        Icon(tab.icon, tab.label, tint = fg(0.85f))
                    }
                }
            }
        }
    }
}

@Composable
fun PlayCircle(
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 36.dp,
    icon: ImageVector = Icons.Default.PlayArrow,
    container: Color = fg(0.12f),
    tint: Color = fg()
) {
    Box(
        Modifier.size(size).clip(CircleShape).background(container).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.6f), tint = tint) }
}

/** Flat song row: rounded cover, title/artist, small play button. */
@Composable
fun SongRow(song: Song, playing: Boolean, onPlay: () -> Unit, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onPlay)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (playing) accentText() else fg()
            )
            Text(
                song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = fg(0.6f)
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayCircle(onPlay, container = if (playing) Cyan else fg(0.12f), tint = if (playing) Ink else fg())
        if (onMore != null) {
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More", tint = fg(0.75f)) }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp)
            .shadow(
                12.dp, RoundedCornerShape(28.dp),
                ambientColor = Color.Black.copy(alpha = 0.35f), spotColor = Color.Black.copy(alpha = 0.45f)
            )
            .clip(RoundedCornerShape(28.dp)).background(Color(0xFF26212F))
            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(28.dp))
            .clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      CompositionLocalProvider(LocalContentColor provides Color.White) {
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(vm.currentMeta?.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(
                vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
        }
        if (vm.buffering) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Cyan)
        Spacer(Modifier.width(6.dp))
        PlayCircle(
            onClick = { vm.togglePlay() }, size = 42.dp,
            icon = if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            container = Cyan, tint = Ink
        )
        IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, "Next") }
      }
    }
}

@Composable
fun FluxChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.clip(shape)
            .background(if (selected) Cyan else look.glass)
            .border(1.dp, if (selected) Cyan else look.border, shape)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
        Text(
            label, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Ink else fg()
        )
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: () -> Unit = {}) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, fontSize = 13.sp, color = fg(0.6f),
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(4.dp)
            )
        }
    }
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = fg(), unfocusedTextColor = fg(), cursorColor = accentText(),
    focusedPlaceholderColor = fg(0.6f),
    unfocusedPlaceholderColor = fg(0.6f)
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
