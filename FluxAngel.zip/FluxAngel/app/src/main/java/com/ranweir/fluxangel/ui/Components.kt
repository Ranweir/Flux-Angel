package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

enum class NavTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    EXPLORE("Explore", Icons.Default.Search),
    LIBRARY("Library", Icons.Default.LibraryMusic),
    HISTORY("History", Icons.Default.History)
}

@Composable
fun BottomNav(selected: NavTab, onSelect: (NavTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .glass(RoundedCornerShape(28.dp)).padding(6.dp)
    ) {
        NavTab.values().forEach { tab ->
            val sel = tab == selected
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(22.dp))
                    .background(if (sel) Color.White.copy(alpha = 0.24f) else Color.Transparent)
                    .clickable { onSelect(tab) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(tab.icon, tab.label, tint = if (sel) Color.White else Color.White.copy(alpha = 0.65f))
                Text(
                    tab.label, fontSize = 11.sp,
                    color = if (sel) Color.White else Color.White.copy(alpha = 0.65f)
                )
            }
        }
    }
}

@Composable
fun PlayCircle(onClick: () -> Unit, size: androidx.compose.ui.unit.Dp = 36.dp, icon: ImageVector = Icons.Default.PlayArrow) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Color.White.copy(alpha = 0.24f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.6f)) }
}

@Composable
fun SongRow(song: Song, playing: Boolean, onPlay: () -> Unit, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .glass(RoundedCornerShape(20.dp)).clickable(onClick = onPlay).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (playing) Highlight else Color.White
            )
            Text(
                song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.7f)
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayCircle(onPlay)
        if (onMore != null) {
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More") }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .glass(RoundedCornerShape(24.dp)).clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(vm.currentMeta?.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(
                vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)
            )
        }
        if (vm.buffering) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
        IconButton(onClick = { vm.togglePlay() }) {
            Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
        }
        IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, "Next") }
    }
}

@Composable
fun FluxChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val look = LocalLook.current
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) Accent else look.glass)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Color.White,
    focusedPlaceholderColor = Color.White.copy(alpha = 0.6f),
    unfocusedPlaceholderColor = Color.White.copy(alpha = 0.6f)
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
