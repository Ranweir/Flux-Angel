package com.ranweir.fluxangel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

enum class NavTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    EXPLORE("Explore", Icons.Default.Search),
    LIBRARY("Library", Icons.Default.LibraryMusic),
    HISTORY("History", Icons.Default.History)
}

/** Floating dark pill; the active tab is a round lime button. */
@Composable
fun BottomNav(selected: NavTab, onSelect: (NavTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 10.dp)
            .clip(CircleShape).background(NavBg)
            .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavTab.values().forEach { tab ->
            val sel = tab == selected
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .background(if (sel) Lime else Color.Transparent)
                        .clickable { onSelect(tab) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(tab.icon, tab.label, tint = if (sel) Ink else Color.White.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun PlayCircle(
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 36.dp,
    icon: ImageVector = Icons.Default.PlayArrow,
    container: Color = Color.White.copy(alpha = 0.12f),
    tint: Color = Color.White
) {
    Box(
        Modifier.size(size).clip(CircleShape).background(container).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.6f), tint = tint) }
}

/** Flat song row: rounded cover, title/artist, small play button. */
@Composable
fun SongRow(song: Song, playing: Boolean, onPlay: () -> Unit, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onPlay)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (playing) Lime else Color.White
            )
            Text(
                song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.6f)
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayCircle(onPlay, container = if (playing) Lime else Color.White.copy(alpha = 0.12f), tint = if (playing) Ink else Color.White)
        if (onMore != null) {
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More", tint = Color.White.copy(alpha = 0.75f)) }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(26.dp)).background(Color(0xFF26212F))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(26.dp))
            .clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(vm.currentMeta?.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(
                vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
        }
        if (vm.buffering) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Lime)
        Spacer(Modifier.width(6.dp))
        PlayCircle(
            onClick = { vm.togglePlay() }, size = 42.dp,
            icon = if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            container = Lime, tint = Ink
        )
        IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, "Next") }
    }
}

@Composable
fun FluxChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.clip(shape)
            .background(if (selected) Lime else look.glass)
            .border(1.dp, if (selected) Lime else look.border, shape)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
        Text(
            label, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Ink else Color.White
        )
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: () -> Unit = {}) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f),
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(4.dp)
            )
        }
    }
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Lime,
    focusedPlaceholderColor = Color.White.copy(alpha = 0.6f),
    unfocusedPlaceholderColor = Color.White.copy(alpha = 0.6f)
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
