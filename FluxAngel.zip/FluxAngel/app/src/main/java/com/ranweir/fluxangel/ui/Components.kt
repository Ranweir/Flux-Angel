package com.ranweir.fluxangel.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import coil.request.CachePolicy
import coil.request.ImageRequest
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

enum class NavTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    EXPLORE("Explore", Icons.Default.Search),
    LIBRARY("Library", Icons.Default.LibraryMusic),
    HISTORY("History", Icons.Default.History)
}

/** Provided by App: extra bottom space so lists scroll clear of the floating mini player. */
val LocalBottomInset = compositionLocalOf { 0.dp }

/**
 * Floating liquid-glass pill on the right edge. Tap a tab, or drag a finger up/down along the
 * pill: the glass bubble follows the finger smoothly (no tab rebuilds while dragging) and the
 * tab is switched once when the finger is released.
 */
@Composable
fun SideNav(
    selected: NavTab, onSelect: (NavTab) -> Unit, backdrop: BackdropState, blur: Boolean,
    capsuleStyle: CapsuleStyle = CapsuleStyle.SMOKE_GLASS, position: NavPosition = NavPosition.RIGHT, barStyle: BarStyle = BarStyle.DEFAULT,
    modifier: Modifier = Modifier
) {
    val tabs = NavTab.values()
    val horiz = position == NavPosition.BOTTOM
    val slot = if (horiz) 76.dp else 74.dp   // length of one tab along the bar
    val padV = 7.dp
    val pillW = if (horiz) 58.dp else 52.dp  // bar thickness
    val capW = if (horiz) 46.dp else 38.dp   // active capsule thickness (idle size); grows ~9% while touched
    val capH = if (horiz) 70.dp else 70.dp   // active capsule length
    val shape = RoundedCornerShape(30.dp)
    val capsule = RoundedCornerShape(26.dp)
    val dark = LocalLook.current.fg == Color.White
    val tabAccent = if (dark) Cyan else Color(0xFF0A7F94)

    val density = LocalDensity.current
    val stepPx = with(density) { slot.toPx() }
    val capOffsetPx = with(density) { ((slot - capH) / 2).toPx() }
    val padPx = with(density) { padV.toPx() }
    val lastIdx = tabs.lastIndex
    val currentOnSelect by rememberUpdatedState(onSelect)
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // capsule position as a fractional tab index; read only inside graphicsLayer => no recomposition per frame
    val settled = remember { Animatable(selected.ordinal.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(selected.ordinal.toFloat()) }
    val scale = animateFloatAsState(
        if (dragging || pressed) 1.09f else 1f,
        spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "capsuleScale"
    )
    LaunchedEffect(selected, dragging) {
        if (!dragging) settled.animateTo(
            selected.ordinal.toFloat(), spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)
        )
    }
    val hover by remember {
        derivedStateOf { (if (dragging) dragPos else settled.value).roundToInt().coerceIn(0, lastIdx) }
    }
    LaunchedEffect(hover) {
        if (dragging) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    fun posAt(y: Float) = ((y - padPx - stepPx / 2f) / stepPx).coerceIn(0f, lastIdx.toFloat())
    fun finishDrag() {
        val target = dragPos.roundToInt().coerceIn(0, lastIdx)
        scope.launch {
            settled.snapTo(dragPos)
            dragging = false
            currentOnSelect(tabs[target])
        }
    }

    // neutral frosted tint (no colour cast). With real blur it is light; without blur (Android < 12) it is denser.
    val real = backdrop.supported && blur
    val tintTop = when {
        real && dark -> Color.White.copy(alpha = 0.16f)
        real -> Color(0xFFECF4F8).copy(alpha = 0.58f)
        dark -> Color(0xFF2A303A).copy(alpha = 0.90f)
        else -> Color(0xFFF3F9FB).copy(alpha = 0.92f)
    }
    val tintBottom = when {
        real && dark -> Color.White.copy(alpha = 0.06f)
        real -> Color(0xFFE3EEF3).copy(alpha = 0.46f)
        dark -> Color(0xFF1B2027).copy(alpha = 0.90f)
        else -> Color(0xFFE2EFF3).copy(alpha = 0.92f)
    }
    val bs = barStyle
    val tintMul = when (bs) { BarStyle.LIQUID -> 0.7f; BarStyle.FROSTED -> 1.7f; BarStyle.BLUR -> 0.55f; BarStyle.GLOW -> 0.9f; else -> 1f }
    fun Color.mul() = copy(alpha = (alpha * tintMul).coerceIn(0f, 0.96f))
    val midnight = Color(0xFF0A0D14).copy(alpha = if (real) 0.62f else 0.92f)
    val barTop = if (bs == BarStyle.MIDNIGHT) midnight else tintTop.mul()
    val barBottom = if (bs == BarStyle.MIDNIGHT) midnight.copy(alpha = midnight.alpha * 0.9f) else tintBottom.mul()
    val blurDp = when (bs) { BarStyle.LIQUID -> 14.dp; BarStyle.FROSTED -> 26.dp; BarStyle.BLUR -> 40.dp; BarStyle.MIDNIGHT -> 12.dp; else -> 18.dp }
    val specBase = if (dark || bs == BarStyle.MIDNIGHT) 0.28f else 0.70f
    val specular = when (bs) { BarStyle.LIQUID -> specBase * 1.4f; BarStyle.BLUR -> specBase * 0.4f; BarStyle.MIDNIGHT -> 0.14f; else -> specBase }.coerceAtMost(0.95f)
    val rimBrush = when (bs) {
        BarStyle.LIQUID -> Brush.linearGradient(listOf(Color.White.copy(0.98f), Color.White.copy(0.12f), Color.White.copy(0.85f)))
        BarStyle.FROSTED -> Brush.linearGradient(listOf(Color.White.copy(0.60f), Color.White.copy(0.30f)))
        BarStyle.BLUR -> Brush.linearGradient(listOf(Color.White.copy(0.35f), Color.White.copy(0.10f)))
        BarStyle.GLOW -> Brush.linearGradient(listOf(Cyan, Violet, Pink))
        BarStyle.MIDNIGHT -> Brush.linearGradient(listOf(Color.White.copy(0.22f), Color.White.copy(0.05f)))
        else -> Brush.linearGradient(listOf(Color.White.copy(0.90f), Color.White.copy(0.10f), Color.White.copy(0.50f)))
    }
    val rimW = when (bs) { BarStyle.LIQUID -> 1.7.dp; BarStyle.GLOW -> 1.6.dp; BarStyle.BLUR -> 0.8.dp; BarStyle.MIDNIGHT -> 1.dp; else -> 1.4.dp }
    val shadowAmbient = if (bs == BarStyle.GLOW) Cyan.copy(alpha = 0.55f) else Color.Black.copy(alpha = 0.28f)
    val shadowSpot = if (bs == BarStyle.GLOW) Violet.copy(alpha = 0.75f) else Color.Black.copy(alpha = 0.38f)
    val elevation = if (bs == BarStyle.GLOW) 16.dp else 10.dp
    val cs = capsuleStyle
    val capTop = if (dark) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.30f)
    val capBottom = if (dark) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.10f)
    val activeColor = when (cs) {
        CapsuleStyle.ORIGINAL -> tabAccent
        CapsuleStyle.SMOKE_CYAN -> Cyan
        else -> Color.White
    }

    Box(
        modifier
            .then(
                if (horiz) Modifier.height(pillW).width(slot * tabs.size + padV * 2)
                else Modifier.width(pillW).height(slot * tabs.size + padV * 2)
            )
            .shadow(elevation, shape, ambientColor = shadowAmbient, spotColor = shadowSpot)
            .clip(shape)
            .backdropBlur(backdrop, blurDp, blur)
            .background(Brush.verticalGradient(listOf(barTop, barBottom)))
            .drawBehind {
                // soft specular glow from the top-left = "liquid glass" sheen
                drawRect(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = specular), Color.Transparent),
                        center = Offset(size.width * 0.2f, size.height * 0.04f), radius = size.height * 0.5f
                    )
                )
                if (bs == BarStyle.LIQUID) {
                    // second reflection from the opposite corner
                    drawRect(
                        Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.38f), Color.Transparent),
                            center = Offset(size.width * 0.85f, size.height * 0.97f), radius = size.height * 0.4f
                        )
                    )
                }
                if (bs == BarStyle.GLOW) {
                    // inner neon wash along the edges
                    drawRect(
                        Brush.linearGradient(
                            listOf(Cyan.copy(alpha = 0.16f), Color.Transparent, Violet.copy(alpha = 0.18f))
                        )
                    )
                }
            }
            .border(rimW, rimBrush, shape)
            .pointerInput(horiz) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { currentOnSelect(tabs[posAt(if (horiz) it.x else it.y).roundToInt()]) }
                )
            }
            .pointerInput(horiz) {
                if (horiz) detectHorizontalDragGestures(
                    onDragStart = { dragPos = posAt(it.x); dragging = true },
                    onHorizontalDrag = { change, _ -> change.consume(); dragPos = posAt(change.position.x) },
                    onDragEnd = { finishDrag() },
                    onDragCancel = { finishDrag() }
                ) else detectVerticalDragGestures(
                    onDragStart = { dragPos = posAt(it.y); dragging = true },
                    onVerticalDrag = { change, _ -> change.consume(); dragPos = posAt(change.position.y) },
                    onDragEnd = { finishDrag() },
                    onDragCancel = { finishDrag() }
                )
            }
    ) {
        // active capsule: slides to the active tab / follows the finger. Look depends on the chosen style.
        val smokeBg: Brush? = when (cs) {
            CapsuleStyle.ORIGINAL -> null
            CapsuleStyle.SMOKE_GLASS -> SolidColor(Color(0xFF161C18).copy(alpha = 0.48f))
            CapsuleStyle.DEEP_SMOKE -> SolidColor(Color(0xFF0A0E0C).copy(alpha = 0.68f))
            CapsuleStyle.SMOKE_CYAN -> SolidColor(Color(0xFF0E161A).copy(alpha = 0.58f))
            CapsuleStyle.BRIGHT_RIM -> SolidColor(Color(0xFF121814).copy(alpha = 0.50f))
            CapsuleStyle.FROSTED_SMOKE -> SolidColor(Color(0xFF101612).copy(alpha = 0.40f))
            CapsuleStyle.SMOKE_GRADIENT -> Brush.verticalGradient(
                listOf(Color(0xFF3C4640).copy(alpha = 0.45f), Color(0xFF080C0A).copy(alpha = 0.70f))
            )
        }
        val smokeBorder: Pair<Color, Float> = when (cs) {
            CapsuleStyle.SMOKE_CYAN -> Cyan.copy(alpha = 0.45f) to 1f
            CapsuleStyle.BRIGHT_RIM -> Color.White.copy(alpha = 0.60f) to 1.3f
            CapsuleStyle.FROSTED_SMOKE -> Color.White.copy(alpha = 0.28f) to 1f
            CapsuleStyle.SMOKE_GRADIENT -> Color.White.copy(alpha = 0.22f) to 1f
            CapsuleStyle.DEEP_SMOKE -> Color.White.copy(alpha = 0.16f) to 1f
            else -> Color.White.copy(alpha = 0.20f) to 1f
        }
        val topShine = when (cs) {
            CapsuleStyle.BRIGHT_RIM -> 0.38f
            CapsuleStyle.FROSTED_SMOKE -> 0.30f
            CapsuleStyle.SMOKE_GRADIENT -> 0.30f
            CapsuleStyle.DEEP_SMOKE -> 0.14f
            else -> 0.18f
        }
        Box(
            Modifier
                .offset(x = if (horiz) 0.dp else (pillW - capW) / 2, y = if (horiz) (pillW - capW) / 2 else 0.dp)
                .then(if (horiz) Modifier.width(capH).height(capW) else Modifier.width(capW).height(capH))
                .graphicsLayer {
                    val p = if (dragging) dragPos else settled.value
                    if (horiz) translationX = padPx + p * stepPx + capOffsetPx
                    else translationY = padPx + p * stepPx + capOffsetPx
                    scaleX = scale.value; scaleY = scale.value
                }
                .shadow(
                    if (cs == CapsuleStyle.ORIGINAL) 5.dp else 4.dp, capsule,
                    ambientColor = if (cs == CapsuleStyle.SMOKE_CYAN) Cyan.copy(alpha = 0.35f) else Color(0xFF003C50).copy(alpha = 0.30f),
                    spotColor = if (cs == CapsuleStyle.SMOKE_CYAN) Cyan.copy(alpha = 0.55f) else Color(0xFF003C50).copy(alpha = 0.40f)
                )
                .clip(capsule)
                .then(
                    if (smokeBg == null) Modifier.background(Brush.verticalGradient(listOf(capTop, capBottom)))
                    else Modifier.background(smokeBg)
                )
                .drawBehind {
                    val w = size.width
                    val h = size.height
                    if (smokeBg != null) {
                        // soft shine along the top edge of the smoke glass
                        drawRect(
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = topShine), Color.Transparent),
                                startY = 0f, endY = h * 0.28f
                            )
                        )
                    } else {
                        // soft bright glow along the bottom edge
                        drawRect(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = if (dark) 0.25f else 0.55f)),
                                startY = h * 0.62f, endY = h
                            )
                        )
                        // curved specular highlight, top-left
                        rotate(-12f, pivot = Offset(w * 0.4f, h * 0.2f)) {
                            drawOval(
                                Brush.verticalGradient(
                                    listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0f)),
                                    startY = h * 0.05f, endY = h * 0.39f
                                ),
                                topLeft = Offset(w * 0.12f, h * 0.05f), size = Size(w * 0.62f, h * 0.34f)
                            )
                        }
                        // small bright reflection near the bottom
                        drawOval(
                            Brush.radialGradient(
                                listOf(Color.White.copy(alpha = 0.85f), Color.White.copy(alpha = 0f)),
                                center = Offset(w * 0.5f, h * 0.89f), radius = w * 0.32f
                            ),
                            topLeft = Offset(w * 0.18f, h * 0.81f), size = Size(w * 0.64f, h * 0.16f)
                        )
                    }
                }
                .border(
                    if (smokeBg == null) 1.3.dp else smokeBorder.second.dp,
                    if (smokeBg == null) Color.White.copy(alpha = 0.95f) else smokeBorder.first,
                    capsule
                )
        )
        val cells: @Composable () -> Unit = {
            tabs.forEach { tab ->
                val on = tab.ordinal == hover
                Box(
                    if (horiz) Modifier.width(slot).fillMaxHeight() else Modifier.fillMaxWidth().height(slot),
                    contentAlignment = Alignment.Center
                ) {
                    if (horiz) {
                        // bottom bar: every tab has icon + label, so icons all sit on the same line
                        Column(
                            if (on) Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value } else Modifier,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(tab.icon, tab.label, Modifier.size(22.dp), tint = if (on) activeColor else fg(0.85f))
                            Spacer(Modifier.height(3.dp))
                            Text(
                                tab.label, fontSize = 9.5.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                                color = if (on) activeColor else fg(0.75f), maxLines = 1
                            )
                        }
                    } else if (on) {
                        Column(
                            Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(tab.icon, tab.label, Modifier.size(22.dp), tint = activeColor)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                tab.label, fontSize = 9.5.sp, fontWeight = FontWeight.Bold,
                                color = activeColor, maxLines = 1
                            )
                        }
                    } else {
                        Icon(tab.icon, tab.label, tint = fg(0.85f))
                    }
                }
            }
        }
        if (horiz) Row(Modifier.padding(horizontal = padV)) { cells() }
        else Column(Modifier.padding(vertical = padV)) { cells() }
    }
}

/** Round profile avatar: the user's own photo if set, otherwise the default gradient + person icon. */
@Composable
fun ProfileAvatar(vm: MainViewModel, size: Dp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val version = vm.profileVersion
    Box(
        modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Violet, Pink)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (version > 0L) {
            val request = remember(version) {
                ImageRequest.Builder(ctx).data(vm.profileFile)
                    .memoryCacheKey("profile-$version").diskCachePolicy(CachePolicy.DISABLED).build()
            }
            AsyncImage(
                model = request, contentDescription = "Profile", contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Default.Person, "Profile", tint = Color.White)
        }
    }
}

@Composable
fun PlayCircle(
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 36.dp,
    icon: ImageVector = Icons.Default.PlayArrow,
    container: Color = fg(0.12f),
    tint: Color = fg()
) {
    Box(
        Modifier.size(size).clip(CircleShape).background(container).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.6f), tint = tint) }
}

/** Flat song row: rounded cover, title/artist, small play button. */
@Composable
fun SongRow(song: Song, playing: Boolean, onPlay: () -> Unit, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onPlay)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (playing) accentText() else fg()
            )
            Text(
                song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = fg(0.6f)
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayCircle(onPlay, container = if (playing) Cyan else fg(0.12f), tint = if (playing) Ink else fg())
        if (onMore != null) {
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More", tint = fg(0.75f)) }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp)
            .shadow(
                12.dp, RoundedCornerShape(28.dp),
                ambientColor = Color.Black.copy(alpha = 0.35f), spotColor = Color.Black.copy(alpha = 0.45f)
            )
            .clip(RoundedCornerShape(28.dp)).background(Color(0xFF26212F))
            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(28.dp))
            .clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      CompositionLocalProvider(LocalContentColor provides Color.White) {
        AsyncImage(
            model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(vm.currentMeta?.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(
                vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
        }
        if (vm.buffering) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Cyan)
        Spacer(Modifier.width(6.dp))
        PlayCircle(
            onClick = { vm.togglePlay() }, size = 42.dp,
            icon = if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            container = Cyan, tint = Ink
        )
        IconButton(onClick = { vm.next() }) { Icon(Icons.Default.SkipNext, "Next") }
      }
    }
}

@Composable
fun FluxChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.clip(shape)
            .background(if (selected) Cyan else look.glass)
            .border(1.dp, if (selected) Cyan else look.border, shape)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
        Text(
            label, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Ink else fg()
        )
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: () -> Unit = {}) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, fontSize = 13.sp, color = fg(0.6f),
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(4.dp)
            )
        }
    }
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = fg(), unfocusedTextColor = fg(), cursorColor = accentText(),
    focusedPlaceholderColor = fg(0.6f),
    unfocusedPlaceholderColor = fg(0.6f)
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
