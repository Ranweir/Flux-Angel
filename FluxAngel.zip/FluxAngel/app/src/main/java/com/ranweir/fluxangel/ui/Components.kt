package com.ranweir.fluxangel.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import coil.request.CachePolicy
import coil.request.ImageRequest
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ranweir.fluxangel.MainViewModel
import com.ranweir.fluxangel.Song

/**
 * Window-pixel positions shared by the mini bar and the full player so that the open / close animation
 * can morph one into the other (album art flies up into the card, the bar turns into the control pill).
 */
@Stable
class SheetGeo {
    var miniArt by mutableStateOf(Offset.Zero)      // centre of the small album art in the mini bar
    var miniArtSize by mutableFloatStateOf(0f)
    var miniBar by mutableStateOf(Offset.Zero)      // centre of the whole mini bar (resting place)
    var carousel by mutableStateOf(Offset.Zero)     // centre of the cover-flow area in the player
    var pill by mutableStateOf(Offset.Zero)         // centre of the player's control pill
}

enum class NavTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    EXPLORE("Explore", Icons.Default.Search),
    LIBRARY("Library", Icons.Default.LibraryMusic),
    HISTORY("History", Icons.Default.History)
}

/** Provided by App: extra bottom space so lists scroll clear of the floating mini player. */
val LocalBottomInset = compositionLocalOf { 0.dp }

/**
 * Floating liquid-glass navigation: a round Search button on the left, a pill with two tabs (Home | Playlists)
 * in the middle and a round History button on the right. Tap a tab, or drag a finger across the pill: the glass
 * thumb follows the finger (stretching a little while it travels) and the tab is switched when the finger is
 * released. Search / History light up their own round button; the thumb then fades out of the pill.
 */
@Composable
fun SideNav(
    selected: NavTab, onSelect: (NavTab) -> Unit, backdrop: BackdropState, blur: Boolean,
    barStyle: BarStyle = BarStyle.BLUR,
    modifier: Modifier = Modifier,
    onScrub: (Float) -> Unit = {},      // finger position over the pill while dragging: 0 = first tab .. 1 = second tab
    onScrubEnd: (Int) -> Unit = {},     // thumb has settled after release: index of the tab it landed on
    thumb: Animatable<Float, AnimationVector1D>? = null    // shared thumb position: the pages read this very value, so page and pill can never differ
) {
    val pillTabs = listOf(NavTab.HOME, NavTab.LIBRARY)
    val pillLabels = listOf("Home", "Playlists")
    val slot = 96.dp                 // width of one tab in the pill
    val padV = 5.dp
    val barH = 50.dp                 // height of the pill and diameter of the round buttons
    val capLen = slot - 1.dp         // thumb width (idle size); shrinks ~10% while touched
    val capH = barH - 9.dp          // thumb height
    val shape = RoundedCornerShape(50)
    val capsule = RoundedCornerShape(50)
    val dark = LocalLook.current.fg == Color.White
    val accentC = LocalLook.current.accentFill
    val tabAccent = LocalLook.current.accent

    val density = LocalDensity.current
    val stepPx = with(density) { slot.toPx() }
    val capOffsetPx = with(density) { ((slot - capLen) / 2).toPx() }
    val padPx = with(density) { padV.toPx() }
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentSelected by rememberUpdatedState(selected)
    val currentOnScrub by rememberUpdatedState(onScrub)
    val currentOnScrubEnd by rememberUpdatedState(onScrubEnd)
    var scrubOn by remember { mutableStateOf(false) }   // this drag started on Home/Playlists: the page follows the finger
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    val pillSelected = selected == NavTab.HOME || selected == NavTab.LIBRARY
    val selIdx = if (selected == NavTab.LIBRARY) 1 else 0

    // thumb position as a fractional tab index; read only inside graphicsLayer => no recomposition per frame
    val settled = thumb ?: remember { Animatable(selIdx.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(selIdx.toFloat()) }
    val scale = animateFloatAsState(
        if (dragging || pressed) 0.9f else 1f,
        spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessMedium), label = "capsuleScale"
    )
    val thumbVis = animateFloatAsState(
        if (pillSelected || dragging || pressed) 1f else 0f,
        spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium), label = "thumbVis"
    )
    LaunchedEffect(selected, dragging) {
        if (!dragging && pillSelected && !scrubOn) settled.animateTo(
            selIdx.toFloat(), spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium)
        )
    }
    val hover by remember {
        derivedStateOf { (if (dragging) dragPos else settled.value).roundToInt().coerceIn(0, 1) }
    }
    LaunchedEffect(hover) {
        if (dragging) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    // the thumb trails the finger a little (critically damped spring): smooth, never jumpy
    fun follow() { scope.launch { settled.animateTo(dragPos, spring(dampingRatio = 1f, stiffness = 1000f)) } }
    fun posAt(x: Float) = ((x - padPx - stepPx / 2f) / stepPx).coerceIn(0f, 1f)
    fun finishDrag() {
        val target = dragPos.roundToInt().coerceIn(0, 1)
        val scrub = scrubOn
        scope.launch {
            dragging = false   // the thumb keeps its glide: it settles from where it is (no jump)
            if (scrub) {
                // the pages ride on this same value, so they settle together with the thumb
                settled.animateTo(target.toFloat(), spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium))
                currentOnScrubEnd(target)
            } else currentOnSelect(pillTabs[target])
            scrubOn = false
        }
    }

    // neutral frosted tint (no colour cast). With real blur it is light; without blur (Android < 12) it is denser.
    val real = backdrop.supported && blur
    val tintTop = when {
        real -> Color.Transparent   // no tint at all: just the blurred content behind
        dark -> Color(0xFF2A303A).copy(alpha = 0.90f)
        else -> Color(0xFFF3F9FB).copy(alpha = 0.92f)
    }
    val tintBottom = when {
        real -> Color.Transparent
        dark -> Color(0xFF1B2027).copy(alpha = 0.90f)
        else -> Color(0xFFE2EFF3).copy(alpha = 0.92f)
    }
    val bs = barStyle
    val barTop = tintTop
    val barBottom = tintBottom
    val blurDp = 40.dp   // the one and only style: strong blur, almost no tint or border
    val specular = (if (dark) 0.28f else 0.70f) * 0.4f
    val rimBrush = Brush.linearGradient(listOf(Color.White.copy(0.35f), Color.White.copy(0.10f)))
    val rimW = 0.8.dp
    val shadowAmbient = Color.Black.copy(alpha = 0.28f)
    val shadowSpot = Color.Black.copy(alpha = 0.38f)
    val elevation = 10.dp
    // the thumb is plain opaque white (no blur, no tint) with dark text; only the bar itself is blurred glass
    val thumbFill = Color.White.copy(alpha = 0.97f)
    val onThumb = Color(0xFF111418)

    // the glass look shared by the pill and the two round buttons
    @Composable
    fun Modifier.surface(sh: Shape): Modifier = this
        .shadow(elevation, sh, ambientColor = shadowAmbient, spotColor = shadowSpot)
        .clip(sh)
        .backdropBlur(backdrop, blurDp, blur)
        .background(Brush.verticalGradient(listOf(barTop, barBottom)))
        .drawBehind {
                // soft specular glow from the top-left = "liquid glass" sheen
                drawRect(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = specular), Color.Transparent),
                        center = Offset(size.width * 0.2f, size.height * 0.04f), radius = size.height * 0.5f
                    )
                )
            }
        .border(rimW, rimBrush, sh)

    @Composable
    fun NavCircle(tab: NavTab) {
        val on = selected == tab
        var down by remember { mutableStateOf(false) }
        val sc by animateFloatAsState(
            if (down) 1.12f else 1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "circleScale"
        )
        val glow by animateFloatAsState(
            if (on) 1f else 0f, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow), label = "circleOn"
        )
        Box(
            Modifier.size(barH)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .surface(CircleShape)
                .drawBehind { drawRect(thumbFill, alpha = glow.coerceIn(0f, 1f)) }
                .pointerInput(tab) {
                    detectTapGestures(
                        onPress = { down = true; tryAwaitRelease(); down = false },
                        onTap = { currentOnSelect(tab) }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(tab.icon, tab.label, Modifier.size(26.dp), tint = if (on) onThumb else fg(0.85f))
        }
    }

    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(32.dp)) {
        NavCircle(NavTab.EXPLORE)
        Box(
            Modifier
                .width(slot * 2 + padV * 2).height(barH)
                .surface(shape)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                        onTap = { currentOnSelect(pillTabs[posAt(it.x).roundToInt()]) }
                    )
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = {
                            dragPos = posAt(it.x); dragging = true
                            follow()
                            scrubOn = currentSelected == NavTab.HOME || currentSelected == NavTab.LIBRARY
                            if (scrubOn) currentOnScrub(dragPos)
                        },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            dragPos = posAt(change.position.x)
                            follow()
                            if (scrubOn) currentOnScrub(dragPos)      // the page follows the finger
                            else {                                    // started from Search/History: switch at the middle
                                val t = pillTabs[dragPos.roundToInt().coerceIn(0, 1)]
                                if (t != currentSelected) currentOnSelect(t)
                            }
                        },
                        onDragEnd = { finishDrag() },
                        onDragCancel = { finishDrag() }
                    )
                }
        ) {
            // glass thumb: slides to the active tab / follows the finger, stretching while it moves
            Box(
                Modifier
                    .offset(y = (barH - capH) / 2)
                    .width(capLen).height(capH)
                    .graphicsLayer {
                        val p = settled.value
                        translationX = padPx + p * stepPx + capOffsetPx
                        val d = abs(p - p.roundToInt())          // 0 at rest .. 0.5 halfway between tabs
                        val vis = thumbVis.value.coerceIn(0f, 1f)
                        val k = scale.value * (0.85f + 0.15f * vis)
                        val lag = if (dragging) abs(dragPos - p) else 0f   // stretches more the further it trails the finger
                        scaleX = k * (1f + 0.80f * d + 0.60f * lag)
                        scaleY = k * (1f - 0.35f * d - 0.20f * lag)
                        alpha = vis
                    }
                    .shadow(3.dp, capsule, ambientColor = Color.Black.copy(alpha = 0.12f), spotColor = Color.Black.copy(alpha = 0.22f))
                    .clip(capsule)
                    .background(thumbFill)
            )
            Row(Modifier.padding(horizontal = padV).fillMaxHeight()) {
                pillLabels.forEachIndexed { i, label ->
                    val on = i == hover && (pillSelected || dragging || pressed)
                    Box(Modifier.width(slot).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        Text(
                            label, fontSize = 15.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                            color = if (on) onThumb else fg(0.8f), maxLines = 1
                        )
                    }
                }
            }
        }
        NavCircle(NavTab.HISTORY)
    }
}

/** Round profile avatar: the user's own photo if set, otherwise the default gradient + person icon. */
@Composable
fun ProfileAvatar(vm: MainViewModel, size: Dp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val version = vm.profileVersion
    Box(
        modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Violet, Pink)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (version > 0L) {
            val request = remember(version) {
                ImageRequest.Builder(ctx).data(vm.profileFile)
                    .memoryCacheKey("profile-$version").diskCachePolicy(CachePolicy.DISABLED).build()
            }
            AsyncImage(
                model = request, contentDescription = "Profile", contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Default.Person, "Profile", tint = Color.White)
        }
    }
}

@Composable
fun PlayCircle(
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 36.dp,
    icon: ImageVector = Icons.Default.PlayArrow,
    container: Color = fg(0.12f),
    tint: Color = fg()
) {
    Box(
        Modifier.size(size).clip(CircleShape).background(container).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.6f), tint = tint) }
}

/** Flat song row: rounded cover, title/artist, small play button. */
@Composable
fun SongRow(song: Song, playing: Boolean, onPlay: () -> Unit, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onPlay)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = song.thumb, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (playing) accentText() else fg()
            )
            Text(
                song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = fg(0.6f)
            )
        }
        Spacer(Modifier.width(8.dp))
        PlayCircle(onPlay, container = if (playing) LocalLook.current.accentFill else fg(0.12f), tint = if (playing) Ink else fg())
        if (onMore != null) {
            IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "More", tint = fg(0.75f)) }
        }
    }
}

/** Three floating glass pieces (previous · now playing pill · next), like the lock-screen player. */
@Composable
fun MiniPlayer(vm: MainViewModel, backdrop: BackdropState, blur: Boolean, artAlpha: () -> Float = { 1f }, onOpen: () -> Unit) {
    val real = backdrop.supported && blur
    val h = 54.dp
    val dark = LocalLook.current.fg == Color.White
    val content = LocalLook.current.fg
    // same frosted tint as the navigation pill: light glass in light mode, smoke glass in dark mode
    val tintTop = when {
        real && dark -> Color.White.copy(alpha = 0.16f)
        real -> Color(0xFFECF4F8).copy(alpha = 0.58f)
        dark -> Color(0xFF2A303A).copy(alpha = 0.90f)
        else -> Color(0xFFF3F9FB).copy(alpha = 0.92f)
    }
    val tintBottom = when {
        real && dark -> Color.White.copy(alpha = 0.06f)
        real -> Color(0xFFE3EEF3).copy(alpha = 0.46f)
        dark -> Color(0xFF1B2027).copy(alpha = 0.90f)
        else -> Color(0xFFE2EFF3).copy(alpha = 0.92f)
    }
    val fill = Brush.verticalGradient(listOf(tintTop, tintBottom))
    val rim = Brush.linearGradient(listOf(Color.White.copy(0.90f), Color.White.copy(0.10f), Color.White.copy(0.50f)))

    @Composable
    fun Modifier.glassPiece(shape: androidx.compose.ui.graphics.Shape): Modifier = this
        .shadow(10.dp, shape, ambientColor = Color.Black.copy(0.28f), spotColor = Color.Black.copy(0.38f))
        .clip(shape)
        .backdropBlur(backdrop, 18.dp, blur)
        .background(fill)
        .border(1.2.dp, rim, shape)

    CompositionLocalProvider(LocalContentColor provides content) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // previous
            Box(
                Modifier.size(h).glassPiece(CircleShape).clickable { vm.previous() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.SkipPrevious, "Previous", Modifier.size(26.dp)) }

            Spacer(Modifier.width(10.dp))

            // now playing pill
            Row(
                Modifier.weight(1f).height(h).glassPiece(CircleShape).clickable(onClick = onOpen).padding(start = 8.dp, end = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = vm.currentMeta?.artworkUri, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(38.dp).graphicsLayer { alpha = artAlpha() }.clip(RoundedCornerShape(12.dp))
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        vm.currentMeta?.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp
                    )
                    Text(
                        vm.currentMeta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontSize = 11.sp, color = content.copy(alpha = 0.6f)
                    )
                }
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(content.copy(alpha = 0.12f))
                        .border(0.8.dp, content.copy(0.14f), CircleShape).clickable { vm.togglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    if (vm.buffering) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = content)
                    else Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", Modifier.size(24.dp))
                }
            }

            Spacer(Modifier.width(10.dp))

            // next
            Box(
                Modifier.size(h).glassPiece(CircleShape).clickable { vm.next() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.SkipNext, "Next", Modifier.size(26.dp)) }
        }
    }
}

@Composable
fun FluxChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.clip(shape)
            .background(if (selected) LocalLook.current.accentFill else look.glass)
            .border(1.dp, if (selected) LocalLook.current.accentFill else look.border, shape)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
        Text(
            label, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Ink else fg()
        )
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: () -> Unit = {}) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, fontSize = 13.sp, color = fg(0.6f),
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(4.dp)
            )
        }
    }
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = fg(), unfocusedTextColor = fg(), cursorColor = accentText(),
    focusedPlaceholderColor = fg(0.6f),
    unfocusedPlaceholderColor = fg(0.6f)
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
