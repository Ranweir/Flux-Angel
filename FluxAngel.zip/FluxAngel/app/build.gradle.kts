import com.android.build.api.instrumentation.FramesComputationMode
import com.android.build.api.instrumentation.AsmClassVisitorFactory
import com.android.build.api.instrumentation.ClassContext
import com.android.build.api.instrumentation.ClassData
import com.android.build.api.instrumentation.InstrumentationParameters
import com.android.build.api.instrumentation.InstrumentationScope
import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

/**
 * Old Android (below 13) lacks URLDecoder.decode(String, Charset) and URLEncoder.encode(String, Charset)
 * (Java 10 APIs). NewPipeExtractor calls them, which throws NoSuchMethodError. This redirects those
 * calls, in all classes, to com.ranweir.fluxangel.CompatUrl.
 */
abstract class UrlCompatFactory : AsmClassVisitorFactory<InstrumentationParameters.None> {
    override fun createClassVisitor(classContext: ClassContext, nextClassVisitor: ClassVisitor): ClassVisitor =
        object : ClassVisitor(Opcodes.ASM9, nextClassVisitor) {
            override fun visitMethod(
                access: Int, name: String?, descriptor: String?, signature: String?, exceptions: Array<out String>?
            ): MethodVisitor {
                val mv = super.visitMethod(access, name, descriptor, signature, exceptions)
                return object : MethodVisitor(Opcodes.ASM9, mv) {
                    override fun visitMethodInsn(
                        opcode: Int, owner: String?, mName: String?, mDesc: String?, isInterface: Boolean
                    ) {
                        if (opcode == Opcodes.INVOKESTATIC &&
                            (owner == "java/net/URLDecoder" || owner == "java/net/URLEncoder") &&
                            (mName == "decode" || mName == "encode") &&
                            mDesc == "(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;"
                        ) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "com/ranweir/fluxangel/CompatUrl", mName, mDesc, false)
                        } else {
                            super.visitMethodInsn(opcode, owner, mName, mDesc, isInterface)
                        }
                    }
                }
            }
        }

    override fun isInstrumentable(classData: ClassData): Boolean =
        classData.className != "com.ranweir.fluxangel.CompatUrl"
}

android {
    namespace = "com.ranweir.fluxangel"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ranweir.fluxangel"
        minSdk = 26
        targetSdk = 34
        versionCode = 27
        versionName = "1.14.1"
    }
    buildTypes {
        // The "debug" build is optimised too, so `gradle assembleDebug` also produces a fast, non-debuggable APK.
        debug {
            isMinifyEnabled = true
            isShrinkResources = false
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            // non-debuggable build (much smoother Compose), signed with the debug key so it installs over old builds
            // R8 optimisation: removes dead code and optimises Compose => noticeably smoother scrolling
            isMinifyEnabled = true
            isShrinkResources = false
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES", "META-INF/INDEX.LIST")
        }
    }
}

androidComponents {
    onVariants { variant ->
        // make Java 10+ URLDecoder/URLEncoder calls inside libraries work on Android 8-12
        variant.instrumentation.transformClassesWith(UrlCompatFactory::class.java, InstrumentationScope.ALL) {}
        variant.instrumentation.setAsmFramesComputationMode(FramesComputationMode.COPY_FRAMES)
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.activity:activity-compose:1.9.0")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.3.1")

    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
}

configurations.all {
    resolutionStrategy.force("com.squareup.okhttp3:okhttp:4.12.0")
}
